import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  language: localStorage.getItem('teryaq_lang') || 'en',
  mobileMenuOpen: false,
  notification: null,
};

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    setLanguage: (state, action) => {
      state.language = action.payload;
      localStorage.setItem('teryaq_lang', action.payload);
      document.documentElement.dir = action.payload === 'ar' ? 'rtl' : 'ltr';
      document.body.dir = action.payload === 'ar' ? 'rtl' : 'ltr';
    },
    toggleMobileMenu: (state) => {
      state.mobileMenuOpen = !state.mobileMenuOpen;
    },
    closeMobileMenu: (state) => {
      state.mobileMenuOpen = false;
    },
    showNotification: (state, action) => {
      state.notification = action.payload;
    },
    clearNotification: (state) => {
      state.notification = null;
    },
  },
});

export const { setLanguage, toggleMobileMenu, closeMobileMenu, showNotification, clearNotification } = uiSlice.actions;
export default uiSlice.reducer;
