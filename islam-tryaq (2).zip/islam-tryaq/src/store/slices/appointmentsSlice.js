import { createSlice } from '@reduxjs/toolkit';
import { appointments as mockAppointments } from '../../data/mockData';

const initialState = {
  list: mockAppointments,
};

const appointmentsSlice = createSlice({
  name: 'appointments',
  initialState,
  reducers: {
    addAppointment: (state, action) => {
      state.list.unshift({ ...action.payload, id: Date.now() });
    },
    cancelAppointment: (state, action) => {
      const appt = state.list.find(a => a.id === action.payload);
      if (appt) appt.status = 'cancelled';
    },
    rescheduleAppointment: (state, action) => {
      const appt = state.list.find(a => a.id === action.payload.id);
      if (appt) { appt.date = action.payload.date; appt.time = action.payload.time; }
    },
  },
});

export const { addAppointment, cancelAppointment, rescheduleAppointment } = appointmentsSlice.actions;
export default appointmentsSlice.reducer;
