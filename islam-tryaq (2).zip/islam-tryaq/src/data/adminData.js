export const pendingDoctors = [
  {
    id: 101,
    name: 'Dr. Khalid Mansour',
    specialty: 'Cardiology',
    email: 'khalid.mansour@email.com',
    phone: '+1 (555) 234-5678',
    submittedAt: 'Mar 28, 2026',
    documents: ['Medical License', 'Board Certificate', 'CV'],
    image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=100&h=100&fit=crop&crop=face',
    status: 'pending',
  },
  {
    id: 102,
    name: 'Dr. Lena Hoffmann',
    specialty: 'Neurology',
    email: 'lena.hoffmann@email.com',
    phone: '+1 (555) 345-6789',
    submittedAt: 'Mar 29, 2026',
    documents: ['Medical License', 'Board Certificate'],
    image: 'https://images.unsplash.com/photo-1651008376811-b90baee60c1f?w=100&h=100&fit=crop&crop=face',
    status: 'pending',
  },
  {
    id: 103,
    name: 'Dr. Samuel Okafor',
    specialty: 'Pediatrics',
    email: 'samuel.okafor@email.com',
    phone: '+1 (555) 456-7890',
    submittedAt: 'Mar 30, 2026',
    documents: ['Medical License'],
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=100&h=100&fit=crop&crop=face',
    status: 'pending',
  },
];

export const allUsers = [
  { id: 1, name: 'John Doe', email: 'john.doe@email.com', role: 'patient', status: 'active', joined: 'Jan 10, 2026', appointments: 12 },
  { id: 2, name: 'Maria Garcia', email: 'maria.garcia@email.com', role: 'patient', status: 'active', joined: 'Feb 3, 2026', appointments: 5 },
  { id: 3, name: 'Ahmed Al-Rashid', email: 'ahmed.rashid@email.com', role: 'patient', status: 'suspended', joined: 'Mar 1, 2026', appointments: 2 },
  { id: 4, name: 'Dr. Sarah Mitchell', email: 'sarah.mitchell@email.com', role: 'doctor', status: 'active', joined: 'Dec 5, 2025', appointments: 127 },
  { id: 5, name: 'Dr. James Cooper', email: 'james.cooper@email.com', role: 'doctor', status: 'active', joined: 'Dec 12, 2025', appointments: 98 },
  { id: 6, name: 'Linda Parker', email: 'linda.parker@email.com', role: 'patient', status: 'active', joined: 'Mar 20, 2026', appointments: 1 },
];

export const financialData = [
  { month: 'Oct', revenue: 12400, consultations: 104 },
  { month: 'Nov', revenue: 15800, consultations: 132 },
  { month: 'Dec', revenue: 18200, consultations: 151 },
  { month: 'Jan', revenue: 16900, consultations: 140 },
  { month: 'Feb', revenue: 21300, consultations: 178 },
  { month: 'Mar', revenue: 24700, consultations: 206 },
];

export const complaints = [
  { id: 1, from: 'John Doe', role: 'patient', subject: 'Doctor was late to session', status: 'open', date: 'Mar 29, 2026', priority: 'medium' },
  { id: 2, from: 'Maria Garcia', role: 'patient', subject: 'Payment not refunded after cancellation', status: 'open', date: 'Mar 30, 2026', priority: 'high' },
  { id: 3, from: 'Dr. Sarah Mitchell', role: 'doctor', subject: 'Technical issue during video call', status: 'resolved', date: 'Mar 25, 2026', priority: 'low' },
  { id: 4, from: 'Ahmed Al-Rashid', role: 'patient', subject: 'Prescription not received', status: 'open', date: 'Mar 31, 2026', priority: 'high' },
];

export const adminSpecialties = [
  { id: 1, name: 'Cardiology', nameAr: 'أمراض القلب', doctors: 8, icon: '❤️' },
  { id: 2, name: 'Neurology', nameAr: 'أمراض الأعصاب', doctors: 5, icon: '🧠' },
  { id: 3, name: 'Ophthalmology', nameAr: 'طب العيون', doctors: 6, icon: '👁️' },
  { id: 4, name: 'General Medicine', nameAr: 'الطب العام', doctors: 15, icon: '🩺' },
  { id: 5, name: 'Pediatrics', nameAr: 'طب الأطفال', doctors: 9, icon: '👶' },
  { id: 6, name: 'Orthopedics', nameAr: 'العظام والمفاصل', doctors: 7, icon: '🦴' },
  { id: 7, name: 'Dermatology', nameAr: 'الأمراض الجلدية', doctors: 4, icon: '🌿' },
  { id: 8, name: 'Psychiatry', nameAr: 'الطب النفسي', doctors: 3, icon: '🧘' },
];
