import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import './i18n';
import store from './store';
import theme from './theme';

// Patient pages
import Home from './pages/Home';
import Login from './pages/Auth/Login';
import Register from './pages/Auth/Register';
import FindDoctors from './pages/Doctors';
import DoctorProfile from './pages/Doctors/DoctorProfile';
import MyAppointments from './pages/Appointments';
import Booking from './pages/Appointments/Booking';
import Chat from './pages/Chat';
import VideoCall from './pages/VideoCall';
import Profile from './pages/Profile';

// New role-based dashboards
import PatientDashboard from './pages/Patient';
import DoctorDashboard from './pages/Doctor';
import PatientHistory from './pages/Doctor/PatientHistory';
import NGODashboard from './pages/NGO';
import NGOReports from './pages/NGO/Reports';

// Admin pages
import AdminDashboard from './pages/Admin';
import DoctorApprovals from './pages/Admin/DoctorApprovals';
import UserManagement from './pages/Admin/UserManagement';
import Specialties from './pages/Admin/Specialties';
import FinancialReports from './pages/Admin/FinancialReports';
import Complaints from './pages/Admin/Complaints';

function AppInit() {
  useEffect(() => {
    const lang = localStorage.getItem('teryaq_lang') || 'en';
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.body.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, []);
  return null;
}

function App() {
  return (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <BrowserRouter>
          <AppInit />
          <Routes>

            {/* Public / Patient routes */}
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/doctors" element={<FindDoctors />} />
            <Route path="/doctors/:id" element={<DoctorProfile />} />
            <Route path="/appointments" element={<MyAppointments />} />
            <Route path="/booking" element={<Booking />} />
            
            <Route path="/chat/:id" element={<Chat />} />
            <Route path="/video/:id" element={<VideoCall />} />
            <Route path="/profile" element={<Profile />} />

            {/* Role-based dashboards */}
            <Route path="/patient" element={<PatientDashboard />} />
            <Route path="/doctor" element={<DoctorDashboard />} />
            <Route path="/doctor/history" element={<PatientHistory />} />
            <Route path="/ngo" element={<NGODashboard />} />
            <Route path="/ngo/reports" element={<NGOReports />} />

            {/* Admin routes */}
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/doctors" element={<DoctorApprovals />} />
            <Route path="/admin/users" element={<UserManagement />} />
            <Route path="/admin/specialties" element={<Specialties />} />
            <Route path="/admin/finance" element={<FinancialReports />} />
            <Route path="/admin/complaints" element={<Complaints />} />

          </Routes>
        </BrowserRouter>
      </ThemeProvider>
    </Provider>
  );
}

export default App;
