import React from 'react';
import { 
  Box, Card, CardContent, CardMedia,
  Typography, Button, Stack, Chip 
} from '@mui/material';
import StarIcon from '@mui/icons-material/Star';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AccessTimeIcon from '@mui/icons-material/AccessTime';

const DoctorCard = ({ doctor, language, navigate }) => {
  const isAr = language === 'ar';

  if (!doctor) return null; // ← حماية من undefined

  return (
    <Card 
      sx={{ 
        borderRadius: 6, 
        boxShadow: '0 10px 40px rgba(0,0,0,0.06)', 
        position: 'relative',
        width: '100%',
        transition: "all 0.4s ease",
        textAlign: 'center', 
        cursor: "pointer",
        padding: "8px",
        '&:hover': {
          transform: 'translateY(-10px)',
          boxShadow: '0 15px 35px rgba(13,148,136,0.2)',
        }
      }}
    >
      {/* Rating Badge */}
      <Box sx={{ 
        position: 'absolute', top: 15, 
        right: isAr ? 'auto' : 15, 
        left: isAr ? 15 : 'auto', 
        zIndex: 2 
      }}>
        <Chip
          icon={<StarIcon sx={{ color: '#FFB400 !important', fontSize: '14px' }} />}
          label={`${doctor.rating}`}
          size="small"
          sx={{ bgcolor: 'white', fontWeight: 'bold', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}
        />
      </Box>

      {/* صورة الطبيب */}
      <Box sx={{ p: 2, display: 'flex', justifyContent: 'center' }}>
        <CardMedia
          component="img"
          image={doctor.image}
          alt={doctor.name}
          sx={{ 
            width: 120, height: 120,
            borderRadius: '50%', 
            objectFit: "cover",
            border: '4px solid #f1f5f9'
          }}
        />
      </Box>

      <CardContent sx={{ px: 3, pb: 4 }}>
        <Typography variant="h6" fontWeight="800" gutterBottom>
          {isAr ? doctor.nameAr : doctor.name}
        </Typography>

        <Typography variant="subtitle2" sx={{ 
          mb: 2, fontWeight: 600, letterSpacing: 0.5, 
          background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', 
          backgroundClip: 'text', display: 'inline-block', 
        }}>
          {isAr ? doctor.specialtyAr : doctor.specialty}
        </Typography>

        <Stack 
          direction="row" spacing={2}
          justifyContent="center" alignItems="center" 
          sx={{ color: 'text.secondary', mb: 3 }}
        >
          <Stack direction="row" alignItems="center" spacing={0.5}>
            <LocationOnIcon sx={{ fontSize: 16 }} />
            <Typography variant="caption">{doctor.location}</Typography>
          </Stack>
          <Stack direction="row" alignItems="center" spacing={0.5}>
            <AccessTimeIcon sx={{ fontSize: 16 }} />
            <Typography variant="caption">
              {isAr ? doctor.availableAr : doctor.available}  {/* ← available مش availability */}
            </Typography>
          </Stack>
        </Stack>

        <Stack spacing={2} alignItems="center">
          <Typography variant="h5" fontWeight="900" color="text.primary">
            ${doctor.fee}  {/* ← fee مش price */}
          </Typography>

          <Button 
            variant="contained"
            fullWidth
            disableElevation
            onClick={() => navigate && navigate(`/doctors/${doctor.id}`)}
            sx={{ 
              borderRadius: 3, 
              textTransform: 'none', 
              color: 'white !important',
              fontWeight: 'bold',
              py: 1.2,
              background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
              '&:hover': { opacity: 0.9 }
            }}
          >
            {isAr ? 'احجز الآن' : 'Book Appointment'}
          </Button>
        </Stack>
      </CardContent>
    </Card>
  );
};

export default DoctorCard;