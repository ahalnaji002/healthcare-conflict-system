import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import {
  AppBar, Toolbar, Box, Button, IconButton, Avatar, Menu, MenuItem,
  Drawer, List, ListItem, ListItemText, Divider, Chip, useScrollTrigger,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import TranslateIcon from '@mui/icons-material/Translate';
import { logout } from '../../store/slices/authSlice';
import { setLanguage } from '../../store/slices/uiSlice';
import i18n from '../../i18n';
import AssignmentIcon from '@mui/icons-material/Assignment';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import BusinessIcon from '@mui/icons-material/Business';

import SettingsIcon from '@mui/icons-material/Settings';




import LoginIcon from '@mui/icons-material/Login';

import PersonIcon from '@mui/icons-material/Person';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import LogoutIcon from '@mui/icons-material/Logout';

const TeryaqLogo = () => (
  <Box
    sx={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}
    component={Link}
    to="/"
  >
    <img
      src="/logo.png"
      alt="Teryaq"
      style={{ height: 40, width: 25, objectFit: 'cover', display: 'block' }}
    />
    <span style={{ fontFamily: "'Sora', sans-serif", fontWeight: 700, fontSize: 22, color: '#188', marginLeft: 6 }}>
      Teryaq
    </span>
  </Box>
);

export default function Navbar() {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, user } = useSelector(s => s.auth);
  const { language } = useSelector(s => s.ui);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const trigger = useScrollTrigger({ disableHysteresis: true, threshold: 10 });

  const navLinks = [
    { label: t('nav.home'), path: '/' },
    { label: t('nav.findDoctors'), path: '/doctors' },
    { label: t('nav.myAppointments'), path: '/appointments' },
  ];

  const handleLangToggle = () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    dispatch(setLanguage(newLang));
    i18n.changeLanguage(newLang);
  };

  const handleLogout = () => {
    dispatch(logout());
    setAnchorEl(null);
    navigate('/');
  };

  const isActive = (path) => location.pathname === path;

  return (
    <>
      <AppBar
        position="fixed"
        elevation={trigger ? 2 : 0}
        sx={{
          background: trigger ? 'rgba(255,255,255,0.97)' : 'rgba(255,255,255,0.95)',
          backdropFilter: 'blur(12px)',
          borderBottom: trigger ? '1px solid #F1F5F9' : '1px solid transparent',
          transition: 'all 0.3s ease',
        }}
      >
        <Toolbar sx={{ maxWidth: 1200, mx: 'auto', width: '100%', px: { xs: 2, md: 3 }, minHeight: '68px !important' }}>
          <TeryaqLogo />

          {/* Desktop Nav */}
          <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 0.5, mx: 'auto' }}>
            {navLinks.map(link => (
              <Button
                key={link.path}
                component={Link}
                to={link.path}
                sx={{
                  color: isActive(link.path) ? '#0e7e78' : '#64748B',
                  fontWeight: isActive(link.path) ? 600 : 500,
                  fontSize: 15,
                  px: 2,
                  borderRadius: 2,
                  position: 'relative',
                  transition:"all 0.3s ease",
                  '&:hover': { color: '#0e7e78', background: '#F0F9FF' },
                  '&::after': isActive(link.path) ? {
                    content: '""', position: 'absolute', bottom: 4,
                    left: '50%', transform: 'translateX(-50%)',
                    width: 20, height: 2, borderRadius: 1,
                    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                  } : {},
                }}
              >
                {link.label}
              </Button>
            ))}
          </Box>

          {/* Right side AR */}
          <Box sx={{ display: { xs: 'none', md: 'flex' }, alignItems: 'center', gap: 1 }}>

            {/* <IconButton onClick={handleLangToggle} size="small"
              sx={{ color: '#0e7e78', border: '1px solid #0e7e78', borderRadius: 2, px: 1.5, py: 0.5, gap: 0.5 }}>
              <TranslateIcon sx={{ fontSize: 16 }} />
              <span style={{ fontSize: 13, fontWeight: 600 }}>{language === 'en' ? 'AR' : 'EN'}</span>
            </IconButton> */}

            {isAuthenticated ? (
              <>
                <IconButton onClick={e => setAnchorEl(e.currentTarget)} sx={{ p: 0.5 }}>
                  <Avatar sx={{ width: 36, height: 36, background: "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)", fontSize: 14, fontWeight: 700 }}>
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </Avatar>
                  <KeyboardArrowDownIcon sx={{ fontSize: 16, color: '#64748B', ml: 0.5 }} />
                </IconButton>
                <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}
                  PaperProps={{ sx: { borderRadius: 3, mt: 1, minWidth: 180, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' } }}>
                  {/* Dashboard link based on role */}
                  {user?.role === 'patient' && (
                    <MenuItem component={Link} to="/patient" onClick={() => setAnchorEl(null)} sx={{ gap: 1.5, py: 1.5 }}>
                      <span style={{ fontSize: 16 }}><AssignmentIcon sx={{color:"#188"}} /></span> {language === 'ar' ? 'لوحة المريض' : 'Patient Dashboard'}
                    </MenuItem>
                  )}
                  {user?.role === 'doctor' && (
                    <MenuItem component={Link} to="/doctor" onClick={() => setAnchorEl(null)} sx={{ gap: 1.5, py: 1.5 }}>
                      <span style={{ fontSize: 16 }}><LocalHospitalIcon sx={{color:"#188"}} />
                      </span> {language === 'ar' ? 'لوحة الطبيب' : 'Doctor Dashboard'}
                    </MenuItem>
                  )}
                  {user?.role === 'ngo' && (
                    <MenuItem component={Link} to="/ngo" onClick={() => setAnchorEl(null)} sx={{ gap: 1.5, py: 1.5 }}>
                      <span style={{ fontSize: 16 }}><BusinessIcon sx={{color:"#188"}} /></span> {language === 'ar' ? 'لوحة المنظمة' : 'NGO Dashboard'}
                    </MenuItem>
                  )}
                  {user?.role === 'admin' && (
                    <MenuItem component={Link} to="/admin" onClick={() => setAnchorEl(null)} sx={{ gap: 1.5, py: 1.5 }}>
                      <span style={{ fontSize: 16 }}><SettingsIcon sx={{color:"#188"}} /></span> {language === 'ar' ? 'لوحة الإدارة' : 'Admin Panel'}
                    </MenuItem>
                  )}
                  <MenuItem component={Link} to="/profile" onClick={() => setAnchorEl(null)} sx={{ gap: 1.5, py: 1.5 }}>
                   <PersonIcon sx={{color:"#188"}}/>  {t('nav.profile')}
                  </MenuItem>
                  {(user?.role === 'patient' || !user?.role) && (
                    <MenuItem component={Link} to="/appointments" onClick={() => setAnchorEl(null)} sx={{ gap: 1.5, py: 1.5 }}>
                      <CalendarMonthIcon sx={{color:"#188"}}/> {t('nav.myAppointments')}
                    </MenuItem>
                  )}
                  <Divider />
                  <MenuItem onClick={handleLogout} sx={{ gap: 1.5, py: 1.5, color: '#188' }}>
                    <LogoutIcon/> {t('nav.signOut')}
                  </MenuItem>
                </Menu>
              </>
            ) : (
              <>
                {/* sign in */}
                <Button component={Link} to="/login"
                startIcon={<LoginIcon />}
                  sx={{ color: '#64748B', fontWeight: 500,
                    transition:"all 0.3s ease",
                   '&:hover': { color: '#0e7e78' } }}>
                  {t('nav.signIn')}
                </Button>

                {/* ✅ Get Started — الزر بعد التعديل */}
                <Button component={Link} to="/register" variant="contained"
                  sx={{
                    borderRadius: 2.5, px: 2.5, py: 1, fontSize: 14,
                    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                    color:"white",
                    boxShadow: '0 4px 14px rgba(13,148,136,0.35)',
                    transition:"all 0.3s ease",
                    '&:hover': {
                      background: 'linear-gradient(90deg, #1e293b 0%, #0f766e 100%)',
                      transform: 'translateY(-1px)',
                    },
                  }}>
                  {t('nav.getStarted')}
                </Button>
              </>
            )}
          </Box>

          {/* Mobile menu icon */}
          <Box sx={{ display: { xs: 'flex', md: 'none' }, ml: 'auto', gap: 1 }}>

            {/* <IconButton onClick={handleLangToggle} size="small" sx={{ color: '#188' }}>
              <TranslateIcon sx={{ fontSize: 20 }} />
            </IconButton> */}

            <IconButton onClick={() => setMobileOpen(true)} sx={{ color: '#188' }}>

              <MenuIcon />
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Mobile Drawer */}
      <Drawer anchor="top" open={mobileOpen} onClose={() => setMobileOpen(false)}
        PaperProps={{ sx: { borderRadius: '0 0 20px 20px', pt: 1, pb: 3 } }}>
        <Box sx={{ px: 2, py: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <TeryaqLogo />
          <IconButton onClick={() => setMobileOpen(false)}><CloseIcon /></IconButton>
        </Box>
        <Divider sx={{ my: 1 }} />
        <List sx={{ px: 2 }}>
          {navLinks.map(link => (
            <ListItem key={link.path} component={Link} to={link.path}
              onClick={() => setMobileOpen(false)}
              sx={{
                borderRadius: 2, mb: 0.5,
                background: isActive(link.path) ? '#F0F9FF' : 'transparent',
                color: isActive(link.path) ? '#188' : '#0F172A',
              }}>
              <ListItemText primary={link.label} primaryTypographyProps={{ fontWeight: isActive(link.path) ? 600 : 400 }} />
            </ListItem>
          ))}
          {isAuthenticated && (
            <ListItem component={Link} to="/profile" onClick={() => setMobileOpen(false)} sx={{ borderRadius: 2 }}>
              <ListItemText primary={t('nav.profile')} />
            </ListItem>
          )}
        </List>
        <Box sx={{ px: 2, mt: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
          {isAuthenticated ? (
            <Button onClick={() => { handleLogout(); setMobileOpen(false); }}
              variant="outlined" color="error" fullWidth sx={{ borderRadius: 2 }}>
              {t('nav.signOut')}
            </Button>
          ) : (
            <>

             <Button
  startIcon={<LoginIcon sx={{ color: "#188" }} />}
  component={Link}
  to="/login"
  fullWidth
  onClick={() => setMobileOpen(false)}
  sx={{
    borderRadius: 2,

    // 🔥 النص gradient
    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    backgroundClip: 'text',

    // 🔹 مهم جداً
    border: '2px solid transparent',
    transition: 'all 0.3s ease',

    // ✅ hover الصحيح
    '&:hover': {
      border: '2px solid #188',
    },
  }}
>
  {t('nav.signIn')}
</Button>

              <Button component={Link} to="/register" variant="contained" fullWidth
                onClick={() => setMobileOpen(false)} sx={{ 
                  borderRadius: 2,
                  transition:"all 0.4s ease",
                   background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                   color:"white" }}>
                {t('nav.getStarted')}
              </Button>
            </>
          )}
        </Box>
      </Drawer>

      {/* Spacer */}
      <Toolbar sx={{ minHeight: '68px !important' }} />
    </>
  );
}