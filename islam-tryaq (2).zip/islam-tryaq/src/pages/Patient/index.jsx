import React, { useState } from 'react';
import {
  Box, Typography, Grid, Card, CardContent, Avatar, Chip, Button,
  LinearProgress, Divider, TextField, Dialog, DialogTitle, 
  DialogContent, DialogActions, CircularProgress
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import Layout from '../../components/layout/Layout';

// Icons
import MedicationIcon from '@mui/icons-material/Medication';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import ChatIcon from '@mui/icons-material/Chat';
import SosIcon from '@mui/icons-material/Sos';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import FavoriteIcon from '@mui/icons-material/Favorite';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import WaterDropIcon from '@mui/icons-material/WaterDrop';
import ThermostatIcon from '@mui/icons-material/Thermostat';
import AirIcon from '@mui/icons-material/Air';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import EmergencyIcon from '@mui/icons-material/Emergency';
import WavingHandIcon from '@mui/icons-material/WavingHand';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import DirectionsRunIcon from '@mui/icons-material/DirectionsRun';
import NotificationsIcon from '@mui/icons-material/Notifications';
import CheckIcon from '@mui/icons-material/Check';







// ─── Custom Styles ──────────────────────────────────────────────────────────
const themeStyles = {
  gradientBtn: {
    background: "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)",
    color: "white !important",
    textTransform: 'none',
    fontWeight: 700,
    borderRadius: 2.5,
    padding: '8px 20px',
    '&:hover': {
      opacity: 0.9,
      background: "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)",
    }
  },
  customInput: {
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: '#E2E8F0',
        borderWidth: '1px',
      },
      '&:hover fieldset': {
        borderColor: '#188',
        borderWidth: '2px',
      },
      '&.Mui-focused fieldset': {
        borderColor: '#0d9488',
      },
    },
    '& .MuiInputLabel-root.Mui-focused': {
      color: '#0d9488',
    }
  }
};

// ─── Mock Data ────────────────────────────────────────────────────────────────
const treatmentPlan = {
  doctor: { name: 'Dr. Sarah Mitchell', nameAr: 'د. سارة ميتشيل', specialty: 'Cardiology', image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop&crop=face' },
  diagnosis: 'Hypertension - Stage 1',
  diagnosisAr: 'ارتفاع ضغط الدم - المرحلة الأولى',
  medications: [
    { id: 1, name: 'Amlodipine 5mg', nameAr: 'أملوديبين 5 ملغ', time: '08:00 AM', taken: false, instructions: 'Take with water before meals', instructionsAr: 'تناول مع الماء قبل الأكل', color: '#0EA5E9' },
    { id: 2, name: 'Losartan 50mg', nameAr: 'لوسارتان 50 ملغ', time: '08:00 AM', taken: true, instructions: 'Take with or without food', instructionsAr: 'يمكن تناوله مع أو بدون طعام', color: '#14B8A6' },
  ],
  instructions: [
    { id: 1, text: 'Reduce salt intake to less than 2g/day', textAr: 'تقليل تناول الملح إلى أقل من 2 غرام/يوم', done: true },
    { id: 2, text: 'Walk 30 minutes daily', textAr: 'المشي 30 دقيقة يومياً', done: false },
  ],
};

// ─── Components ───────────────────────────────────────────────────────────────

const GradientText = ({ children, sx = {} }) => (
  <Box component="span" sx={{
    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
    WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
    backgroundClip: 'text', display: 'inline-block', ...sx,
  }}>{children}</Box>
);

function TreatmentPlanCard({ plan, lang }) {
  const [meds, setMeds] = useState(plan.medications);
  const toggleMed = (id) => setMeds(meds.map(m => m.id === id ? { ...m, taken: !m.taken } : m));
  const takenCount = meds.filter(m => m.taken).length;

  return (
    <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 12px rgba(0,0,0,0.05)' }}>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
          <Avatar src={plan.doctor.image} sx={{ width: 52, height: 52, borderRadius: 2.5 }} />
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 15 }}>{lang === 'ar' ? plan.doctor.nameAr : plan.doctor.name}</Typography>
            <Typography sx={{ color: '#14B8A6', fontSize: 13, fontWeight: 600 }}>{plan.doctor.specialty}</Typography>
          </Box>
          <Chip label={lang === 'ar' ? plan.diagnosisAr : plan.diagnosis} sx={{ background: '#FEF2F2', color: '#DC2626', fontWeight: 600, fontSize: 11 }} />
        </Box>

        <Box sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 14 }}> <MedicationIcon sx={{color:"#188"}}/> {lang === 'ar' ? 'أدوية اليوم' : "Today's Medications"}</Typography>
            <Chip label={`${takenCount}/${meds.length}`} size="small" />
          </Box>
          <LinearProgress variant="determinate" value={(takenCount / meds.length) * 100} sx={{ height: 6, borderRadius: 3, mb: 2 ,'& .MuiLinearProgress-bar': { background: 'linear-gradient(90deg, #0f172a 0%, #14B8A6 100%)'  }}} />
          {meds.map(med => (
            <Box key={med.id} onClick={() => toggleMed(med.id)} sx={{
              display: 'flex', alignItems: 'center', gap: 2, p: 1.5, borderRadius: 2.5,
              border: `1px solid ${med.taken ? '#D1FAE5' : '#F1F5F9'}`,
              background: med.taken ? '#F0FDF4' : 'white', mb: 1, cursor: 'pointer'
            }}>
              {med.taken ? <CheckCircleIcon sx={{ color: '#22C55E' }} /> : <RadioButtonUncheckedIcon sx={{ color: '#CBD5E1' }} />}
              <Box sx={{ flex: 1 }}>
                <Typography sx={{ fontWeight: 600, fontSize: 13.5, textDecoration: med.taken ? 'line-through' : 'none' }}>
                  {lang === 'ar' ? med.nameAr : med.name}
                </Typography>
                <Typography sx={{ color: '#94A3B8', fontSize: 11.5 }}>{lang === 'ar' ? med.instructionsAr : med.instructions}</Typography>
              </Box>
              <Chip label={med.time} size="small" sx={{ background: `${med.color}15`, color: med.color }} />
            </Box>
          ))}
        </Box>
      </CardContent>
    </Card>
  );
}

function HealthTrackingCard({ lang }) {
  const [logOpen, setLogOpen] = useState(false);
  const vitals = { bp: '132/84', pulse: 74, temp: 36.8, oxygen: 98 };

  return (
    <>
      <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 12px rgba(0,0,0,0.05)' }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2.5 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <TrendingUpIcon sx={{ color: '#14B8A6' }} />
              <Typography sx={{ fontWeight: 700, fontSize: 16 }}>{lang === 'ar' ? 'متابعة الحالة الصحية' : 'Health Tracking'}</Typography>
            </Box>
            <Button size="small" startIcon={<AddCircleIcon />} onClick={() => setLogOpen(true)} sx={{ fontWeight: 700, color: '#188' }}>
              {lang === 'ar' ? 'تسجيل جديد' : 'New Log'}
            </Button>
          </Box>

          <Grid container spacing={1.5}>
            {[
              { icon: <WaterDropIcon />, label: lang === 'ar' ? 'الضغط' : 'BP', value: vitals.bp, color: '#EF4444', bg: '#FEF2F2' },
              { icon: <FavoriteIcon />, label: lang === 'ar' ? 'النبض' : 'Pulse', value: vitals.pulse, color: '#F59E0B', bg: '#FFFBEB' },
              { icon: <ThermostatIcon />, label: lang === 'ar' ? 'الحرارة' : 'Temp', value: vitals.temp, color: '#8B5CF6', bg: '#F5F3FF' },
              { icon: <AirIcon />, label: lang === 'ar' ? 'الأكسجين' : 'Oxygen', value: `${vitals.oxygen}%`, color: '#0EA5E9', bg: '#F0F9FF' },
            ].map((v, i) => (
              <Grid item xs={6} sm={3} key={i}>
                <Box sx={{ p: 1.5, borderRadius: 2.5, background: v.bg, border: `1px solid ${v.color}20`, textAlign: 'center' }}>
                  <Typography sx={{ fontSize: 11, fontWeight: 600, color: v.color }}>{v.label}</Typography>
                  <Typography sx={{ fontSize: 18, fontWeight: 800 }}>{v.value}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      <Dialog open={logOpen} onClose={() => setLogOpen(false)} PaperProps={{ sx: { borderRadius: 3.5, minWidth: { xs: '90%', sm: 500 } } }}>
        <DialogTitle sx={{ fontWeight: 700 }}>{lang === 'ar' ? 'إضافة قراءات جديدة' : 'Add New Vitals'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={6}><TextField fullWidth label={lang === 'ar' ? 'ضغط الدم' : 'BP'} sx={themeStyles.customInput} /></Grid>
            <Grid item xs={6}><TextField fullWidth label={lang === 'ar' ? 'النبض' : 'Pulse'} sx={themeStyles.customInput} /></Grid>
            <Grid item xs={6}><TextField fullWidth label={lang === 'ar' ? 'الحرارة' : 'Temp'} sx={themeStyles.customInput} /></Grid>
            <Grid item xs={6}><TextField fullWidth label={lang === 'ar' ? 'الأكسجين' : 'Oxygen'} sx={themeStyles.customInput} /></Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={() => setLogOpen(false)} sx={{ color: '#64748B' }}>{lang === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
          <Button variant="contained" sx={themeStyles.gradientBtn} onClick={() => setLogOpen(false)}>{lang === 'ar' ? 'حفظ' : 'Save'}</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

function HelpRequestCard({ lang }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleRequest = () => {
    setLoading(true);
    // محاكاة إرسال الطلب
    setTimeout(() => {
      setLoading(false);
      setSent(true);
      // إغلاق النافذة بعد ثانيتين من النجاح
      setTimeout(() => { 
        setSent(false); 
        setOpen(false); 
      }, 2000);
    }, 1500);
  };

  return (
    <>
      <Card sx={{ borderRadius: 3.5, background: 'linear-gradient(135deg, #FEF2F2 0%, #FFF7ED 100%)', border: '1px solid #FEE2E2' }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
            <SosIcon sx={{ color: '#EF4444' }} />
            <Typography sx={{ fontWeight: 700, fontSize: 16 }}>{lang === 'ar' ? 'طلب مساعدة' : 'Request Help'}</Typography>
          </Box>
          <Button fullWidth variant="contained" onClick={() => setOpen(true)} sx={themeStyles.gradientBtn}>
            <EmergencyIcon sx={{ mr: 1 }} />
            {lang === 'ar' ? 'اطلب الآن' : 'Request Now'}
          </Button>
        </CardContent>
      </Card>

      {/* الـ Dialog المضاف حديثاً لطلب المساعدة */}
      <Dialog 
        open={open} 
        onClose={() => !loading && setOpen(false)} 
        PaperProps={{ sx: { borderRadius: 4, minWidth: { xs: '90%', sm: 400 } } }}
      >
        <DialogTitle sx={{ textAlign: 'center', fontWeight: 800, pt: 3 }}>
          {sent ? (
            <CheckCircleIcon sx={{ color: '#22C55E', fontSize: 60 }} />
          ) : (
            <EmergencyIcon sx={{ color: '#EF4444', fontSize: 60 }} />
          )}
          <Box sx={{ mt: 1 }}>
            {sent ? (lang === 'ar' ? 'تم الإرسال بنجاح' : 'Sent Successfully') : (lang === 'ar' ? 'تأكيد طلب المساعدة' : 'Confirm Help Request')}
          </Box>
        </DialogTitle>
        <DialogContent sx={{ textAlign: 'center' }}>
          <Typography sx={{ color: '#64748B' }}>
            {sent 
              ? (lang === 'ar' ? 'سيقوم الطاقم الطبي بالتواصل معك فوراً.' : 'Medical staff will contact you immediately.') 
              : (lang === 'ar' ? 'هل أنت متأكد من إرسال نداء استغاثة للطاقم الطبي المناوب؟' : 'Are you sure you want to send an emergency alert to the staff on duty?')}
          </Typography>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 3, px: 3 }}>
          {!sent && (
            <>
              <Button 
                onClick={() => setOpen(false)} 
                disabled={loading}
                sx={{ color: '#64748B', fontWeight: 600 }}
              >
                {lang === 'ar' ? 'إلغاء' : 'Cancel'}
              </Button>
              <Button 
                variant="contained" 
                onClick={handleRequest} 
                disabled={loading}
                sx={{ 
                  background: '#EF4444', 
                  color: 'white',
                  borderRadius: 2,
                  px: 4,
                  fontWeight: 700,
                  '&:hover': { background: '#DC2626' }
                }}
              >
                {loading ? <CircularProgress size={24} color="inherit" /> : (lang === 'ar' ? 'تأكيد الطلب' : 'Confirm')}
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
}

// ─── Reminders Card ──────────────────────────────────────────────────────────
const initialReminders = [
  { id: 1, type: 'medication', title: 'Amlodipine 5mg', titleAr: 'أملوديبين 5 ملغ', time: '08:00 AM', timeValue: '08:00', done: false, color: '#0EA5E9', recurring: 'daily' },
  { id: 2, type: 'medication', title: 'Losartan 50mg', titleAr: 'لوسارتان 50 ملغ', time: '08:00 AM', timeValue: '08:00', done: true, color: '#14B8A6', recurring: 'daily' },
  { id: 3, type: 'appointment', title: 'Dr. Sarah – Follow-up', titleAr: 'د. سارة – متابعة', time: '10:30 AM', timeValue: '10:30', done: false, color: '#8B5CF6', recurring: 'once' },
  { id: 4, type: 'exercise', title: 'Walk 30 minutes', titleAr: 'المشي 30 دقيقة', time: '06:00 PM', timeValue: '18:00', done: false, color: '#22C55E', recurring: 'daily' },
];

const reminderTypeIcons = { 
  medication: <MedicationIcon />, 
  appointment: <CalendarMonthIcon />, 
  exercise: <DirectionsRunIcon /> 
};


function RemindersCard({ lang }) {
  const [reminders, setReminders] = useState(initialReminders);
  const [addOpen, setAddOpen] = useState(false);
  const [snackMsg, setSnackMsg] = useState('');
  const [newR, setNewR] = useState({ title: '', time: '08:00', type: 'medication', recurring: 'daily' });
  const [notifEnabled, setNotifEnabled] = useState(true);

  const toggle = (id) => {
    setReminders(r => r.map(x => x.id === id ? { ...x, done: !x.done } : x));
  };
  const deleteR = (id) => setReminders(r => r.filter(x => x.id !== id));

  const addReminder = () => {
    if (!newR.title.trim()) return;
    const colors = { medication: '#0EA5E9', appointment: '#8B5CF6', exercise: '#22C55E' };
    const [h, m] = newR.time.split(':');
    const hr = parseInt(h);
    const ampm = hr >= 12 ? 'PM' : 'AM';
    const displayHr = hr > 12 ? hr - 12 : hr === 0 ? 12 : hr;
    const timeDisplay = `${displayHr}:${m} ${ampm}`;
    setReminders(r => [...r, {
      id: Date.now(), type: newR.type,
      title: newR.title, titleAr: newR.title,
      time: timeDisplay, timeValue: newR.time,
      done: false, color: colors[newR.type], recurring: newR.recurring
    }]);
    setSnackMsg(lang === 'ar' ? 'تم إضافة التذكير!' : 'Reminder added!');
    setNewR({ title: '', time: '08:00', type: 'medication', recurring: 'daily' });
    setAddOpen(false);
  };

  const doneCount = reminders.filter(r => r.done).length;

  return (
    <>
      <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 12px rgba(0,0,0,0.05)' }}>
        <CardContent sx={{ p: 3 }}>
          {/* Header */}
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <MedicationIcon sx={{ color: '#14B8A6', fontSize: 20 }} />
              <Typography sx={{ fontWeight: 700, fontSize: 16 }}>
                {lang === 'ar' ? 'تذكيراتي' : 'My Reminders'}
              </Typography>
              <Chip label={`${doneCount}/${reminders.length}`} size="small"
                sx={{ background: '#F0FDF4', color: '#15803D', fontWeight: 700, fontSize: 11, height: 20 }} />
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography sx={{ fontSize: 11, color: '#94A3B8' }}>
                  {lang === 'ar' ? 'إشعارات' : 'Notify'}
                </Typography>
                <Box
                  onClick={() => setNotifEnabled(v => !v)}
                  sx={{
                    width: 32, height: 18, borderRadius: 9, cursor: 'pointer', transition: 'background 0.2s',
                    background: notifEnabled ? '#14B8A6' : '#CBD5E1', position: 'relative'
                  }}
                >
                  <Box sx={{
                    position: 'absolute', top: 2, left: notifEnabled ? 16 : 2,
                    width: 14, height: 14, borderRadius: '50%', background: 'white',
                    transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                  }} />
                </Box>
              </Box>
              <Button size="small" startIcon={<AddCircleIcon sx={{ fontSize: 16 }} />}
                onClick={() => setAddOpen(true)}
                sx={{ fontWeight: 700, color: '#188', fontSize: 12, textTransform: 'none', minWidth: 0, px: 1 }}>
                {lang === 'ar' ? 'إضافة' : 'Add'}
              </Button>
            </Box>
          </Box>

          {/* Progress bar */}
          <LinearProgress variant="determinate" value={(doneCount / Math.max(reminders.length, 1)) * 100}
            sx={{ height: 5, borderRadius: 3, mb: 2, '& .MuiLinearProgress-bar': { background: 'linear-gradient(90deg, #0f172a 0%, #14B8A6 100%)' } }} />

          {/* Reminders list */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {reminders.length === 0 && (
              <Typography sx={{ fontSize: 13, color: '#94A3B8', textAlign: 'center', py: 2 }}>
                {lang === 'ar' ? 'لا توجد تذكيرات. أضف واحدة!' : 'No reminders yet. Add one!'}
              </Typography>
            )}
            {reminders.map(r => (
              <Box key={r.id} sx={{
                display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, borderRadius: 2.5,
                border: `1px solid ${r.done ? '#D1FAE5' : '#F1F5F9'}`,
                background: r.done ? '#F0FDF4' : 'white', cursor: 'pointer',
                transition: 'all 0.2s', '&:hover': { boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }
              }}>
                <Box onClick={() => toggle(r.id)} sx={{ flexShrink: 0 }}>
                  {r.done
                    ? <CheckCircleIcon sx={{ color: '#22C55E', fontSize: 20 }} />
                    : <RadioButtonUncheckedIcon sx={{ color: '#CBD5E1', fontSize: 20 }} />}
                </Box>
                <Typography sx={{ fontSize: 16, flexShrink: 0 }}>{reminderTypeIcons[r.type]}</Typography>
                <Box sx={{ flex: 1, minWidth: 0 }} onClick={() => toggle(r.id)}>
                  <Typography sx={{ fontWeight: 600, fontSize: 13, textDecoration: r.done ? 'line-through' : 'none', color: r.done ? '#94A3B8' : '#0F172A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {lang === 'ar' ? r.titleAr : r.title}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <Typography sx={{ fontSize: 11, color: '#94A3B8' }}>{r.time}</Typography>
                    {r.recurring === 'daily' && (
                      <Chip label={lang === 'ar' ? 'يومي' : 'daily'} size="small"
                        sx={{ height: 14, fontSize: 9, background: `${r.color}15`, color: r.color, fontWeight: 600 }} />
                    )}
                  </Box>
                </Box>
                <Box onClick={() => deleteR(r.id)} sx={{ flexShrink: 0, color: '#CBD5E1', cursor: 'pointer', '&:hover': { color: '#EF4444' }, fontSize: 16 }}>✕</Box>
              </Box>
            ))}
          </Box>

          {/* Notification banner */}
          {notifEnabled && (
            <Box sx={{ mt: 2, p: 1.5, borderRadius: 2, background: '#F0FDF4', border: '1px solid #D1FAE5', display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography sx={{ fontSize: 14 }}><NotificationsIcon sx={{color:"#188"}}/></Typography>
              <Typography sx={{ fontSize: 12, color: '#15803D', fontWeight: 600 }}>
                {lang === 'ar' ? 'الإشعارات مفعّلة – ستصلك تنبيهات في الوقت المحدد' : "Notifications ON – You'll be alerted at the set times"}
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Add Reminder Dialog */}
      <Dialog open={addOpen} onClose={() => setAddOpen(false)}
        PaperProps={{ sx: { borderRadius: 3.5, minWidth: { xs: '90%', sm: 420 } } }}>
        <DialogTitle sx={{ fontWeight: 700 }}>{lang === 'ar' ? 'إضافة تذكير جديد' : 'Add New Reminder'}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
            <TextField fullWidth label={lang === 'ar' ? 'العنوان' : 'Title'}
              value={newR.title} onChange={e => setNewR({ ...newR, title: e.target.value })}
              sx={themeStyles.customInput} />
            <TextField fullWidth type="time" label={lang === 'ar' ? 'الوقت' : 'Time'}
              value={newR.time} onChange={e => setNewR({ ...newR, time: e.target.value })}
              InputLabelProps={{ shrink: true }} sx={themeStyles.customInput} />

           <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
  {['medication', 'appointment', 'exercise'].map((t) => (
    <Chip
      key={t}
      clickable
      // الأيقونة توضع هنا فقط
      icon={reminderTypeIcons[t]} 
      // الـ label يجب أن يكون نصاً صافياً (String) فقط
      label={lang === 'ar' ? { medication: 'دواء', appointment: 'موعد', exercise: 'رياضة' }[t] : t}
      onClick={() => setNewR({ ...newR, type: t })}
      sx={{
        fontWeight: 600,
        background: newR.type === t ? '#0d9488' : '#F1F5F9',
        color: newR.type === t ? 'white' : '#0F172A',
        // لتغيير لون الأيقونة حسب حالة التحديد
        '& .MuiChip-icon': {
          color: newR.type === t ? 'white !important' : '#188',
        },
      }}
    />
  ))}
</Box>

            <Box sx={{ display: 'flex', gap: 1 }}>
              {['daily', 'weekly', 'once'].map(r => (
                <Chip key={r} clickable label={lang === 'ar' ? { daily: 'يومي', weekly: 'أسبوعي', once: 'مرة' }[r] : r}
                  onClick={() => setNewR({ ...newR, recurring: r })}
                  sx={{ fontWeight: 600, background: newR.recurring === r ? '#188' : '#F1F5F9', color: newR.recurring === r ? 'white' : '#0F172A' }} />
              ))}
            </Box>
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={() => setAddOpen(false)} sx={{ color: '#188' }}>{lang === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
          <Button variant="contained"  onClick={addReminder} disabled={!newR.title.trim()} sx={themeStyles.gradientBtn } >
            {lang === 'ar' ? 'إضافة' : 'Add'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      {snackMsg && (
        <Box sx={{
          position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', zIndex: 9999,
          background: '#0f172a', color: 'white', px: 3, py: 1.5, borderRadius: 2.5,
          fontSize: 14, fontWeight: 600, boxShadow: '0 4px 20px rgba(0,0,0,0.2)'
        }}
          onClick={() => setSnackMsg('')}>
          <CheckIcon sx={{color:"#188"}}/> {snackMsg}
        </Box>
      )}
    </>
  );
}

// ─── Main Patient Dashboard ───────────────────────────────────────────────────
export default function PatientDashboard() {
  const { user } = useSelector(s => s.auth);
  const navigate = useNavigate();
  const { language } = useSelector(s => s.ui);
  const lang = language || 'en';

  return (
    <Layout>
  <Box sx={{ background: '#F8FAFC', minHeight: '100vh', pt: { xs: 9, md: 10 }, pb: 6 , display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'}} >
    <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, md: 4 } }}>
      
      {/* Header Section - بدون تغيير */}
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 800 }}>
            <GradientText>{lang === 'ar' ? 'مرحباً' : 'Welcome'}, {user?.firstName || 'Patient'} <WavingHandIcon sx={{ color: "#188" }} /></GradientText>
          </Typography>
          <Typography sx={{ color: '#64748B' }}>{lang === 'ar' ? 'ملخص حالتك الصحية' : "Your health summary"}</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1.5 }}>
          <Button variant="outlined" startIcon={<ChatIcon />} onClick={() => navigate('/chat/1')} sx={{ borderRadius: 2.5, borderColor: '#14B8A6', color: '#14B8A6' }}>
            {lang === 'ar' ? 'مراسلة' : 'Chat'}
          </Button>
          <Button variant="contained" startIcon={<VideoCallIcon />} sx={themeStyles.gradientBtn} onClick={() => navigate('/video/1')}>
            {lang === 'ar' ? 'مكالمة فيديو' : 'Video Call'}
          </Button>
        </Box>
      </Box>

      {/* Grid Container - التعديل هنا */}
      <Grid container spacing={3}>
        
        {/* العمود الأيسر (العريض) */}
        <Grid item xs={12} lg={7}>
          {/* نستخدم Box مع gap لترتيب الكرتين فوق بعض */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <TreatmentPlanCard plan={treatmentPlan} lang={lang} />
            {/* نقلنا HealthTrackingCard إلى هنا ليصبح فوق/أعلى */}
            <HealthTrackingCard lang={lang} />
          </Box>
        </Grid>

        {/* العمود الأيمن (الجانبي) */}
        <Grid item xs={12} lg={5}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <HelpRequestCard lang={lang} />
            <RemindersCard lang={lang} />
          </Box>
        </Grid>

        {/* تم حذف الـ Grid item اللي كان تحت هنا لرفع المتابعة الصحية */}
      </Grid>

    </Box>
  </Box>
</Layout>
  );
}