import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, Grid, Container, Avatar, Chip, List, ListItem, ListItemIcon, ListItemText, Button } from '@mui/material';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import DescriptionIcon from '@mui/icons-material/Description';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import EditIcon from '@mui/icons-material/Edit';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SecurityIcon from '@mui/icons-material/Security';
import SettingsIcon from '@mui/icons-material/Settings';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import Layout from '../../components/layout/Layout';
import { prescriptions } from '../../data/mockData';

import AlarmIcon from '@mui/icons-material/Alarm';
import ForumOutlinedIcon from '@mui/icons-material/ForumOutlined';

export default function Profile() {
  const { user } = useSelector(s => s.auth);
  const { list } = useSelector(s => s.appointments);
  const { t } = useTranslation();
  const navigate = useNavigate();

  // اللون المعتمد للبراند
  const brandColor = '#0d9488';
  const brandGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';

  const stats = [
    { icon: <CalendarMonthIcon sx={{ color: brandColor, fontSize: 28 }} />, value: list.length, label: t('profile.appointments') },
    { icon: <DescriptionIcon sx={{ color: brandColor, fontSize: 28 }} />, value: prescriptions.length, label: t('profile.prescriptions') },
    { icon: <VideoCallIcon sx={{ color: brandColor, fontSize: 28 }} />, value: list.filter(a => a.status === 'completed').length + 13, label: t('profile.consultations') },
  ];

  const upcoming = list.filter(a => a.status === 'confirmed' || a.status === 'pending').slice(0, 2);

  const quickActions = [
    { icon: <EditIcon sx={{ fontSize: 18 }} />, label: t('profile.editProfile') },
    { icon: <NotificationsIcon sx={{ fontSize: 18 }} />, label: t('profile.notifications') },
    { icon: <SecurityIcon sx={{ fontSize: 18 }} />, label: t('profile.privacySecurity') },
    { icon: <SettingsIcon sx={{ fontSize: 18 }} />, label: t('profile.settings') },
  ];

  const prescriptionStatusColor = { active: '#15803D', completed: '#64748B' };

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', py: { xs: 4, md: 5 } }}>
        <Container maxWidth="lg">
          <Grid container spacing={3} justifyContent="center"> {/* التوسيط للـ Grid */}
            
            {/* Left sidebar */}
            <Grid item xs={12} md={4} lg={3.5}>
              <Box sx={{ background: 'white', borderRadius: 4, border: '1px solid #F1F5F9', overflow: 'hidden', mb: 2, textAlign: 'center' }}>
                {/* تعديل تدرج خلفية الهيدر */}
                <Box sx={{ height: 80, background: brandGradient }} />
                
                <Box sx={{ px: 3, pb: 3, display: 'flex', flexDirection: 'column', alignItems: 'center' }}> {/* التوسيط للأفاتار والنصوص */}
                  <Avatar sx={{
                    width: 72, height: 72, mt: -4.5, mb: 2,
                    background: brandGradient,
                    fontSize: 24, fontWeight: 800,
                    border: '4px solid white', boxShadow: '0 4px 14px rgba(13,148,136,0.3)',
                  }}>
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </Avatar>
                  <Typography sx={{ fontWeight: 800, fontSize: 18, color: '#0F172A', mb: 0.3 }}>
                    {user?.firstName} {user?.lastName}
                  </Typography>
                  <Typography sx={{ color: '#94A3B8', fontSize: 13, mb: 2.5 }}>
                    Patient ID: {user?.id || 'TRQ-2024-0847'}
                  </Typography>

                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.2, width: '100%', alignItems: 'center' }}>
                    {[
                      { icon: <EmailIcon sx={{ fontSize: 14 }} />, text: user?.email || 'john.doe@email.com' },
                      { icon: <PhoneIcon sx={{ fontSize: 14 }} />, text: '+1 (555) 987-6543' },
                      { icon: <LocationOnIcon sx={{ fontSize: 14 }} />, text: 'New York, USA' },
                    ].map((item, i) => (
                      <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1, color: '#64748B', fontSize: 13 }}>
                        {item.icon} {item.text}
                      </Box>
                    ))}
                  </Box>
                </Box>
              </Box>

              {/* Quick Actions */}
              <Box sx={{ background: 'white', borderRadius: 4, border: '1px solid #F1F5F9', p: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A', px: 1, mb: 1, textAlign: {xs: 'center', md: 'left'} }}>
                  {t('profile.quickActions')}
                </Typography>
                <List dense>
                  {quickActions.map((a, i) => (
                    <ListItem key={i} button sx={{ borderRadius: 2, mb: 0.5, '&:hover': { background: '#F0FDF4', color: brandColor } }}>
                      <ListItemIcon sx={{ minWidth: 34, color: '#64748B' }}>{a.icon}</ListItemIcon>
                      <ListItemText primary={a.label} primaryTypographyProps={{ fontSize: 14, fontWeight: 500 }} />
                    </ListItem>
                  ))}
                </List>
              </Box>
            </Grid>

            {/* Right content */}
            <Grid item xs={12} md={8} lg={8.5}>
              {/* Stats */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                {stats.map((s, i) => (
                  <Grid item xs={4} key={i}>
                    <Box sx={{ 
                      background: 'white', borderRadius: 3, p: 2.5, textAlign: 'center', border: '1px solid #F1F5F9',
                      transition: '0.3s', '&:hover': { transform: 'translateY(-5px)', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }
                    }}>
                      <Box sx={{ display: 'flex', justifyContent: 'center', mb: 1 }}>{s.icon}</Box>
                      <Typography sx={{ fontSize: 28, fontWeight: 800, color: '#0F172A', lineHeight: 1 }}>{s.value}</Typography>
                      <Typography sx={{ fontSize: 12, color: '#94A3B8', mt: 0.8, fontWeight: 500 }}>{s.label}</Typography>
                    </Box>
                  </Grid>
                ))}
              </Grid>

              {/* Upcoming Appointments */}
              <Box sx={{ background: 'white', borderRadius: 4, border: '1px solid #F1F5F9', p: 3, mb: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2.5 }}>
                  <Typography sx={{ fontWeight: 700, fontSize: 16, color: '#0F172A' }}>{t('profile.upcomingAppointments')}</Typography>
                  <Button size="small" onClick={() => navigate('/appointments')} sx={{ color: brandColor, fontWeight: 700, fontSize: 13 }}>
                    {t('profile.viewAll')}
                  </Button>
                </Box>
                {upcoming.length === 0 ? (
                  <Typography sx={{ color: '#94A3B8', fontSize: 14, textAlign: 'center', py: 2 }}>No upcoming appointments</Typography>
                ) : (
                  upcoming.map(appt => (
                    <Box key={appt.id} sx={{ display: 'flex', alignItems: 'center', gap: 2, py: 2, borderBottom: '1px solid #F8FAFC' }}>
                      <Box sx={{
                        width: 42, height: 42, borderRadius: 2, display: 'flex', alignItems: 'center', justifyContent: 'center',
                        background: '#F0FDF4',
                      }}>
                        {appt.type === 'video' ? <VideoCallIcon sx={{ color: brandColor, fontSize: 20 }} /> : <Box sx={{ fontSize: 18 }}>
                          <ForumOutlinedIcon sx={{color:"#188"}} />
                          </Box>}
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{appt.doctor}</Typography>
                        <Typography sx={{ fontSize: 12, color: '#64748B' }}>{appt.specialty}</Typography>
                      </Box>
                      <Box sx={{ textAlign: 'right' }}>
                        <Typography sx={{ fontSize: 13, fontWeight: 700, color: '#0F172A' }}>{appt.date}</Typography>
                        <Typography sx={{ fontSize: 12, color: '#94A3B8' }}><AlarmIcon sx={{color:"#188",fontSize:"20px",mr:1}}/>{appt.time}</Typography>
                      </Box>
                    </Box>
                  ))
                )}
              </Box>

              {/* Prescriptions */}
              <Box sx={{ background: 'white', borderRadius: 4, border: '1px solid #F1F5F9', p: 3 }}>
                <Typography sx={{ fontWeight: 700, fontSize: 16, color: '#0F172A', mb: 2.5 }}>{t('profile.myPrescriptions')}</Typography>
                {prescriptions.map(rx => (
                  <Box key={rx.id} sx={{ display: 'flex', alignItems: 'center', gap: 2, py: 2, borderBottom: '1px solid #F8FAFC', '&:last-child': { borderBottom: 0 } }}>
                    <Box sx={{ 
                      width: 40, height: 40, borderRadius: 2, 
                      background: brandGradient, // استخدام التدرج الجديد للأيقونات
                      display: 'flex', alignItems: 'center', justifyContent: 'center' 
                    }}>
                      <DescriptionIcon sx={{ color: 'white', fontSize: 18 }} />
                    </Box>
                    <Box sx={{ flex: 1 }}>
                      <Typography sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{rx.name}</Typography>
                      <Typography sx={{ fontSize: 12, color: '#64748B' }}>by {rx.doctor} · {rx.date}</Typography>
                    </Box>
                    <Chip label={rx.status === 'active' ? t('profile.active') : t('profile.completed')} size="small"
                      sx={{
                        background: rx.status === 'active' ? '#DCFCE7' : '#F1F5F9',
                        color: prescriptionStatusColor[rx.status],
                        fontWeight: 700, fontSize: 11, borderRadius: 1.5, height: 24,
                      }} />
                  </Box>
                ))}
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Layout>
  );
}