import React, { useState, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Box, Typography, TextField, Grid, Chip, Container, InputAdornment, IconButton, Drawer, Slider, FormControlLabel, Checkbox, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import TuneIcon from '@mui/icons-material/Tune';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import Layout from '../../components/layout/Layout';
import DoctorCard from '../../components/common/DoctorCard';
import { doctors, specialties } from '../../data/mockData';


export default function FindDoctors() {

  const { t } = useTranslation();
  const { language } = useSelector(s => s.ui);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [activeSpecialty, setActiveSpecialty] = useState(searchParams.get('specialty') || 'all');
  const [filterOpen, setFilterOpen] = useState(false);
  const [maxFee, setMaxFee] = useState(200);

  const filtered = useMemo(() => {
    return doctors.filter(d => {
      const name = language === 'ar' ? d.nameAr : d.name;
      const spec = language === 'ar' ? d.specialtyAr : d.specialty;
      const matchQuery = !query || name.toLowerCase().includes(query.toLowerCase()) || spec.toLowerCase().includes(query.toLowerCase());
      const matchSpec = activeSpecialty === 'all' || d.specialtyKey === activeSpecialty;
      const matchFee = d.fee <= maxFee;
      return matchQuery && matchSpec && matchFee;
    });
  }, [query, activeSpecialty, maxFee, language]);

  const specTabs = [{ key: 'all', label: language === 'ar' ? 'الكل' : 'All' }, ...specialties.map(s => ({ key: s.key, label: t(`specialties.${s.key}`) }))];

  return (

    <Layout>


      <Box sx={{ background: 'linear-gradient(160deg, #F0F9FF 0%, #F8FAFC 100%)', py: { xs: 4, md: 6 } }}>

        <Container maxWidth="lg">

          <Typography variant="h3" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 1, fontSize: { xs: 26, md: 36 }  }}>

            {t('doctors.title')}
          </Typography>

          <Typography sx={{ color: '#64748B', fontSize: 16, mb: 4 }}>{t('doctors.subtitle')}</Typography>


          {/* Search bar */}
          <Box sx={{ display: 'flex', gap: 2, mb: 4 }}>
            <TextField
             sx={{
    '& .MuiOutlinedInput-root': {
      borderRadius: '40px',
      '& fieldset': {
        borderColor: '#ccc',
      },
      '&:hover fieldset': {
        borderColor: '#ccc',
      },
      '&.Mui-focused fieldset': {
        borderColor: '#0d9488',
        borderWidth: '2px',
      },
    },
  }}
              fullWidth value={query} onChange={e => setQuery(e.target.value)}
              placeholder={t('doctors.search')}
              InputProps={{
                startAdornment: <InputAdornment position="start"><SearchIcon sx={{ color: '#188' }} /></InputAdornment>,
                sx: { borderRadius: 3, background: 'white', fontSize: 15 },
              }}
            />

            <IconButton onClick={() => setFilterOpen(true)}
              sx={{ background: 'white', border: '1px solid #E2E8F0', borderRadius: 2, px: 2, color: '#188', '&:hover': { borderColor: '#188', color: '#188' } }}>
              <TuneIcon />
            </IconButton>
          </Box>



          {/* Specialty chips */}
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', mb: 3 }}>
            {specTabs.map(sp => (
              <Chip key={sp.key} label={sp.label} clickable
                onClick={() => setActiveSpecialty(sp.key)}
                sx={{
                  fontWeight: 600, fontSize: 13, borderRadius: 2,
                  background: activeSpecialty === sp.key ? 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)' : 'white',
                  color: activeSpecialty === sp.key ? 'white' : '#64748B',
                  border: activeSpecialty === sp.key ? 'none' : '1px solid #E2E8F0',
                  '&:hover': { background: activeSpecialty === sp.key ? undefined : '#F0F9FF' },
                }}
              />
            ))}
          </Box>

          

          <Typography sx={{  fontSize: 14, mb: 3 , background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',}}>
            <strong style={{ color: '#0F172A' }}>{filtered.length}</strong> {t('doctors.found')}
          </Typography>

          <Grid container spacing={3}>
            {filtered.map(doc => (
              <Grid item xs={12} sm={6} md={4} key={doc.id}>
                <DoctorCard doctor={doc} language={language} navigate={navigate} />
              </Grid>
            ))}
          </Grid>

          {filtered.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <Typography sx={{ fontSize: 48, mb: 2 }}>
                <SearchIcon sx={{fontSize:"70px"}}/>
              </Typography>
              <Typography variant="h6" sx={{ background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 1 }}>No doctors found</Typography>
              <Typography sx={{ color: '#64748B' }}>Try adjusting your search or filters</Typography>
            </Box>
          )}
        </Container>
      </Box>


      {/* Filter Drawer */}
      <Drawer anchor="right" open={filterOpen} onClose={() => setFilterOpen(false)}
        PaperProps={{ sx: { width: 300, p: 3, borderRadius: '16px 0 0 16px' } }}>
        <Typography variant="h6" sx={{ fontWeight: 700, mb: 3 }}>Filters</Typography>

        <Typography sx={{ fontWeight: 600, mb: 1, fontSize: 14 ,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',}}>Max Consultation Fee: ${maxFee}</Typography>

        <Slider value={maxFee} onChange={(_, v) => setMaxFee(v)} min={35} max={200} step={5}
          sx={{ color: '#188', mb: 4 }} />


        <Typography sx={{ fontWeight: 600, mb: 2, fontSize: 14 }}>Consultation Type</Typography>
        {['Video Call', 'Text Chat'].map(type => (
          <FormControlLabel key={type} control={<Checkbox defaultChecked size="small"  sx={{
    color: '#94A3B8', 
    '&.Mui-checked': {
      color: '#188', 
    },
  }}/>}
            label={<Typography sx={{ fontSize: 14 }}>{type}</Typography>} sx={{ display: 'flex', mb: 1 }} />
        ))}
        

        <Box sx={{ mt: 'auto', pt: 3, display: 'flex', gap: 2 }}>
          <Button fullWidth onClick={() => { setMaxFee(200); setFilterOpen(false); }}
           sx={{
    position: 'relative',
    borderRadius: '30px',
    zIndex: 1,
    background: 'white',
    color: '#0F172A',
    transition: 'all 0.3s ease',
    '&::before': {
      content: '""',
      position: 'absolute',
      inset: 0,
      borderRadius: '30px',
      padding: '2px',
      background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
      WebkitMask:
        'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
      WebkitMaskComposite: 'xor',
      maskComposite: 'exclude',
      opacity: 0,
      transition: 'opacity 0.3s ease',
    },
    '&:hover::before': {
      opacity: 1,
    },
    '&:hover': {
      transform: 'translateY(-4px)',
    },
    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',
  }}>Reset</Button>

          <Button fullWidth variant="" onClick={() => setFilterOpen(false)}
            sx={{ borderRadius: 2 ,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)', color:"white",
              transition:"all 0.4s ease",
             '&:hover': {
      transform: 'translateY(-4px)', 
    }
        }}>Apply</Button>
        </Box>
      </Drawer>
    </Layout>
  );
}