import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Box, Typography, Button, Grid, Container, Chip, Avatar, Divider, Tab, Tabs } from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import StarIcon from '@mui/icons-material/Star';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import ChatIcon from '@mui/icons-material/Chat';
import VerifiedIcon from '@mui/icons-material/Verified';
import Layout from '../../components/layout/Layout';
import { doctors } from '../../data/mockData';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PeopleIcon from '@mui/icons-material/People';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import LanguageIcon from '@mui/icons-material/Language';
import { Rating } from '@mui/material';
const timeSlots = ['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'];

export default function DoctorProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { language } = useSelector(s => s.ui);
  const [tab, setTab] = useState(2); // جعلنا التبويب الافتراضي Reviews كما في الصورة
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [consultType, setConsultType] = useState('video');

  const doctor = doctors.find(d => d.id === Number(id));
  if (!doctor) return <Layout><Box sx={{ p: 8, textAlign: 'center' }}><Typography>Doctor not found</Typography></Box></Layout>;

  const handleBook = () => {
  if (!selectedDate || !selectedTime) return;

  navigate('/booking', {
    state: {
      doctor,
      date: selectedDate.label,
      time: selectedTime,
      type: consultType
    }
  });
};

  const name = language === 'ar' ? doctor.nameAr : doctor.name;
  const specialty = language === 'ar' ? doctor.specialtyAr : doctor.specialty;
  const about = language === 'ar' ? doctor.aboutAr : doctor.about;

  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return { date: d, label: d.toLocaleDateString('en', { weekday: 'short' }), day: d.getDate() };
  });

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', pb: 8 }}>
        <Container maxWidth="lg" sx={{ pt: 4 }}>
          {/* Back Button */}
          <Button 
            onClick={() => navigate('/doctors')} 
            startIcon={<ArrowBackIcon />}
            sx={{ color: '#0d9488', mb: 3, fontWeight: 700, textTransform: 'none' }}
          >
            Back to Doctors
          </Button>

          <Grid container spacing={4}>
            {/* LEFT: Doctor Info */}
            <Grid item xs={12} md={7}>
              <Box sx={{ background: 'white', borderRadius: 8, p: 4, mb: 4, textAlign: 'center', boxShadow: '0 4px 20px rgba(0,0,0,0.03)' }}>

                <Box sx={{ position: 'relative', width: 140, height: 140, margin: '0 auto 20px' }}>
                  <Avatar src={doctor.image} sx={{ width: 140, height: 140, borderRadius: '50%' }} />
                  <Box sx={{ position: 'absolute', bottom: 10, right: 10, width: 18, height: 18, borderRadius: '50%', background: '#22C55E', border: '3px solid white' }} />
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, mb: 1 }}>
                  <Typography variant="h4" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',}}>{name}</Typography>
                  <VerifiedIcon sx={{ color: '#10B981', fontSize: 24 }} />
                </Box>

                <Typography sx={{ background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', fontWeight: 600, fontSize: 18, mb: 2 }}>{specialty}</Typography>

                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 0.5, mb: 3 }}>
                  <StarIcon sx={{ color: '#F59E0B', fontSize: 20 }} />
                  <Typography sx={{ fontWeight: 700 }}>{doctor.rating}</Typography>
                  <Typography sx={{ color: '#94A3B8' }}>({doctor.reviews} reviews)</Typography>
                </Box>

                <Grid container spacing={2} sx={{ mb: 4 ,display:"flex",justifyContent:"center"}}>
                  {[
                    { icon: <WorkIcon />, label: `${doctor.experience} yrs exp` },
                    { icon: <PeopleIcon />, label: `${doctor.patients.toLocaleString()} patients` },
                    { icon: <LocationOnIcon />, label: doctor.location },
                  ].map((item, idx) => (
                    <Grid item xs={4} key={idx}>
                      <Box sx={{ color: '#64748B', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0.5 }}>
                        <Box sx={{ color: '#0d9488' }}>{item.icon}</Box>
                        <Typography sx={{ fontSize: 13, fontWeight: 500 }}>{item.label}</Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>

                <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1.5 }}>
                   <Chip icon={<LanguageIcon sx={{fontSize: '16px !important',color:"#188"}}/>} label="English" variant="outlined" sx={{ borderRadius: 2, color: '#64748B' }} />
                   <Chip icon={<LanguageIcon sx={{fontSize: '16px !important'}}/>} label="Spanish" variant="outlined" sx={{ borderRadius: 2, color: '#64748B' }} />
                   <Chip icon={<VideoCallIcon sx={{fontSize: '16px !important'}}/>} label="Video" variant="outlined" sx={{ borderRadius: 2, color: '#64748B' }} />
                   <Chip icon={<ChatIcon sx={{fontSize: '16px !important'}}/>} label="Chat" variant="outlined" sx={{ borderRadius: 2, color: '#64748B' }} />
                </Box>
              </Box>

              {/* Tabs Section */}
              <Box sx={{ background: 'white', borderRadius: 8, overflow: 'hidden', boxShadow: '0 4px 20px rgba(0,0,0,0.03)' }}>

                <Tabs value={tab} onChange={(_, v) => setTab(v)} centered sx={{ borderBottom: '1px solid #F1F5F9', '& .MuiTabs-indicator': { backgroundColor: '#0d9488' } }}>

                  <Tab label="About" sx={{ textTransform: 'none', fontWeight: 600, '&.Mui-selected': { color: '#0d9488' } }} />

                  <Tab label="Education" sx={{ textTransform: 'none', fontWeight: 600, '&.Mui-selected': { color: '#0d9488' } }} />

                  <Tab label="Reviews" sx={{ textTransform: 'none', fontWeight: 600, '&.Mui-selected': { color: '#0d9488' } }} />

                </Tabs>
                
                <Box sx={{ p: 4 }}>
                  {tab === 2 && (
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                      {[1, 2, 3].map((p) => (
                        <Box key={p}>
                          <Box sx={{ display: 'flex', gap: 2, mb: 1 }}>
                            <Avatar sx={{  fontWeight: 700,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)'}}>P</Avatar>
                            <Box>
                              <Typography sx={{ fontWeight: 700 }}>Patient {p}</Typography>
                              <Rating value={p === 3 ? 4 : 5} readOnly size="small" />
                            </Box>
                          </Box>
                          <Typography sx={{ color: '#64748B', fontStyle: 'italic' }}>
                            "Great service and professional care."
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  )}
                </Box>
              </Box>
            </Grid>

            {/* RIGHT: Booking Panel */}
            <Grid item xs={12} md={5}>
              <Box sx={{ background: 'white', borderRadius: 8, p: 4, position: 'sticky', top: 24, boxShadow: '0 10px 30px rgba(0,0,0,0.05)' }}>
                <Typography variant="h6" sx={{ fontWeight: 800, textAlign: 'center', mb: 3 ,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        }}>Book Appointment</Typography>
                
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 2, color: '#64748B' }}>Consultation Type</Typography>
                <Box sx={{ display: 'flex', gap: 2, mb: 4 }}>
                  <Button 
                    fullWidth 
                    onClick={() => setConsultType('video')}
                    variant={consultType === 'video' ? 'outlined' : 'text'}
                    sx={{ 
                      flexDirection: 'column', py: 2, borderRadius: 6, 
                      borderColor: consultType === 'video' ? '#0d9488' : '#F1F5F9',
                      bgcolor: consultType === 'video' ? '#F0FDFA' : 'transparent',
                      color: consultType === 'video' ? '#0d9488' : '#94A3B8'
                    }}
                  >
                    <VideoCallIcon />
                    <Typography sx={{ fontSize: 12, mt: 1, textTransform: 'none', fontWeight: 700 }}>Video</Typography>
                  </Button>
                  <Button 
                    fullWidth 
                    onClick={() => setConsultType('chat')}
                    variant={consultType === 'chat' ? 'outlined' : 'text'}
                    sx={{ 
                      flexDirection: 'column', py: 2, borderRadius: 6,
                      borderColor: consultType === 'chat' ? '#0d9488' : '#F1F5F9',
                      bgcolor: consultType === 'chat' ? '#F0FDFA' : 'transparent',
                      color: consultType === 'chat' ? '#188' : '#94A3B8'
                    }}
                  >
                    <ChatIcon />
                    <Typography sx={{ fontSize: 12, mt: 1, textTransform: 'none', fontWeight: 700 }}>Chat</Typography>
                  </Button>
                </Box>

                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 2, color: '#64748B' }}>Select Date</Typography>
                <Box sx={{ display: 'flex', gap: 1, mb: 4, overflowX: 'auto', py: 1 }}>
                  {dates.map((d, i) => (
                    <Box 
                      key={i} 
                      onClick={() => setSelectedDate(d)}
                      sx={{
                        minWidth: 55, p: 1.5, borderRadius: 4, textAlign: 'center', cursor: 'pointer',
                        border: '1px solid',
                        borderColor: selectedDate?.day === d.day ? '#0d9488' : '#F1F5F9',
                        
                        boxShadow: selectedDate?.day === d.day ? '0 4px 12px rgba(13,148,136,0.2)' : 'none'
                      }}
                    >
                      <Typography sx={{ fontSize: 11, color: '#94A3B8' }}>{d.label}</Typography>
                      <Typography sx={{ fontWeight: 800 }}>{d.day}</Typography>
                    </Box>
                  ))}
                </Box>

                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 2, color: '#64748B' }}>Select Time</Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 4 }}>
                  {timeSlots.map(time => (
                    <Chip 
                      key={time} 
                      label={time} 
                      onClick={() => setSelectedTime(time)}
                      sx={{ 
                        borderRadius: 2, 
                        bgcolor: selectedTime === time ? '#0d9488' : 'transparent',
                        color: selectedTime === time ? 'white' : '#64748B',
                        '&:hover': { bgcolor: '#0d9488', color: 'white' }
                      }} 
                    />
                  ))}
                </Box>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>Total Fee</Typography>
                  <Typography variant="h5" sx={{ fontWeight: 800 }}>${doctor.fee}</Typography>
                </Box>

               <Button 
  fullWidth 
  variant="contained" 
  onClick={handleBook}
  disabled={!selectedDate || !selectedTime}
  sx={{ 
    borderRadius: 4,
    py: 2,
    fontWeight: 800,
    fontSize: 16,
    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
    textTransform: 'none',
    boxShadow: '0 10px 20px rgba(13,148,136,0.3)',
    color: "white !important"
  }}
>
  Confirm Booking
</Button>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Layout>
  );
}