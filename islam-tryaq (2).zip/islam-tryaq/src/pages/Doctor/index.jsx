import React, { useState } from 'react';
import {
  Box, Typography, Grid, Card, CardContent, Avatar, Chip, Button,
  TextField, Divider, IconButton, LinearProgress, Dialog, DialogTitle,
  DialogContent, DialogActions, List, ListItem, Tabs, Tab, Badge,
  MenuItem, Select, FormControl, InputLabel
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Layout from '../../components/layout/Layout';

// Icons
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import MedicationIcon from '@mui/icons-material/Medication';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ChatIcon from '@mui/icons-material/Chat';
import FavoriteIcon from '@mui/icons-material/Favorite';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import AssignmentIcon from '@mui/icons-material/Assignment';
import HistoryIcon from '@mui/icons-material/History';

import PeopleIcon from '@mui/icons-material/People';import EmergencyIcon from '@mui/icons-material/Emergency';import WarningIcon from '@mui/icons-material/Warning';import TodayIcon from '@mui/icons-material/Today';

// --- Styles ---
const btnGradient = "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)";
const inputStyles = {
  '& .MuiOutlinedInput-root': {
    '& fieldset': { borderColor: '#E2E8F0' },
    '&:hover fieldset': { borderColor: '#188' },
    '&.Mui-focused fieldset': { borderColor: '#188' },
  },
  '& .MuiInputLabel-root.Mui-focused': { color: '#188' }
};

// ─── Mock Data ────────────────────────────────────────────────────────────────
const mockPatients = [
  { id: 1, name: 'Ahmed Al-Hassan', nameAr: 'أحمد الحسن', age: 52, diagnosis: 'Hypertension Stage 1', diagnosisAr: 'ارتفاع ضغط الدم', status: 'stable', lastBP: '132/84', medicationAdherence: 75, missedMeds: 2, image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face', medications: [{ id: 1, name: 'Amlodipine 5mg', time: '08:00 AM', frequency: 'Daily' }, { id: 2, name: 'Losartan 50mg', time: '08:00 AM', frequency: 'Daily' }], instructions: ['Reduce salt intake', 'Walk 30 min daily', 'Monitor BP twice daily'] },
  { id: 2, name: 'Fatima Nour', nameAr: 'فاطمة نور', age: 38, diagnosis: 'Type 2 Diabetes', diagnosisAr: 'السكري من النوع الثاني', status: 'critical', lastBP: '145/92', medicationAdherence: 40, missedMeds: 8, image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop&crop=face', medications: [{ id: 1, name: 'Metformin 500mg', time: '08:00 AM', frequency: 'Twice Daily' }], instructions: ['Check blood sugar daily', 'Low-carb diet'] },
  { id: 3, name: 'Omar Khalil', nameAr: 'عمر خليل', age: 67, diagnosis: 'Heart Failure Class II', diagnosisAr: 'قصور القلب - الدرجة الثانية', status: 'warning', lastBP: '140/88', medicationAdherence: 60, missedMeds: 5, image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop&crop=face', medications: [{ id: 1, name: 'Furosemide 40mg', time: '07:00 AM', frequency: 'Daily' }, { id: 2, name: 'Carvedilol 6.25mg', time: '08:00 AM', frequency: 'Twice Daily' }], instructions: ['Weigh daily', 'Fluid restriction 1.5L/day'] },
];

const doctorAlerts = [
  { id: 1, patientId: 2, patient: 'Fatima Nour', patientAr: 'فاطمة نور', msg: 'Missed Metformin for 3 consecutive days', msgAr: 'لم تتناول الميتفورمين لمدة 3 أيام متتالية', severity: 'critical', time: '1 hour ago' },
  { id: 2, patientId: 2, patient: 'Fatima Nour', patientAr: 'فاطمة نور', msg: 'Glucose level reported at 320 mg/dl', msgAr: 'مستوى الجلوكوز 320 مغ/دل', severity: 'critical', time: '3 hours ago' },
  { id: 3, patientId: 3, patient: 'Omar Khalil', patientAr: 'عمر خليل', msg: 'Missed Furosemide – risk of fluid retention', msgAr: 'لم يأخذ فوروسيمايد - خطر احتباس السوائل', severity: 'warning', time: '6 hours ago' },
  { id: 4, patientId: 1, patient: 'Ahmed Al-Hassan', patientAr: 'أحمد الحسن', msg: 'Appointment due in 3 days', msgAr: 'موعد بعد 3 أيام', severity: 'info', time: '1 day ago' },
];

const statusConfig = { stable: { label: 'Stable', labelAr: 'مستقر', color: '#15803D', bg: '#F0FDF4', border: '#BBF7D0' }, warning: { label: 'Warning', labelAr: 'تحذير', color: '#D97706', bg: '#FFFBEB', border: '#FDE68A' }, critical: { label: 'Critical', labelAr: 'حرج', color: '#DC2626', bg: '#FEF2F2', border: '#FECACA' } };
const alertConfig = { critical: { color: '#DC2626', bg: '#FEF2F2', icon: '🚨' }, warning: { color: '#D97706', bg: '#FFFBEB', icon: '⚠️' }, info: { color: '#0EA5E9', bg: '#F0F9FF', icon: 'ℹ️' } };

// ─── Edit Dialog ──────────────────────────────────────────────────────────────
function EditTreatmentDialog({ open, onClose, patient, lang }) {
  const [meds, setMeds] = useState(patient?.medications || []);
  const [instructions, setInstructions] = useState(patient?.instructions || []);
  const [newMed, setNewMed] = useState({ name: '', time: '' });
  const [newIns, setNewIns] = useState('');
  const [saved, setSaved] = useState(false);

  React.useEffect(() => { if (patient) { setMeds(patient.medications); setInstructions(patient.instructions); } }, [patient]);

  const handleSave = () => { setSaved(true); setTimeout(() => { setSaved(false); onClose(); }, 1500); };
  if (!patient) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3.5 } }}>
      <DialogTitle sx={{ fontWeight: 800, fontSize: 18 }}>{lang === 'ar' ? 'تعديل خطة العلاج' : 'Edit Treatment Plan'} — {lang === 'ar' ? patient.nameAr : patient.name}</DialogTitle>
      <DialogContent>
        {saved ? (
          <Box sx={{ textAlign: 'center', py: 4 }}><CheckCircleIcon sx={{ fontSize: 60, color: '#22C55E', mb: 2 }} /><Typography sx={{ fontWeight: 700, fontSize: 18 }}>{lang === 'ar' ? 'تم الحفظ!' : 'Saved!'}</Typography></Box>
        ) : (
          <>
            <Typography sx={{ fontWeight: 700, fontSize: 14, mb: 1.5, mt: 1 }}> {lang === 'ar' ? 'الأدوية' : 'Medications'}</Typography>
            {meds.map(m => (
              <Box key={m.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1, p: 1.5, borderRadius: 2.5, background: '#F8FAFC', border: '1px solid #F1F5F9' }}>
                <MedicationIcon sx={{ color: '#0EA5E9', fontSize: 18 }} />
                <Box sx={{ flex: 1 }}><Typography sx={{ fontWeight: 600, fontSize: 13 }}>{m.name}</Typography><Typography sx={{ fontSize: 11, color: '#94A3B8' }}>{m.time} · {m.frequency}</Typography></Box>
                <IconButton size="small" onClick={() => setMeds(meds.filter(x => x.id !== m.id))} sx={{ color: '#EF4444' }}><DeleteIcon sx={{ fontSize: 25 }} /></IconButton>
              </Box>
            ))}
            
            <Grid container spacing={2} sx={{ mb: 3 }}>
              <Grid item xs={6}>
                <TextField size="small" fullWidth label={lang === 'ar' ? 'اسم الدواء' : 'Medication'} value={newMed.name} onChange={e => setNewMed({ ...newMed, name: e.target.value })} sx={inputStyles} />
              </Grid>
              <Grid item xs={6}>
                <TextField size="small" fullWidth label={lang === 'ar' ? 'الوقت' : 'Time'} value={newMed.time} onChange={e => setNewMed({ ...newMed, time: e.target.value })} sx={inputStyles} />
              </Grid>
              <Grid item xs={12}>
                <Button fullWidth onClick={() => { if (newMed.name) { setMeds([...meds, { ...newMed, id: Date.now(), frequency: 'Daily' }]); setNewMed({ name: '', time: '' }); } }} variant="contained" size="small" sx={{ borderRadius: 2, background: btnGradient, color: 'white', py: 1 }}><AddIcon sx={{ mr: 1 }} /> {lang === 'ar' ? 'إضافة دواء' : 'Add Medication'}</Button>
              </Grid>
            </Grid>

            <Divider sx={{ my: 2 }} />
            
            <Typography sx={{ fontWeight: 700, fontSize: 14, mb: 1.5 }}><AssignmentIcon sx={{color:"#188",mr:1}} /> {lang === 'ar' ? 'التعليمات' : 'Instructions'}</Typography>
            {instructions.map((ins, i) => (
              <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1, p: 1.5, borderRadius: 2.5, background: '#F0FDF4', border: '1px solid #D1FAE5' }}>
                <CheckCircleIcon sx={{ color: '#22C55E', fontSize: 18 }} />
                <Typography sx={{ fontSize: 13, flex: 1 }}>{ins}</Typography>
                <IconButton size="small" onClick={() => setInstructions(instructions.filter((_, j) => j !== i))} sx={{ color: '#EF4444' }}><DeleteIcon sx={{ fontSize: 25 }} /></IconButton>
              </Box>
            ))}

            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField size="small" fullWidth label={lang === 'ar' ? 'تعليمة جديدة' : 'New instruction'} value={newIns} onChange={e => setNewIns(e.target.value)} sx={inputStyles} />
              </Grid>
              <Grid item xs={12}>
                <Button fullWidth onClick={() => { if (newIns) { setInstructions([...instructions, newIns]); setNewIns(''); } }} variant="contained" size="small" sx={{ borderRadius: 2, background: btnGradient, color: 'white', py: 1 }}><AddIcon sx={{ mr: 1 }} /> {lang === 'ar' ? 'إضافة تعليمة' : 'Add Instruction'}</Button>
              </Grid>
            </Grid>
          </>
        )}
      </DialogContent>
      {!saved && (
        <DialogActions sx={{ p: 2.5 }}>
          <Button onClick={onClose} sx={{ borderRadius: 2.5, color: '#64748B', textTransform: 'none' }}>{lang === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
          <Button variant="contained" onClick={handleSave} sx={{ borderRadius: 2.5, textTransform: 'none', background: btnGradient, color: 'white', px: 4 }}>{lang === 'ar' ? 'حفظ التغييرات' : 'Save Changes'}</Button>
        </DialogActions>
      )}
    </Dialog>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function DoctorDashboard() {
  const { user } = useSelector(s => s.auth);
  const { language } = useSelector(s => s.ui);
  const navigate = useNavigate();
  const lang = language || 'en';
  const [tab, setTab] = useState(0);
  const [editPatient, setEditPatient] = useState(null);
  const [filter, setFilter] = useState('all');

  const urgentAlerts = doctorAlerts.filter(a => a.severity === 'critical').length;
  const filteredPatients = filter === 'all' ? mockPatients : mockPatients.filter(p => p.status === filter);

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', pt: { xs: 9, md: 10 }, pb: 6 ,display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'}}>
        <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, md: 4 } }}>
          {/* Header */}
          <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 2 }}>
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 800, mb: 0.5 }}>
                <Box component="span" sx={{ background: btnGradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', display: 'inline-block' }}>
                  {lang === 'ar' ? 'لوحة الطبيب' : "Doctor's Dashboard"}
                </Box>
              </Typography>
              <Typography sx={{ color: '#64748B', fontSize: 15 }}>
                {lang === 'ar' ? `مرحباً د. ${user?.firstName || 'Doctor'}` : `Welcome Dr. ${user?.firstName || 'Doctor'}`}
              </Typography>
            </Box>
            <Button variant="outlined" startIcon={<HistoryIcon />} onClick={() => navigate('/doctor/history')}
              sx={{ borderRadius: 2.5, textTransform: 'none', fontWeight: 700, borderColor: '#14B8A6', color: '#14B8A6' }}>
              {lang === 'ar' ? 'سجلات المرضى' : 'Patient History'}
            </Button>
          </Box>

          {/* Stats */}
          <Grid container spacing={2} sx={{ mb: 4 }}>
            {[
               {
    icon: <PeopleIcon sx={{color:"#188"}}/>,
    label: lang === 'ar' ? 'إجمالي المرضى' : 'Total Patients',
    value: mockPatients.length,
    bg: '#F0F9FF',
    color: '#0EA5E9'
  },
  {
    icon: <EmergencyIcon sx={{color:"#188"}}/>,
    label: lang === 'ar' ? 'حالات حرجة' : 'Critical Cases',
    value: mockPatients.filter(p => p.status === 'critical').length,
    bg: '#FEF2F2',
    color: '#DC2626'
  },
  {
    icon: <WarningIcon sx={{color:"#188"}} />,
    label: lang === 'ar' ? 'تنبيهات عاجلة' : 'Urgent Alerts',
    value: urgentAlerts,
    bg: '#FFFBEB',
    color: '#D97706'
  },
  {
    icon: <TodayIcon sx={{color:"#188"}} />,
    label: lang === 'ar' ? 'مواعيد اليوم' : "Today's Appts",
    value: 4,
    bg: '#F0FDF4',
    color: '#14B8A6'
  }
            ].map((s, i) => (
              <Grid item xs={6} sm={3} key={i}>
                <Card sx={{ borderRadius: 3, border: `1px solid ${s.color}25`, boxShadow: 'none', background: s.bg }}>
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography sx={{ fontSize: 24, mb: 0.5 }}>{s.icon}</Typography>
                    <Typography sx={{ fontSize: 26, fontWeight: 800, color: '#0F172A', lineHeight: 1 }}>{s.value}</Typography>
                    <Typography sx={{ fontSize: 11.5, color: '#64748B', mt: 0.5 }}>{s.label}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Tabs */}
          <Box sx={{ borderBottom: '1px solid #F1F5F9', mb: 3 }}>
            <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, fontSize: 14 }, '& .Mui-selected': { color: '#188' }, '& .MuiTabs-indicator': { background: btnGradient } }}>
              <Tab label={lang === 'ar' ? 'مرضاي' : 'My Patients'} />
              <Tab label={<Badge badgeContent={urgentAlerts} color="error"><Box sx={{ pr: urgentAlerts ? 1.5 : 0 }}>{lang === 'ar' ? 'التنبيهات' : 'Alerts'}</Box></Badge>} />
            </Tabs>
          </Box>

          {/* Patients Tab */}
          {tab === 0 && (
            <>
              <Box sx={{ display: 'flex', gap: 1.5, mb: 3, flexWrap: 'wrap' }}>
                {['all', 'stable', 'warning', 'critical'].map(f => (
                  <Chip key={f} clickable onClick={() => setFilter(f)}
                    label={lang === 'ar' ? { all: 'الكل', stable: 'مستقر', warning: 'تحذير', critical: 'حرج' }[f] : f.charAt(0).toUpperCase() + f.slice(1)}
                    sx={{ fontWeight: 600, fontSize: 13, borderRadius: 2.5, background: filter === f ? btnGradient : 'white', color: filter === f ? 'white' : '#64748B', border: '1px solid #E2E8F0' }} />
                ))}
              </Box>
              <Grid container spacing={3}>
                {filteredPatients.map(p => {
                  const st = statusConfig[p.status];
                  return (
                    <Grid item xs={12} md={6} lg={4} key={p.id}>
                      <Card sx={{ borderRadius: 3.5, border: `1px solid ${st.border}`, boxShadow: '0 2px 10px rgba(0,0,0,0.04)', transition: 'all 0.2s', '&:hover': { boxShadow: '0 6px 20px rgba(0,0,0,0.08)', transform: 'translateY(-2px)' } }}>
                        <CardContent sx={{ p: 2.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                            <Avatar src={p.image} sx={{ width: 50, height: 50, borderRadius: 2.5 }} />
                            <Box sx={{ flex: 1 }}>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                                <Typography sx={{ fontWeight: 700, fontSize: 14.5 }}>{lang === 'ar' ? p.nameAr : p.name}</Typography>
                                <Chip label={lang === 'ar' ? st.labelAr : st.label} size="small" sx={{ background: st.bg, color: st.color, fontWeight: 700, fontSize: 10, height: 20, borderRadius: 1.5 }} />
                              </Box>
                              <Typography sx={{ fontSize: 12, color: '#14B8A6', fontWeight: 600 }}>{lang === 'ar' ? p.diagnosisAr : p.diagnosis} · {p.age}y</Typography>
                            </Box>
                          </Box>
                          <Box sx={{ mb: 2 }}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                              <Typography sx={{ fontSize: 11.5, color: '#64748B', fontWeight: 600 }}>{lang === 'ar' ? 'الالتزام بالدواء' : 'Adherence'}</Typography>
                              <Typography sx={{ fontSize: 12, fontWeight: 700, color: p.medicationAdherence >= 70 ? '#22C55E' : p.medicationAdherence >= 50 ? '#F59E0B' : '#EF4444' }}>{p.medicationAdherence}%</Typography>
                            </Box>
                            <LinearProgress variant="determinate" value={p.medicationAdherence} sx={{ height: 5, borderRadius: 3, '& .MuiLinearProgress-bar': { background: p.medicationAdherence >= 70 ? '#22C55E' : p.medicationAdherence >= 50 ? '#F59E0B' : '#EF4444' } }} />
                          </Box>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, alignItems: 'center' }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><FavoriteIcon sx={{ fontSize: 13, color: '#EF4444' }} /><Typography sx={{ fontSize: 12, color: '#64748B' }}>{p.lastBP}</Typography></Box>
                            {p.missedMeds > 0 && <Chip label={`${p.missedMeds} ${lang === 'ar' ? 'دواء فائت' : 'missed'}`} size="small" sx={{ background: '#FEF2F2', color: '#DC2626', fontWeight: 700, fontSize: 10, height: 20, borderRadius: 1.5 }} />}
                          </Box>
                          <Box sx={{ display: 'flex', gap: 1 }}>
                            <Button size="small" startIcon={<EditIcon />} onClick={() => setEditPatient(p)} fullWidth sx={{ borderRadius: 2, textTransform: 'none', fontWeight: 600, fontSize: 12, border: '1px solid #E2E8F0', color: '#0F172A' }}>{lang === 'ar' ? 'تعديل العلاج' : 'Edit Plan'}</Button>
                            <Button size="small" startIcon={<ChatIcon />} onClick={() => navigate(`/chat/${p.id}`)} fullWidth variant="contained" sx={{ borderRadius: 2, textTransform: 'none', fontWeight: 600, fontSize: 12, background: btnGradient, color: 'white' }}>{lang === 'ar' ? 'مراسلة' : 'Message'}</Button>
                          </Box>
                        </CardContent>
                      </Card>
                    </Grid>
                  );
                })}
              </Grid>
            </>
          )}

          {/* Alerts Tab */}
          {tab === 1 && (
            <Box>
              {doctorAlerts.map(alert => {
                const cfg = alertConfig[alert.severity];
                return (
                  <Card key={alert.id} sx={{ borderRadius: 3, border: `1px solid ${cfg.color}25`, background: cfg.bg, mb: 2, boxShadow: 'none' }}>
                    <CardContent sx={{ p: 2.5, '&:last-child': { pb: 2.5 } }}>
                      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
                        <Typography sx={{ fontSize: 24, flexShrink: 0 }}>{cfg.icon}</Typography>
                        <Box sx={{ flex: 1 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5 }}>
                            <Typography sx={{ fontWeight: 700, fontSize: 14 }}>{lang === 'ar' ? alert.patientAr : alert.patient}</Typography>
                            <Chip label={alert.severity} size="small" sx={{ background: `${cfg.color}20`, color: cfg.color, fontWeight: 700, fontSize: 10, height: 20, borderRadius: 1.5 }} />
                          </Box>
                          <Typography sx={{ fontSize: 13.5, mb: 0.5 }}>{lang === 'ar' ? alert.msgAr : alert.msg}</Typography>
                          <Typography sx={{ fontSize: 11.5, color: '#94A3B8' }}>{alert.time}</Typography>
                        </Box>
                        <Button size="small" variant="contained" onClick={() => navigate(`/chat/${alert.patientId}`)} sx={{ borderRadius: 2, textTransform: 'none', fontWeight: 600, fontSize: 12, flexShrink: 0, background: btnGradient, color: 'white' }}>{lang === 'ar' ? 'تواصل' : 'Contact'}</Button>
                      </Box>
                    </CardContent>
                  </Card>
                );
              })}
            </Box>
          )}
        </Box>
      </Box>
      <EditTreatmentDialog open={!!editPatient} onClose={() => setEditPatient(null)} patient={editPatient} lang={lang} />
    </Layout>
  );
}