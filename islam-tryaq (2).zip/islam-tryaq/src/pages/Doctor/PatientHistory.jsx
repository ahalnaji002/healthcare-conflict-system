import React, { useState } from 'react';
import {
  Box, Typography, Grid, Card, CardContent, Avatar, Chip, Button,
  Divider, TextField, InputAdornment, Tabs, Tab, LinearProgress, Dialog,
  DialogTitle, DialogContent, DialogActions, List, ListItem, ListItemText
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import Layout from '../../components/layout/Layout';

import SearchIcon from '@mui/icons-material/Search';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MedicationIcon from '@mui/icons-material/Medication';
import MonitorHeartIcon from '@mui/icons-material/MonitorHeart';
import AssignmentIcon from '@mui/icons-material/Assignment';
import ChatIcon from '@mui/icons-material/Chat';
import HistoryIcon from '@mui/icons-material/History';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ThermostatIcon from '@mui/icons-material/Thermostat';
import AirIcon from '@mui/icons-material/Air';
import WaterDropIcon from '@mui/icons-material/WaterDrop';
import WarningIcon from '@mui/icons-material/Warning';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const btnGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';

const patientsHistory = [
  {
    id: 1,
    name: 'Ahmed Al-Hassan', nameAr: 'أحمد الحسن',
    age: 52, gender: 'Male', genderAr: 'ذكر',
    diagnosis: 'Hypertension Stage 1', diagnosisAr: 'ارتفاع ضغط الدم – المرحلة الأولى',
    status: 'stable',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
    bloodType: 'A+',
    allergies: ['Penicillin'],
    allergiesAr: ['بنسلين'],
    visitHistory: [
      { date: '2026-04-10', type: 'Follow-up', typeAr: 'متابعة', notes: 'BP improved to 128/82. Continue current meds.', notesAr: 'تحسن الضغط إلى 128/82. الاستمرار في الأدوية.' },
      { date: '2026-03-15', type: 'Routine Check', typeAr: 'فحص دوري', notes: 'BP was 142/90. Adjusted Losartan to 50mg.', notesAr: 'الضغط 142/90. تعديل الجرعة.' },
      { date: '2026-02-01', type: 'Initial Diagnosis', typeAr: 'تشخيص أولي', notes: 'Patient presented with chronic headache. Diagnosed HTN stage 1.', notesAr: 'صداع مزمن. تم تشخيص ارتفاع ضغط الدم.' },
    ],
    medications: [
      { name: 'Amlodipine 5mg', frequency: 'Once daily', since: '2026-02-01' },
      { name: 'Losartan 50mg', frequency: 'Once daily', since: '2026-03-15' },
    ],
    vitalsLog: [
      { date: '2026-04-10', bp: '128/82', pulse: 72, temp: 36.6, oxygen: 98 },
      { date: '2026-03-15', bp: '142/90', pulse: 80, temp: 36.8, oxygen: 97 },
      { date: '2026-02-01', bp: '148/94', pulse: 84, temp: 37.0, oxygen: 97 },
    ],
    adherenceHistory: [75, 80, 60, 90, 75],
    missedMeds: 2,
    medicationAdherence: 75,
  },
  {
    id: 2,
    name: 'Fatima Nour', nameAr: 'فاطمة نور',
    age: 38, gender: 'Female', genderAr: 'أنثى',
    diagnosis: 'Type 2 Diabetes', diagnosisAr: 'السكري من النوع الثاني',
    status: 'critical',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop&crop=face',
    bloodType: 'O-',
    allergies: ['Sulfa drugs'],
    allergiesAr: ['مضادات السلفا'],
    visitHistory: [
      { date: '2026-04-12', type: 'Emergency', typeAr: 'طارئ', notes: 'Glucose 320 mg/dl, missed Metformin 3 days. Insulin adjusted.', notesAr: 'جلوكوز 320. فاتت جرعات متفورمين. تم تعديل الإنسولين.' },
      { date: '2026-03-20', type: 'Follow-up', typeAr: 'متابعة', notes: 'HbA1c 7.8%. Diet counseling provided.', notesAr: 'HbA1c 7.8%. تقديم إرشادات غذائية.' },
    ],
    medications: [
      { name: 'Metformin 500mg', frequency: 'Twice daily', since: '2026-01-15' },
      { name: 'Insulin Glargine', frequency: 'Once at night', since: '2026-04-12' },
    ],
    vitalsLog: [
      { date: '2026-04-12', bp: '145/92', pulse: 90, temp: 37.2, oxygen: 96 },
      { date: '2026-03-20', bp: '138/88', pulse: 82, temp: 36.9, oxygen: 97 },
    ],
    adherenceHistory: [40, 30, 55, 40, 20],
    missedMeds: 8,
    medicationAdherence: 40,
  },
  {
    id: 3,
    name: 'Omar Khalil', nameAr: 'عمر خليل',
    age: 67, gender: 'Male', genderAr: 'ذكر',
    diagnosis: 'Heart Failure Class II', diagnosisAr: 'قصور القلب – الدرجة الثانية',
    status: 'warning',
    image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop&crop=face',
    bloodType: 'B+',
    allergies: ['Aspirin'],
    allergiesAr: ['أسبرين'],
    visitHistory: [
      { date: '2026-04-08', type: 'Follow-up', typeAr: 'متابعة', notes: 'Slight edema in lower limbs. Furosemide maintained.', notesAr: 'تورم طفيف في الساقين. الاستمرار في الفيروسيميد.' },
      { date: '2026-03-10', type: 'Echocardiogram', typeAr: 'صدى القلب', notes: 'EF 40%. Mild mitral regurgitation noted.', notesAr: 'EF 40%. قلس تاجي خفيف.' },
    ],
    medications: [
      { name: 'Furosemide 40mg', frequency: 'Once daily (morning)', since: '2026-01-01' },
      { name: 'Carvedilol 6.25mg', frequency: 'Twice daily', since: '2026-01-01' },
    ],
    vitalsLog: [
      { date: '2026-04-08', bp: '140/88', pulse: 68, temp: 36.7, oxygen: 95 },
      { date: '2026-03-10', bp: '138/84', pulse: 66, temp: 36.5, oxygen: 96 },
    ],
    adherenceHistory: [60, 70, 55, 65, 60],
    missedMeds: 5,
    medicationAdherence: 60,
  },
];

const statusConfig = {
  stable: { label: 'Stable', labelAr: 'مستقر', color: '#15803D', bg: '#F0FDF4', border: '#BBF7D0' },
  warning: { label: 'Warning', labelAr: 'تحذير', color: '#D97706', bg: '#FFFBEB', border: '#FDE68A' },
  critical: { label: 'Critical', labelAr: 'حرج', color: '#DC2626', bg: '#FEF2F2', border: '#FECACA' },
};

function VitalsRow({ v }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1.5, borderRadius: 2, background: '#F8FAFC', border: '1px solid #F1F5F9', mb: 1 }}>
      <Typography sx={{ fontSize: 12, color: '#94A3B8', minWidth: 80 }}>{v.date}</Typography>
      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <WaterDropIcon sx={{ fontSize: 13, color: '#EF4444' }} />
          <Typography sx={{ fontSize: 12, fontWeight: 600 }}>{v.bp}</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <FavoriteIcon sx={{ fontSize: 13, color: '#F59E0B' }} />
          <Typography sx={{ fontSize: 12, fontWeight: 600 }}>{v.pulse} bpm</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <ThermostatIcon sx={{ fontSize: 13, color: '#8B5CF6' }} />
          <Typography sx={{ fontSize: 12, fontWeight: 600 }}>{v.temp}°C</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <AirIcon sx={{ fontSize: 13, color: '#0EA5E9' }} />
          <Typography sx={{ fontSize: 12, fontWeight: 600 }}>{v.oxygen}%</Typography>
        </Box>
      </Box>
    </Box>
  );
}

function PatientDetailDialog({ open, onClose, patient, lang, navigate }) {
  const [tab, setTab] = useState(0);
  if (!patient) return null;
  const st = statusConfig[patient.status];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth PaperProps={{ sx: { borderRadius: 3.5 } }}>
      <DialogTitle sx={{ pb: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Avatar src={patient.image} sx={{ width: 52, height: 52, borderRadius: 2.5 }} />
          <Box sx={{ flex: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography sx={{ fontWeight: 800, fontSize: 17 }}>{lang === 'ar' ? patient.nameAr : patient.name}</Typography>
              <Chip label={lang === 'ar' ? st.labelAr : st.label} size="small"
                sx={{ background: st.bg, color: st.color, fontWeight: 700, fontSize: 11, height: 20 }} />
            </Box>
            <Typography sx={{ fontSize: 13, color: '#14B8A6', fontWeight: 600 }}>
              {lang === 'ar' ? patient.diagnosisAr : patient.diagnosis} · {patient.age}{lang === 'ar' ? ' سنة' : 'y'} · {lang === 'ar' ? patient.genderAr : patient.gender}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Chip label={`🩸 ${patient.bloodType}`} size="small" sx={{ fontWeight: 700, background: '#FEF2F2', color: '#DC2626' }} />
          </Box>
        </Box>
        <Box sx={{ mt: 1.5, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
          {(lang === 'ar' ? patient.allergiesAr : patient.allergies).map(a => (
            <Chip key={a} icon={<WarningIcon sx={{ fontSize: 13 }} />}
              label={`${lang === 'ar' ? 'حساسية: ' : 'Allergy: '}${a}`} size="small"
              sx={{ background: '#FFFBEB', color: '#D97706', fontWeight: 600, fontSize: 11 }} />
          ))}
        </Box>
      </DialogTitle>

      <Box sx={{ px: 3 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, fontSize: 13 }, '& .Mui-selected': { color: '#0d9488' }, '& .MuiTabs-indicator': { background: btnGradient } }}>
          <Tab label={lang === 'ar' ? 'سجل الزيارات' : 'Visit History'} />
          <Tab label={lang === 'ar' ? 'قياسات حيوية' : 'Vitals Log'} />
          <Tab label={lang === 'ar' ? 'الأدوية' : 'Medications'} />
          <Tab label={lang === 'ar' ? 'الالتزام' : 'Adherence'} />
        </Tabs>
      </Box>

      <DialogContent sx={{ pt: 2 }}>
        {tab === 0 && (
          <Box>
            {patient.visitHistory.map((v, i) => (
              <Box key={i} sx={{ display: 'flex', gap: 2, mb: 2 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <Box sx={{ width: 10, height: 10, borderRadius: '50%', background: '#14B8A6', mt: 0.5 }} />
                  {i < patient.visitHistory.length - 1 && <Box sx={{ width: 2, flex: 1, background: '#E2E8F0', mt: 0.5 }} />}
                </Box>
                <Box sx={{ flex: 1, pb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                    <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>{v.date}</Typography>
                    <Chip label={lang === 'ar' ? v.typeAr : v.type} size="small"
                      sx={{ height: 18, fontSize: 10, background: '#F0F9FF', color: '#0EA5E9', fontWeight: 600 }} />
                  </Box>
                  <Typography sx={{ fontSize: 13, color: '#374151' }}>{lang === 'ar' ? v.notesAr : v.notes}</Typography>
                </Box>
              </Box>
            ))}
          </Box>
        )}

        {tab === 1 && (
          <Box>
            {patient.vitalsLog.map((v, i) => <VitalsRow key={i} v={v} />)}
          </Box>
        )}

        {tab === 2 && (
          <Box>
            {patient.medications.map((m, i) => (
              <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1.5, borderRadius: 2.5, background: '#F8FAFC', border: '1px solid #F1F5F9', mb: 1 }}>
                <MedicationIcon sx={{ color: '#0EA5E9', fontSize: 20 }} />
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontWeight: 700, fontSize: 14 }}>{m.name}</Typography>
                  <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>{m.frequency} · {lang === 'ar' ? 'منذ' : 'Since'} {m.since}</Typography>
                </Box>
                <CheckCircleIcon sx={{ color: '#22C55E', fontSize: 18 }} />
              </Box>
            ))}
          </Box>
        )}

        {tab === 3 && (
          <Box>
            <Box sx={{ mb: 2, p: 2, borderRadius: 2.5, background: patient.medicationAdherence >= 70 ? '#F0FDF4' : patient.medicationAdherence >= 50 ? '#FFFBEB' : '#FEF2F2', border: `1px solid ${patient.medicationAdherence >= 70 ? '#D1FAE5' : patient.medicationAdherence >= 50 ? '#FDE68A' : '#FECACA'}` }}>
              <Typography sx={{ fontWeight: 700, fontSize: 22, color: patient.medicationAdherence >= 70 ? '#22C55E' : patient.medicationAdherence >= 50 ? '#F59E0B' : '#EF4444' }}>
                {patient.medicationAdherence}%
              </Typography>
              <Typography sx={{ fontSize: 13, color: '#64748B' }}>{lang === 'ar' ? 'معدل الالتزام الإجمالي' : 'Overall adherence rate'}</Typography>
              <LinearProgress variant="determinate" value={patient.medicationAdherence} sx={{ height: 6, borderRadius: 3, mt: 1, '& .MuiLinearProgress-bar': { background: patient.medicationAdherence >= 70 ? '#22C55E' : patient.medicationAdherence >= 50 ? '#F59E0B' : '#EF4444' } }} />
            </Box>
            <Typography sx={{ fontWeight: 700, fontSize: 13, mb: 1 }}>{lang === 'ar' ? 'الأسابيع الأخيرة' : 'Recent weeks'}</Typography>
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-end', height: 80 }}>
              {patient.adherenceHistory.map((val, i) => (
                <Box key={i} sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0.5 }}>
                  <Typography sx={{ fontSize: 10, color: '#94A3B8' }}>{val}%</Typography>
                  <Box sx={{ width: '100%', height: `${val}%`, minHeight: 6, borderRadius: '4px 4px 0 0', background: val >= 70 ? '#22C55E' : val >= 50 ? '#F59E0B' : '#EF4444', opacity: 0.8 }} />
                  <Typography sx={{ fontSize: 10, color: '#CBD5E1' }}>W{i + 1}</Typography>
                </Box>
              ))}
            </Box>
            {patient.missedMeds > 0 && (
              <Box sx={{ mt: 2, p: 1.5, borderRadius: 2, background: '#FEF2F2', display: 'flex', alignItems: 'center', gap: 1 }}>
                <WarningIcon sx={{ fontSize: 16, color: '#EF4444' }} />
                <Typography sx={{ fontSize: 13, color: '#DC2626', fontWeight: 600 }}>
                  {patient.missedMeds} {lang === 'ar' ? 'جرعة فائتة في آخر أسبوع' : 'missed doses in the last week'}
                </Typography>
              </Box>
            )}
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 2.5, borderTop: '1px solid #F1F5F9' }}>
        <Button onClick={onClose} sx={{ color: '#64748B', textTransform: 'none', fontWeight: 600 }}>
          {lang === 'ar' ? 'إغلاق' : 'Close'}
        </Button>
        <Button variant="contained" startIcon={<ChatIcon />}
          onClick={() => { onClose(); navigate(`/chat/${patient.id}`); }}
          sx={{ textTransform: 'none', fontWeight: 700, background: btnGradient, color: 'white', borderRadius: 2.5 }}>
          {lang === 'ar' ? 'مراسلة المريض' : 'Message Patient'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default function PatientHistory() {
  const { language } = useSelector(s => s.ui);
  const navigate = useNavigate();
  const lang = language || 'en';
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');

  const filtered = patientsHistory.filter(p => {
    const matchSearch = (lang === 'ar' ? p.nameAr : p.name).toLowerCase().includes(search.toLowerCase())
      || (lang === 'ar' ? p.diagnosisAr : p.diagnosis).toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || p.status === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', pt: { xs: 9, md: 10 }, pb: 6 }}>
        <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, md: 4 } }}>

          {/* Header */}
          <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
            <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/doctor')}
              sx={{ color: '#64748B', textTransform: 'none', fontWeight: 600, borderRadius: 2.5, border: '1px solid #E2E8F0' }}>
              {lang === 'ar' ? 'رجوع' : 'Back'}
            </Button>
            <Box sx={{ flex: 1 }}>
              <Typography variant="h4" sx={{ fontWeight: 800, background: btnGradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', display: 'inline-block' }}>
                {lang === 'ar' ? 'سجلات المرضى الطبية' : 'Patient Medical History'}
              </Typography>
              <Typography sx={{ fontSize: 14, color: '#64748B' }}>
                {lang === 'ar' ? `${patientsHistory.length} مرضى – سجلات كاملة` : `${patientsHistory.length} patients – complete records`}
              </Typography>
            </Box>
          </Box>

          {/* Search & Filters */}
          <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap' }}>
            <TextField
              placeholder={lang === 'ar' ? 'ابحث عن مريض أو تشخيص...' : 'Search by name or diagnosis...'}
              value={search} onChange={e => setSearch(e.target.value)}
              size="small" sx={{ flex: 1, minWidth: 200, '& .MuiOutlinedInput-root': { borderRadius: 2.5, '& fieldset': { borderColor: '#E2E8F0' }, '&.Mui-focused fieldset': { borderColor: '#0d9488' } } }}
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18, color: '#94A3B8' }} /></InputAdornment> }}
            />
            <Box sx={{ display: 'flex', gap: 1 }}>
              {['all', 'stable', 'warning', 'critical'].map(f => (
                <Chip key={f} clickable onClick={() => setFilterStatus(f)}
                  label={lang === 'ar' ? { all: 'الكل', stable: 'مستقر', warning: 'تحذير', critical: 'حرج' }[f] : f.charAt(0).toUpperCase() + f.slice(1)}
                  sx={{ fontWeight: 600, fontSize: 12, background: filterStatus === f ? btnGradient : 'white', color: filterStatus === f ? 'white' : '#64748B', border: '1px solid #E2E8F0' }} />
              ))}
            </Box>
          </Box>

          {/* Patient Cards */}
          <Grid container spacing={3}>
            {filtered.map(p => {
              const st = statusConfig[p.status];
              return (
                <Grid item xs={12} sm={6} lg={4} key={p.id}>
                  <Card sx={{ borderRadius: 3.5, border: `1px solid ${st.border}`, boxShadow: '0 2px 10px rgba(0,0,0,0.04)', cursor: 'pointer', transition: 'all 0.2s', '&:hover': { boxShadow: '0 6px 20px rgba(0,0,0,0.1)', transform: 'translateY(-2px)' } }}
                    onClick={() => setSelected(p)}>
                    <CardContent sx={{ p: 2.5 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                        <Avatar src={p.image} sx={{ width: 50, height: 50, borderRadius: 2.5 }} />
                        <Box sx={{ flex: 1, minWidth: 0 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.3 }}>
                            <Typography sx={{ fontWeight: 700, fontSize: 14.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{lang === 'ar' ? p.nameAr : p.name}</Typography>
                            <Chip label={lang === 'ar' ? st.labelAr : st.label} size="small" sx={{ background: st.bg, color: st.color, fontWeight: 700, fontSize: 10, height: 18, borderRadius: 1.5, flexShrink: 0 }} />
                          </Box>
                          <Typography sx={{ fontSize: 12, color: '#14B8A6', fontWeight: 600 }}>{lang === 'ar' ? p.diagnosisAr : p.diagnosis}</Typography>
                          <Typography sx={{ fontSize: 11, color: '#94A3B8' }}>{p.age}{lang === 'ar' ? ' سنة' : 'y'} · {lang === 'ar' ? p.genderAr : p.gender} · 🩸 {p.bloodType}</Typography>
                        </Box>
                      </Box>

                      <Divider sx={{ my: 1.5 }} />

                      <Box sx={{ mb: 1.5 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography sx={{ fontSize: 11.5, color: '#64748B', fontWeight: 600 }}>{lang === 'ar' ? 'الالتزام بالدواء' : 'Adherence'}</Typography>
                          <Typography sx={{ fontSize: 12, fontWeight: 700, color: p.medicationAdherence >= 70 ? '#22C55E' : p.medicationAdherence >= 50 ? '#F59E0B' : '#EF4444' }}>{p.medicationAdherence}%</Typography>
                        </Box>
                        <LinearProgress variant="determinate" value={p.medicationAdherence} sx={{ height: 4, borderRadius: 2, '& .MuiLinearProgress-bar': { background: p.medicationAdherence >= 70 ? '#22C55E' : p.medicationAdherence >= 50 ? '#F59E0B' : '#EF4444' } }} />
                      </Box>

                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <HistoryIcon sx={{ fontSize: 13, color: '#94A3B8' }} />
                          <Typography sx={{ fontSize: 12, color: '#64748B' }}>{p.visitHistory.length} {lang === 'ar' ? 'زيارة' : 'visits'}</Typography>
                        </Box>
                        <Typography sx={{ fontSize: 11, color: '#94A3B8' }}>{lang === 'ar' ? 'آخر زيارة:' : 'Last:'} {p.visitHistory[0]?.date}</Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>

          {filtered.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <Typography sx={{ fontSize: 40, mb: 2 }}>🔍</Typography>
              <Typography sx={{ fontSize: 16, color: '#94A3B8' }}>{lang === 'ar' ? 'لا توجد نتائج' : 'No results found'}</Typography>
            </Box>
          )}
        </Box>
      </Box>

      <PatientDetailDialog open={!!selected} onClose={() => setSelected(null)} patient={selected} lang={lang} navigate={navigate} />
    </Layout>
  );
}
