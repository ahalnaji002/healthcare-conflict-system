import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Box, Typography, TextField, IconButton, Avatar, Button } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import ImageIcon from '@mui/icons-material/Image';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import CallIcon from '@mui/icons-material/Call';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DescriptionIcon from '@mui/icons-material/Description';
import { useSelector } from 'react-redux';
import { chatMessages } from '../../data/mockData';
import { useTranslation } from 'react-i18next';

export default function Chat() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { list } = useSelector(s => s.appointments);
  const appt = list.find(a => a.id === Number(id)) || list[0];
  const [messages, setMessages] = useState(chatMessages);
  const [input, setInput] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, { id: Date.now(), sender: 'patient', text: input, time: new Date().toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }) }]);
    setInput('');
    setTimeout(() => {
      setMessages(prev => [...prev, { id: Date.now() + 1, sender: 'doctor', text: "Thank you for your message. I'll review this and get back to you shortly.", time: new Date().toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }) }]);
    }, 1500);
  };

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#F8FAFC' }}>
      {/* Header */}
      <Box sx={{ background: 'white', px: 2, py: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, boxShadow: '0 1px 8px rgba(0,0,0,0.06)', zIndex: 10 }}>
        <IconButton onClick={() => navigate('/appointments')} sx={{ color: '#188' }}>
          <ArrowBackIcon />
        </IconButton>

        <Box sx={{ position: 'relative' }}>
          <Avatar src={appt?.image} sx={{ width: 42, height: 42, borderRadius: 2 }} />
          <Box sx={{ position: 'absolute', bottom: 2, right: 2, width: 10, height: 10, borderRadius: '50%', background: '#22C55E', border: '2px solid white' }} />
        </Box>

        <Box sx={{ flex: 1 }}>
          <Typography sx={{ 
            fontWeight: 700, 
            fontSize: 15, 
            background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
            WebkitBackgroundClip: 'text', 
            WebkitTextFillColor: 'transparent', 
            backgroundClip: 'text',
            display: 'inline-block' 
          }}>
            {appt?.doctor || 'Dr. Sarah Mitchell'}
          </Typography>
          <Typography sx={{ fontSize: 12, color: '#188', fontWeight: 600 }}>● {t('chat.online')}</Typography>
        </Box>

        <IconButton sx={{ color: '#188' }}><VideoCallIcon /></IconButton>
        <IconButton sx={{ color: '#188' }}><CallIcon /></IconButton>
        <IconButton sx={{ color: '#188' }}><MoreVertIcon /></IconButton>
      </Box>

      {/* Messages */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: { xs: 2, md: 4 }, py: 3 }}>
        <Box sx={{ textAlign: 'center', mb: 3 }}>
          <Typography sx={{ fontSize: 12, color: '#94A3B8', background: 'white', display: 'inline-block', px: 2, py: 0.5, borderRadius: 2 }}>
            Today, Mar 31 2026
          </Typography>
        </Box>

        {messages.map(msg => {
          if (msg.type === 'prescription') {
            return (
              <Box key={msg.id} sx={{ display: 'flex', justifyContent: 'flex-start', mb: 2.5 }}>
                <Avatar src={appt?.image} sx={{ width: 32, height: 32, borderRadius: 1.5, mr: 1, alignSelf: 'flex-end', flexShrink: 0 }} />
                <Box>
                  <Typography sx={{ fontSize: 11, color: '#94A3B8', mb: 0.5 }}>Dr. Mitchell</Typography>
                  <Box sx={{ background: 'white', borderRadius: '16px 16px 16px 4px', p: 2, border: '1px solid #F1F5F9', maxWidth: 250 }}>
                    <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center', mb: 1.5 }}>
                      {/* التعديل: خلفية أيقونة الروشتة */}
                      <Box sx={{ 
                        width: 36, height: 36, borderRadius: '10px', 
                        background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)', 
                        display: 'flex', alignItems: 'center', justifyContent: 'center' 
                      }}>
                        <DescriptionIcon sx={{ color: 'white', fontSize: 18 }} />
                      </Box>
                      <Box>
                        <Typography sx={{ fontWeight: 700, fontSize: 13 }}>{t('chat.prescriptionSent')}</Typography>
                        <Typography sx={{ fontSize: 12, color: '#64748B' }}>2 {t('chat.medicationsPrescribed')}</Typography>
                      </Box>
                    </Box>
                    <Button fullWidth variant="contained" size="small"
                      sx={{ 
                        borderRadius: 2, fontSize: 12, fontWeight: 700,
                        background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                        color:"white",
                        '&:hover': { opacity: 0.9 }
                      }}>
                      {t('chat.viewPrescription')}
                    </Button>
                  </Box>
                  <Typography sx={{ fontSize: 11, color: '#94A3B8', mt: 0.5 }}>{msg.time}</Typography>
                </Box>
              </Box>
            );
          }

          const isPatient = msg.sender === 'patient';
          return (
            <Box key={msg.id} sx={{ display: 'flex', justifyContent: isPatient ? 'flex-end' : 'flex-start', mb: 2.5, gap: 1 }}>
              {!isPatient && <Avatar src={appt?.image} sx={{ width: 32, height: 32, borderRadius: 1.5, alignSelf: 'flex-end', flexShrink: 0 }} />}
              <Box sx={{ maxWidth: '70%' }}>
                {!isPatient && <Typography sx={{ fontSize: 11, color: '#94A3B8', mb: 0.5 }}>Dr. Mitchell</Typography>}
                <Box sx={{
                  px: 2, py: 1.5, borderRadius: isPatient ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                  background: isPatient ? "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)": 'white',
                  color: isPatient ? 'white' : '#0F172A',
                  boxShadow: isPatient ? '0 4px 14px rgba(13,148,136,0.2)' : '0 1px 6px rgba(0,0,0,0.06)',
                  border: isPatient ? 'none' : '1px solid #F1F5F9',
                }}>
                  <Typography sx={{ fontSize: 14, lineHeight: 1.6 }}>{msg.text}</Typography>
                </Box>
                <Typography sx={{ fontSize: 11, color: '#94A3B8', mt: 0.5, textAlign: isPatient ? 'right' : 'left' }}>{msg.time}</Typography>
              </Box>
            </Box>
          );
        })}
        <div ref={bottomRef} />
      </Box>

      {/* Input Section */}
      <Box sx={{ background: 'white', p: 2, boxShadow: '0 -1px 8px rgba(0,0,0,0.06)' }}>
        <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center', maxWidth: 900, mx: 'auto' }}>
          <IconButton sx={{ color: '#188' }}><AttachFileIcon /></IconButton>
          <IconButton sx={{ color: '#188' }}><ImageIcon /></IconButton>

          <TextField
            fullWidth
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && send()}
            placeholder={t('chat.typeMessage')}
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 3,
                background: '#F8FAFC',
                '& fieldset': { borderColor: '#E2E8F0' },
                // التعديل: تغيير اللون عند الـ Hover
                '&:hover fieldset': { borderColor: '#188 !important' },
                // التعديل: تغيير اللون عند الـ Focus
                '&.Mui-focused fieldset': { borderColor: '#188' },
              },
            }}
          />

          <IconButton onClick={send} disabled={!input.trim()}
            sx={{
              background: input.trim() ? "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)" : '#F1F5F9',
              color: input.trim() ? 'white' : '#94A3B8',
              borderRadius: 2.5, width: 46, height: 46, flexShrink: 0,
              transition: 'all 0.2s',
              '&:hover': { opacity: input.trim() ? 0.9 : 1 }
            }}>
            <SendIcon sx={{ fontSize: 20 }} />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
}