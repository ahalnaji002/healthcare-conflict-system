import React, { useState } from 'react';
import {
  Box, Typography, Chip, Button, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, Snackbar, Alert, ToggleButton, ToggleButtonGroup,
} from '@mui/material';
import AdminLayout from './AdminLayout';
import { complaints as initialComplaints } from '../../data/adminData';

const priorityColors = { 
  high: { bg: '#FEF2F2', color: '#DC2626' }, 
  medium: { bg: '#FFFBEB', color: '#D97706' }, 
  low: { bg: '#F0FDF4', color: '#15803D' } 
};
const statusColors = { 
  open: { bg: '#FFFBEB', color: '#D97706' }, 
  resolved: { bg: '#DCFCE7', color: '#15803D' } 
};

export default function Complaints() {
  const [complaints, setComplaints] = useState(initialComplaints);
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState(null);
  const [reply, setReply] = useState('');
  const [snack, setSnack] = useState({ open: false, msg: '' });

  const brandGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';
  const brandColor = '#0d9488';

  // ستايل الإدخال الموحد
  const inputStyle = {
    '& .MuiInputLabel-root.Mui-focused': { color: brandColor },
    '& .MuiOutlinedInput-root': {
      borderRadius: 3,
      '&:hover fieldset': { borderColor: `${brandColor} !important` },
      '&.Mui-focused fieldset': { borderColor: `${brandColor} !important` },
    },
  };

  const filtered = complaints.filter(c => filter === 'all' || c.status === filter);

  const handleResolve = (id) => {
    setComplaints(prev => prev.map(c => c.id === id ? { ...c, status: 'resolved' } : c));
    setSelected(null);
    setReply('');
    setSnack({ open: true, msg: 'Complaint resolved and reply sent.' });
  };

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 2.5, md: 4 } }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4, flexWrap: 'wrap', gap: 2 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800, color: '#0F172A', mb: 0.5 }}>Complaints</Typography>
            <Typography sx={{ color: '#64748B', fontSize: 15 }}>Review and resolve user complaints</Typography>
          </Box>
          
          <ToggleButtonGroup 
            value={filter} 
            exclusive 
            onChange={(_, v) => v && setFilter(v)} 
            size="small"
            sx={{ 
              '& .MuiToggleButton-root': { 
                borderRadius: '12px !important', 
                fontWeight: 700, 
                textTransform: 'none', 
                px: 2.5, 
                fontSize: 13,
                mx: 0.5,
                border: '1px solid #E2E8F0 !important',
                '&.Mui-selected': { 
                  background: brandGradient, 
                  color: 'white !important',
                  boxShadow: '0 4px 12px rgba(13,148,136,0.2)'
                } 
              } 
            }}
          >
            {[{ v: 'all', l: 'All' }, { v: 'open', l: `Open (${complaints.filter(c => c.status === 'open').length})` }, { v: 'resolved', l: 'Resolved' }].map(t => (
              <ToggleButton key={t.v} value={t.v}>
                {t.l}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {filtered.map(c => (
            <Box key={c.id} sx={{
              background: 'white', borderRadius: 4, p: 3, border: '1px solid #F1F5F9',
              display: 'flex', gap: 3, alignItems: 'center', flexWrap: 'wrap',
              transition: 'all 0.3s ease', 
              '&:hover': { boxShadow: '0 10px 25px rgba(0,0,0,0.04)', transform: 'translateY(-2px)' },
            }}>
              <Box sx={{ flex: 1, minWidth: 200 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5, flexWrap: 'wrap' }}>
                  <Typography sx={{ fontWeight: 800, fontSize: 15, color: '#0F172A' }}>{c.from}</Typography>
                  <Chip label={c.role} size="small" sx={{ background: '#F1F5F9', color: '#475569', fontWeight: 700, fontSize: 10, height: 20, textTransform: 'uppercase' }} />
                  <Chip label={c.priority} size="small" sx={{ ...priorityColors[c.priority], fontWeight: 700, fontSize: 10, height: 20, textTransform: 'uppercase' }} />
                  <Chip label={c.status} size="small" sx={{ ...statusColors[c.status], fontWeight: 700, fontSize: 10, height: 20, textTransform: 'uppercase' }} />
                </Box>
                <Typography sx={{ fontSize: 16, fontWeight: 700, color: '#1E293B', mb: 0.5 }}>{c.subject}</Typography>
                <Typography sx={{ fontSize: 13, color: '#94A3B8' }}>Submitted: {c.date}</Typography>
              </Box>
              
              {c.status === 'open' && (
                <Button 
                  variant="contained" 
                  onClick={() => setSelected(c)}
                  sx={{ 
                    borderRadius: 3, 
                    fontWeight: 700, 
                    background: brandGradient,
                    px: 3,
                    textTransform: 'none',
                    color:"white",
                    '&:hover': { background: brandGradient, opacity: 0.9 }
                  }}
                >
                  Resolve Now
                </Button>
              )}
              {c.status === 'resolved' && (
                <Box sx={{ display: 'flex', alignItems: 'center', color: brandColor, gap: 0.5 }}>
                   <Typography sx={{ fontWeight: 800, fontSize: 14 }}>✓ RESOLVED</Typography>
                </Box>
              )}
            </Box>
          ))}

          {filtered.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 10, background: 'white', borderRadius: 5, border: '1px dashed #CBD5E1' }}>
              <Typography sx={{ fontSize: 48, mb: 2 }}>✨</Typography>
              <Typography variant="h6" sx={{ color: '#0F172A', fontWeight: 700 }}>All caught up!</Typography>
              <Typography sx={{ color: '#64748B' }}>No complaints found in this category.</Typography>
            </Box>
          )}
        </Box>
      </Box>

      {/* Resolve Dialog */}
      <Dialog open={Boolean(selected)} onClose={() => { setSelected(null); setReply(''); }} maxWidth="sm" fullWidth
        PaperProps={{ sx: { borderRadius: 4, p: 1 } }}>
        {selected && (
          <>
            <DialogTitle sx={{ fontWeight: 800, color: '#0F172A' }}>Resolve Complaint</DialogTitle>
            <DialogContent sx={{ pt: '12px !important' }}>
              <Box sx={{ background: '#F8FAFC', borderRadius: 3, p: 2.5, mb: 3, border: '1px solid #F1F5F9' }}>
                <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
                  <Chip label={selected.from} size="small" sx={{ fontWeight: 700, background: 'rgba(13,148,136,0.1)', color: brandColor }} />
                  <Chip label={selected.priority} size="small" sx={{ ...priorityColors[selected.priority], fontWeight: 700 }} />
                </Box>
                <Typography sx={{ fontWeight: 700, fontSize: 15, color: '#0F172A', mb: 0.5 }}>{selected.subject}</Typography>
                <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>Ref ID: #{selected.id}</Typography>
              </Box>
              
              <TextField 
                fullWidth 
                multiline 
                rows={4} 
                label="Reply to User" 
                value={reply}
                onChange={e => setReply(e.target.value)} 
                placeholder="Write a professional response..."
                sx={inputStyle} 
              />
            </DialogContent>
            <DialogActions sx={{ px: 3, pb: 3, gap: 1.5 }}>
              <Button onClick={() => { setSelected(null); setReply(''); }} sx={{ fontWeight: 700, color: '#64748B' }}>Cancel</Button>
              <Button 
                onClick={() => handleResolve(selected.id)} 
                variant="contained" 
                sx={{ 
                    borderRadius: 3, 
                    fontWeight: 700, 
                    background: brandGradient,
                    px: 3,
                    '&:hover': { background: brandGradient, opacity: 0.9 }
                }}
              >
                Send Reply & Close
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      <Snackbar 
        open={snack.open} 
        autoHideDuration={3000} 
        onClose={() => setSnack({ ...snack, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert variant="filled" severity="success" sx={{ borderRadius: 3, fontWeight: 700, background: '#0F172A' }}>
          {snack.msg}
        </Alert>
      </Snackbar>
    </AdminLayout>
  );
}