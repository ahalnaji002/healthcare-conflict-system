import React, { useState } from 'react';
import {
  Box, Typography, Grid, Avatar, Chip, Button, Dialog, DialogTitle,
  DialogContent, DialogActions, Divider, Alert, Snackbar,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import DescriptionIcon from '@mui/icons-material/Description';
import AdminLayout from './AdminLayout';
import { pendingDoctors as initialDoctors } from '../../data/adminData';

export default function DoctorApprovals() {
  const [doctors, setDoctors] = useState(initialDoctors);
  const [selected, setSelected] = useState(null);
  const [snack, setSnack] = useState({ open: false, msg: '', severity: 'success' });

  const handleAction = (id, action) => {
    setDoctors(prev => prev.filter(d => d.id !== id));
    setSelected(null);
    setSnack({ open: true, msg: action === 'approve' ? 'Doctor account approved!' : 'Doctor account rejected.', severity: action === 'approve' ? 'success' : 'error' });
  };

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 2.5, md: 4 } }}>
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 0.5 }}>Doctor Approvals</Typography>
          <Typography sx={{ color: '#64748B', fontSize: 15 }}>Review and verify doctor registration requests</Typography>
        </Box>

        {doctors.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 10, background: 'white', borderRadius: 4, border: '1px solid #F1F5F9' }}>
            <Typography sx={{ fontSize: 48, mb: 2 }}>✅</Typography>
            <Typography variant="h6" sx={{ color: '#0F172A', mb: 1 }}>All caught up!</Typography>
            <Typography sx={{ color: '#64748B' }}>No pending doctor approvals at this time.</Typography>
          </Box>
        ) : (
          <Grid container spacing={3}>
            {doctors.map(doc => (
              <Grid item xs={12} md={6} lg={4} key={doc.id}>
                <Box sx={{
                  background: 'white', borderRadius: 4, p: 3, border: '1px solid #F1F5F9',
                  transition: 'all 0.2s', '&:hover': { boxShadow: '0 8px 24px #ccc', borderColor: '#fff' },
                }}>
                  <Box sx={{ display: 'flex', gap: 2, mb: 2.5 }}>
                    <Avatar src={doc.image} sx={{ width: 56, height: 56, borderRadius: 3 }} />
                    <Box>
                      <Typography sx={{ fontWeight: 700, fontSize: 15, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
         }}>{doc.name}</Typography>
                      <Chip label={doc.specialty} size="small" sx={{ background: 'rgba(17, 136, 136, 0.1)', color: '#188', fontWeight: 600, fontSize: 12, mt: 0.5 }} />
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 2.5, p: 2, background: '#F8FAFC', borderRadius: 2 }}>
                    {[
                      { label: 'Email', value: doc.email },
                      { label: 'Phone', value: doc.phone },
                      { label: 'Submitted', value: doc.submittedAt },
                    ].map(row => (
                      <Box key={row.label} sx={{ display: 'flex', justifyContent: 'space-between' }}>
                        <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>{row.label}</Typography>
                        <Typography sx={{ fontSize: 12, color: '#374151', fontWeight: 500 }}>{row.value}</Typography>
                      </Box>
                    ))}
                  </Box>

                  <Box sx={{ mb: 2.5 }}>
                    <Typography sx={{ fontSize: 12, color: '#64748B', fontWeight: 600, mb: 1 }}>Documents ({doc.documents.length})</Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.8 }}>
                      {doc.documents.map(d => (
                        <Box key={d} sx={{ display: 'flex', alignItems: 'center', gap: 0.5, background: '#F0FDF4', px: 1.2, py: 0.5, borderRadius: 1.5 }}>
                          <DescriptionIcon sx={{ fontSize: 12, color: '#16A34A' }} />
                          <Typography sx={{ fontSize: 11, color: '#16A34A', fontWeight: 600 }}>{d}</Typography>
                        </Box>
                      ))}
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', gap: 1.5 }}>
                    <Button fullWidth variant="outlined" onClick={() => setSelected(doc)}
                      sx={{ borderRadius: 2.5, fontWeight: 600, fontSize: 13, borderColor: '#E2E8F0', color: '#64748B' }}>
                      View Details
                    </Button>
                    <Button fullWidth variant="contained" onClick={() => handleAction(doc.id, 'approve')}
                      sx={{ borderRadius: 2.5, fontWeight: 700, fontSize: 13, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)' , color:"white", boxShadow: 'none' }}>
                      ✓ Approve
                    </Button>
                  </Box>
                  <Button fullWidth variant="outlined" color="error" onClick={() => handleAction(doc.id, 'reject')}
                    sx={{ borderRadius: 2.5, fontWeight: 600, fontSize: 13, mt: 1 }}>
                    ✕ Reject
                  </Button>
                </Box>
              </Grid>
            ))}
          </Grid>
        )}
      </Box>

      {/* Detail Dialog */}
      <Dialog open={Boolean(selected)} onClose={() => setSelected(null)} maxWidth="sm" fullWidth
        PaperProps={{ sx: { borderRadius: 4 } }}>
        {selected && (
          <>
            <DialogTitle sx={{ fontWeight: 700, pb: 1 }}>Doctor Application Details</DialogTitle>
            <DialogContent>
              <Box sx={{ display: 'flex', gap: 2, mb: 3, alignItems: 'center' }}>
                <Avatar src={selected.image} sx={{ width: 64, height: 64, borderRadius: 3 }} />
                <Box>
                  <Typography sx={{ fontWeight: 800, fontSize: 18,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', }}>{selected.name}</Typography>
                  <Typography sx={{ color: '#188', fontWeight: 600 }}>{selected.specialty}</Typography>
                </Box>
              </Box>
              <Divider sx={{ mb: 2 }} />
              {[
                { label: 'Email', value: selected.email },
                { label: 'Phone', value: selected.phone },
                { label: 'Submission Date', value: selected.submittedAt },
                { label: 'Documents Submitted', value: selected.documents.join(', ') },
              ].map(row => (
                <Box key={row.label} sx={{ display: 'flex', justifyContent: 'space-between', py: 1.2, borderBottom: '1px solid #F8FAFC' }}>
                  <Typography sx={{ color: '#64748B', fontSize: 14 }}>{row.label}</Typography>
                  <Typography sx={{ fontWeight: 600, fontSize: 14, maxWidth: '60%', textAlign: 'right' }}>{row.value}</Typography>
                </Box>
              ))}
            </DialogContent>
            <DialogActions sx={{ px: 3, pb: 3, gap: 1.5 }}>
              <Button onClick={() => setSelected(null)} variant="outlined" sx={{ borderRadius: 2.5,color:"#188" , borderColor:"#188" }}>Close</Button>
              <Button onClick={() => handleAction(selected.id, 'reject')} variant="outlined" color="error" sx={{ borderRadius: 2.5 }}>Reject</Button>
              <Button onClick={() => handleAction(selected.id, 'approve')} variant="contained" sx={{ borderRadius: 2.5, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',color:"white" }}>
                Approve
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      <Snackbar open={snack.open} autoHideDuration={3000} onClose={() => setSnack({ ...snack, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={snack.severity} sx={{ borderRadius: 2.5 }}>{snack.msg}</Alert>
      </Snackbar>
    </AdminLayout>
  );
}
