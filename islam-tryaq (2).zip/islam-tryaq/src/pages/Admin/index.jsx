import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, Grid, Card, CardContent, Avatar, Chip, LinearProgress, Button } from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import PeopleIcon from '@mui/icons-material/People';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import AdminLayout from './AdminLayout';
import { pendingDoctors, financialData, complaints } from '../../data/adminData';
import { allUsers } from '../../data/adminData';

const statCards = [
  { label: 'Total Users', value: '50,247', change: '+12%', icon: <PeopleIcon />, color: '#0EA5E9', bg: '#F0F9FF' },
  { label: 'Active Doctors', value: '512', change: '+8%', icon: <LocalHospitalIcon />, color: '#14B8A6', bg: '#F0FDF4' },
  { label: 'Monthly Revenue', value: '$24,700', change: '+16%', icon: <AttachMoneyIcon />, color: '#8B5CF6', bg: '#F5F3FF' },
  { label: 'Consultations', value: '1,840', change: '+21%', icon: <TrendingUpIcon />, color: '#F59E0B', bg: '#FFFBEB' },
];

export default function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 2.5, md: 4 } }}>
        {/* Header */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 0.5 }}>Dashboard</Typography>
          <Typography sx={{ color: '#64748B', fontSize: 15 }}>Welcome back, Admin. Here's what's happening today.</Typography>
        </Box>

        {/* Stat cards */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          {statCards.map((s, i) => (
            <Grid item xs={12} sm={6} lg={3} key={i}>
              <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
                <CardContent sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Box sx={{ width: 46, height: 46, borderRadius: '14px', background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: s.color }}>
                      {s.icon}
                    </Box>
                    <Chip label={s.change} size="small"
                      sx={{ background: '#F0FDF4', color: '#15803D', fontWeight: 700, fontSize: 12, height: 24 }} />
                  </Box>
                  <Typography sx={{ fontSize: 28, fontWeight: 800, color: '#0F172A', lineHeight: 1, mb: 0.5 }}>{s.value}</Typography>
                  <Typography sx={{ fontSize: 13, color: '#64748B' }}>{s.label}</Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        <Grid container spacing={3}>
          {/* Revenue chart (simple bar chart) */}
          <Grid item xs={12} lg={7}>
            <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', p: 3, boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Box>
                  <Typography sx={{ fontWeight: 700, fontSize: 16, color: '#0F172A' }}>Monthly Revenue</Typography>
                  <Typography sx={{ fontSize: 13, color: '#64748B' }}>Last 6 months performance</Typography>
                </Box>
                <Chip label="↑ 16% vs last month" size="small" sx={{ background: '#F0FDF4', color: '#15803D', fontWeight: 600 }} />
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: 1.5, height: 160 }}>
                {financialData.map((d, i) => {
                  const maxVal = Math.max(...financialData.map(x => x.revenue));
                  const pct = (d.revenue / maxVal) * 100;
                  const isLast = i === financialData.length - 1;
                  return (
                    <Box key={d.month} sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                      <Typography sx={{ fontSize: 11, color: isLast ? '#0EA5E9' : '#94A3B8', fontWeight: 600 }}>
                        ${(d.revenue / 1000).toFixed(1)}k
                      </Typography>
                      <Box sx={{
                        width: '100%', height: `${pct}%`, minHeight: 8, borderRadius: '6px 6px 0 0',
                        background: isLast ? 'linear-gradient(to top, #0EA5E9, #14B8A6)' : '#E2E8F0',
                        transition: 'all 0.3s',
                        '&:hover': { opacity: 0.85 },
                      }} />
                      <Typography sx={{ fontSize: 12, color: '#64748B', fontWeight: isLast ? 700 : 400 }}>{d.month}</Typography>
                    </Box>
                  );
                })}
              </Box>
            </Card>
          </Grid>

          {/* Pending doctors */}
          <Grid item xs={12} lg={5}>
            <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
              <Box sx={{ p: 3, pb: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography sx={{ fontWeight: 700, fontSize: 16, color: '#0F172A' }}>Pending Approvals</Typography>
                  <Typography sx={{ fontSize: 13, color: '#64748B' }}>{pendingDoctors.length} doctors awaiting review</Typography>
                </Box>
                <Button size="small" onClick={() => navigate('/admin/doctors')} sx={{ color: '#0EA5E9', fontWeight: 600, fontSize: 13 }}>View All</Button>
              </Box>
              <Box sx={{ px: 2, pb: 2 }}>
                {pendingDoctors.map(doc => (
                  <Box key={doc.id} sx={{ display: 'flex', alignItems: 'center', gap: 2, py: 1.5, borderBottom: '1px solid #F8FAFC' }}>
                    <Avatar src={doc.image} sx={{ width: 40, height: 40, borderRadius: 2 }} />
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography sx={{ fontWeight: 600, fontSize: 14, color: '#0F172A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{doc.name}</Typography>
                      <Typography sx={{ fontSize: 12, color: '#64748B' }}>{doc.specialty} · {doc.submittedAt}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 0.5 }}>
                      <Box sx={{ width: 30, height: 30, borderRadius: '50%', background: '#F0FDF4', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', '&:hover': { background: '#DCFCE7' } }}>
                        <CheckCircleIcon sx={{ fontSize: 16, color: '#16A34A' }} />
                      </Box>
                      <Box sx={{ width: 30, height: 30, borderRadius: '50%', background: '#FEF2F2', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', '&:hover': { background: '#FEE2E2' } }}>
                        <CancelIcon sx={{ fontSize: 16, color: '#DC2626' }} />
                      </Box>
                    </Box>
                  </Box>
                ))}
              </Box>
            </Card>
          </Grid>

          {/* Recent complaints */}
          <Grid item xs={12} md={6}>
            <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', p: 3, boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2.5 }}>
                <Typography sx={{ fontWeight: 700, fontSize: 16, color: '#0F172A' }}>Recent Complaints</Typography>
                <Button size="small" onClick={() => navigate('/admin/complaints')} sx={{ color: '#0EA5E9', fontWeight: 600, fontSize: 13 }}>View All</Button>
              </Box>
              {complaints.slice(0, 3).map(c => {
                const priorityColors = { high: '#EF4444', medium: '#F59E0B', low: '#22C55E' };
                const statusColors = { open: '#F59E0B', resolved: '#22C55E' };
                return (
                  <Box key={c.id} sx={{ py: 1.5, borderBottom: '1px solid #F8FAFC' }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                      <Typography sx={{ fontWeight: 600, fontSize: 13, color: '#0F172A' }}>{c.from}</Typography>
                      <Box sx={{ display: 'flex', gap: 0.8 }}>
                        <Chip label={c.priority} size="small" sx={{ height: 18, fontSize: 10, fontWeight: 700, background: `${priorityColors[c.priority]}20`, color: priorityColors[c.priority] }} />
                        <Chip label={c.status} size="small" sx={{ height: 18, fontSize: 10, fontWeight: 700, background: `${statusColors[c.status]}20`, color: statusColors[c.status] }} />
                      </Box>
                    </Box>
                    <Typography sx={{ fontSize: 12, color: '#64748B', lineHeight: 1.4 }}>{c.subject}</Typography>
                  </Box>
                );
              })}
            </Card>
          </Grid>

          {/* System health */}
          <Grid item xs={12} md={6}>
            <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', p: 3, boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
              <Typography sx={{ fontWeight: 700, fontSize: 16, color: '#0F172A', mb: 2.5 }}>Platform Health</Typography>
              {[
                { label: 'API Uptime', value: 99.9, color: '#22C55E' },
                { label: 'Video Service', value: 98.2, color: '#0EA5E9' },
                { label: 'Payment Gateway', value: 100, color: '#14B8A6' },
                { label: 'Auth System', value: 99.5, color: '#8B5CF6' },
              ].map(item => (
                <Box key={item.label} sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.8 }}>
                    <Typography sx={{ fontSize: 13, color: '#374151', fontWeight: 500 }}>{item.label}</Typography>
                    <Typography sx={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}%</Typography>
                  </Box>
                  <LinearProgress variant="determinate" value={item.value}
                    sx={{ height: 6, borderRadius: 3, background: '#F1F5F9', '& .MuiLinearProgress-bar': { background: item.color, borderRadius: 3 } }} />
                </Box>
              ))}
            </Card>
          </Grid>
        </Grid>
      </Box>
    </AdminLayout>
  );
}
