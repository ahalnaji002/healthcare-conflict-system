import React, { useState } from 'react';
import {
  Box, Typography, Grid, TextField, Button, IconButton, Dialog,
  DialogTitle, DialogContent, DialogActions, Snackbar, Alert,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AdminLayout from './AdminLayout';
import { adminSpecialties as initialSpecialties } from '../../data/adminData';

export default function Specialties() {
  const [specialties, setSpecialties] = useState(initialSpecialties);
  const [dialog, setDialog] = useState({ open: false, mode: 'add', item: null });
  const [form, setForm] = useState({ name: '', nameAr: '', icon: '🩺' });
  const [snack, setSnack] = useState({ open: false, msg: '' });

  const brandGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';
  const brandColor = '#0d9488';

  const openAdd = () => { setForm({ name: '', nameAr: '', icon: '🩺' }); setDialog({ open: true, mode: 'add', item: null }); };
  const openEdit = (item) => { setForm({ name: item.name, nameAr: item.nameAr, icon: item.icon }); setDialog({ open: true, mode: 'edit', item }); };

  const handleSave = () => {
    if (!form.name) return;
    if (dialog.mode === 'add') {
      if (specialties.find(s => s.name.toLowerCase() === form.name.toLowerCase())) {
        setSnack({ open: true, msg: 'Specialty already exists!' }); return;
      }
      setSpecialties(prev => [...prev, { id: Date.now(), ...form, doctors: 0 }]);
      setSnack({ open: true, msg: 'Specialty added successfully!' });
    } else {
      setSpecialties(prev => prev.map(s => s.id === dialog.item.id ? { ...s, ...form } : s));
      setSnack({ open: true, msg: 'Specialty updated!' });
    }
    setDialog({ open: false, mode: 'add', item: null });
  };

  const handleDelete = (id) => {
    setSpecialties(prev => prev.filter(s => s.id !== id));
    setSnack({ open: true, msg: 'Specialty deleted.' });
  };

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 2.5, md: 4 } }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4, flexWrap: 'wrap', gap: 2 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800,  mb: 0.5 , background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',}}>Medical Specialties</Typography>
            <Typography sx={{ color: '#64748B', fontSize: 15 }}>Manage available medical specialties on the platform</Typography>
          </Box>
          <Button 
            variant="contained" 
            startIcon={<AddIcon />} 
            onClick={openAdd} 
            sx={{ 
                borderRadius: 3, 
                fontWeight: 700,
                background: brandGradient,
                textTransform: 'none',
                px: 3,
                color:"white",
                '&:hover': { background: brandGradient, opacity: 0.9 }
            }}
          >
            Add Specialty
          </Button>
        </Box>

        <Grid container spacing={2.5}>
          {specialties.map(sp => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={sp.id}>
              <Box sx={{
                background: 'white', borderRadius: 4, p: 3, border: '1px solid #F1F5F9',
                display: 'flex', alignItems: 'center', gap: 2, position: 'relative',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)', 
                '&:hover': { 
                    boxShadow: '0 10px 25px rgba(13,148,136,0.1)', 
                    borderColor: brandColor,
                    transform: 'translateY(-4px)'
                },
              }}>
                <Box sx={{ 
                    width: 50, height: 50, borderRadius: '14px', 
                    background: 'rgba(13, 148, 136, 0.08)', // خلفية خضراء ناعمة
                    display: 'flex', alignItems: 'center', justifyContent: 'center', 
                    fontSize: 24, flexShrink: 0 
                }}>
                  {sp.icon}
                </Box>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {sp.name}
                  </Typography>
                  <Typography sx={{ fontSize: 12, color: '#64748B' }}>{sp.nameAr}</Typography>
                  <Typography sx={{ fontSize: 12, color: brandColor, fontWeight: 700, mt: 0.3 }}>{sp.doctors} doctors</Typography>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                  <IconButton size="small" onClick={() => openEdit(sp)} sx={{ color: '#64748B', '&:hover': { color: brandColor, background: 'rgba(13,148,136,0.1)' } }}>
                    <EditIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                  <IconButton size="small" onClick={() => handleDelete(sp.id)} sx={{ color: '#64748B', '&:hover': { color: '#EF4444', background: '#FEF2F2' } }}>
                    <DeleteIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Box>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Dialog for Add/Edit */}
      <Dialog open={dialog.open} onClose={() => setDialog({ ...dialog, open: false })} maxWidth="sm" fullWidth
        PaperProps={{ sx: { borderRadius: 4, p: 1 } }}>
        <DialogTitle sx={{ fontWeight: 800, color: '#0F172A' }}>
            {dialog.mode === 'add' ? 'Add New Specialty' : 'Edit Specialty'}
        </DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, pt: '12px !important' }}>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <TextField label="Emoji Icon" value={form.icon} onChange={e => setForm({ ...form, icon: e.target.value })}
             sx={{
    // 1. اللون الافتراضي لليبل (قبل التركيز)
    '& .MuiInputLabel-root': {
      color: '#64748B', 
    },
    // 2. لون لليبل عند التركيز (Focus)
    '& .MuiInputLabel-root.Mui-focused': {
      color: '#0d9488',
    },
    '& .MuiOutlinedInput-root': {
      borderRadius: 3,
      // 3. لون البوردر في الحالة العادية
      '& fieldset': {
        borderColor: '#E2E8F0', 
      },
      // 4. لون البوردر عند الهوفر (Hover)
      '&:hover fieldset': {
        borderColor: '#0d9488 !important', 
      },
      // 5. لون البوردر عند التركيز (Focus)
      '&.Mui-focused fieldset': {
        borderColor: '#0d9488 !important',
      },
    },
  }} />
            <TextField fullWidth label="Specialty Name (EN)" value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Cardiology"
              sx={{
    // 1. اللون الافتراضي لليبل (قبل التركيز)
    '& .MuiInputLabel-root': {
      color: '#64748B', 
    },
    // 2. لون لليبل عند التركيز (Focus)
    '& .MuiInputLabel-root.Mui-focused': {
      color: '#0d9488',
    },
    '& .MuiOutlinedInput-root': {
      borderRadius: 3,
      // 3. لون البوردر في الحالة العادية
      '& fieldset': {
        borderColor: '#E2E8F0', 
      },
      // 4. لون البوردر عند الهوفر (Hover)
      '&:hover fieldset': {
        borderColor: '#0d9488 !important', 
      },
      // 5. لون البوردر عند التركيز (Focus)
      '&.Mui-focused fieldset': {
        borderColor: '#0d9488 !important',
      },
    },
  }}
              />
          </Box>
          <TextField fullWidth label="Specialty Name (AR)" value={form.nameAr}
            onChange={e => setForm({ ...form, nameAr: e.target.value })} placeholder="e.g. أمراض القلب"
            inputProps={{ dir: 'rtl' }} 
            
            sx={{
    // 1. اللون الافتراضي لليبل (قبل التركيز)
    '& .MuiInputLabel-root': {
      color: '#64748B', 
    },
    // 2. لون لليبل عند التركيز (Focus)
    '& .MuiInputLabel-root.Mui-focused': {
      color: '#0d9488',
    },
    '& .MuiOutlinedInput-root': {
      borderRadius: 3,
      // 3. لون البوردر في الحالة العادية
      '& fieldset': {
        borderColor: '#E2E8F0', 
      },
      // 4. لون البوردر عند الهوفر (Hover)
      '&:hover fieldset': {
        borderColor: '#0d9488 !important', 
      },
      // 5. لون البوردر عند التركيز (Focus)
      '&.Mui-focused fieldset': {
        borderColor: '#0d9488 !important',
      },
    },
  }} />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, gap: 1.5 }}>
          <Button onClick={() => setDialog({ ...dialog, open: false })} sx={{ borderRadius: 2.5, fontWeight: 600, color: '#64748B' }}>Cancel</Button>
          <Button 
            onClick={handleSave} 
            variant="contained" 
            sx={{ 
                borderRadius: 3, 
                fontWeight: 700, 
                background: brandGradient,
                color:"white",
                '&:hover': { background: brandGradient, opacity: 0.9 }
            }}
          >
            {dialog.mode === 'add' ? 'Add Specialty' : 'Save Changes'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snack.open} autoHideDuration={3000} onClose={() => setSnack({ ...snack, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity="success" sx={{ borderRadius: 3, fontWeight: 600, background: '#0F172A', color: 'white' }}>{snack.msg}</Alert>
      </Snackbar>
    </AdminLayout>
  );
}