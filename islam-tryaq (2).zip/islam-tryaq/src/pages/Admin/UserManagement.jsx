import React, { useState } from 'react';
import {
  Box, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Avatar, Chip, IconButton, Menu, MenuItem,
  TextField, InputAdornment, ToggleButton, ToggleButtonGroup, Snackbar, Alert,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AdminLayout from './AdminLayout';
import { allUsers as initialUsers } from '../../data/adminData';

import PauseIcon from '@mui/icons-material/Pause';
import DeleteIcon from '@mui/icons-material/Delete';

// تحديث الألوان لتناسب الهوية الجديدة
const roleColors = { 
  patient: { bg: '#F0FDF4', color: '#0d9488' }, 
  doctor: { bg: '#F0F9FF', color: '#0284C7' }, 
  admin: { bg: '#F5F3FF', color: '#7C3AED' } 
};
const statusColors = { 
  active: { bg: '#DCFCE7', color: '#15803D' }, 
  suspended: { bg: '#FEF2F2', color: '#DC2626' } 
};

export default function UserManagement() {
  const [users, setUsers] = useState(initialUsers);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [anchorEl, setAnchorEl] = useState(null);
  const [activeUser, setActiveUser] = useState(null);
  const [snack, setSnack] = useState({ open: false, msg: '', severity: 'success' });

  const brandGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';
  const brandColor = '#0d9488';

  const filtered = users.filter(u => {
    const matchQ = !query || u.name.toLowerCase().includes(query.toLowerCase()) || u.email.toLowerCase().includes(query.toLowerCase());
    const matchF = filter === 'all' || u.role === filter;
    return matchQ && matchF;
  });

  const handleAction = (action) => {
    if (action === 'activate') {
      setUsers(prev => prev.map(u => u.id === activeUser.id ? { ...u, status: 'active' } : u));
      setSnack({ open: true, msg: 'User activated.', severity: 'success' });
    } else if (action === 'suspend') {
      setUsers(prev => prev.map(u => u.id === activeUser.id ? { ...u, status: 'suspended' } : u));
      setSnack({ open: true, msg: 'User suspended.', severity: 'warning' });
    } else if (action === 'delete') {
      setUsers(prev => prev.filter(u => u.id !== activeUser.id));
      setSnack({ open: true, msg: 'User deleted.', severity: 'error' });
    }
    setAnchorEl(null);
    setActiveUser(null);
  };

  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 2.5, md: 4 } }}>
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 0.5 }}>User Management</Typography>
          <Typography sx={{ color: '#64748B', fontSize: 15 }}>Manage patient and doctor accounts</Typography>
        </Box>

        {/* Filters Section */}
        <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap', alignItems: 'center' }}>
          <TextField 
            value={query} 
            onChange={e => setQuery(e.target.value)} 
            placeholder="Search users..."
            size="small" 
            sx={{ 
              minWidth: 280, 
              '& .MuiOutlinedInput-root': { 
                borderRadius: 3, 
                background: 'white',
                '&:hover fieldset': { borderColor: brandColor },
                '&.Mui-focused fieldset': { borderColor: brandColor },
              } 
            }}
            InputProps={{ 
              startAdornment: <InputAdornment position="start"><SearchIcon sx={{ color: '#94A3B8', fontSize: 18 }} /></InputAdornment> 
            }} 
          />
          
          <ToggleButtonGroup 
            value={filter} 
            exclusive 
            onChange={(_, v) => v && setFilter(v)} 
            size="small"
            sx={{ 
              '& .MuiToggleButton-root': { 
                borderRadius: '12px !important', 
                fontWeight: 700, 
                fontSize: 13, 
                px: 3, 
                mx: 0.5,
                textTransform: 'none',
                border: '1px solid #E2E8F0 !important',
                '&.Mui-selected': { 
                  background: brandGradient, 
                  color: 'white !important',
                  boxShadow: '0 4px 12px rgba(13,148,136,0.2)'
                } 
              } 
            }}
          >
            {['all', 'patient', 'doctor'].map(f => (
              <ToggleButton key={f} value={f}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
        </Box>

        {/* Table Section */}
        <TableContainer component={Paper} sx={{ borderRadius: 4, border: '1px solid #F1F5F9', boxShadow: '0 4px 20px rgba(0,0,0,0.03)', overflow: 'hidden' }}>
          <Table>
            <TableHead>
              <TableRow sx={{ background: '#F8FAFC' }}>
                {['User', 'Role', 'Status', 'Joined', 'Appointments', 'Actions'].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, fontSize: 13, color: '#64748B', borderBottom: '1px solid #F1F5F9', py: 2.5 }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.map(user => (
                <TableRow key={user.id} sx={{ '&:hover': { background: '#F0FDF4/20' }, '& td': { borderBottom: '1px solid #F8FAFC' } }}>
                  <TableCell sx={{ py: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Avatar sx={{ 
                        width: 40, height: 40, 
                        background: brandGradient, 
                        fontSize: 14, fontWeight: 700, 
                        borderRadius: 2 
                      }}>
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </Avatar>
                      <Box>
                        <Typography sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{user.name}</Typography>
                        <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>{user.email}</Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip label={user.role} size="small"
                      sx={{ ...roleColors[user.role], fontWeight: 700, fontSize: 11, height: 24, borderRadius: 1.5, textTransform: 'uppercase' }} />
                  </TableCell>
                  <TableCell>
                    <Chip label={user.status} size="small"
                      sx={{ ...statusColors[user.status], fontWeight: 700, fontSize: 11, height: 24, borderRadius: 1.5, textTransform: 'uppercase' }} />
                  </TableCell>
                  <TableCell sx={{ color: '#64748B', fontSize: 13 }}>{user.joined}</TableCell>
                  <TableCell sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A', textAlign: 'center' }}>{user.appointments}</TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={e => { setAnchorEl(e.currentTarget); setActiveUser(user); }} sx={{ color: '#94A3B8', '&:hover': { color: brandColor } }}>
                      <MoreVertIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Action Menu */}
        <Menu 
          anchorEl={anchorEl} 
          open={Boolean(anchorEl)} 
          onClose={() => { setAnchorEl(null); setActiveUser(null); }}
          PaperProps={{ sx: { borderRadius: 3, boxShadow: '0 8px 24px rgba(0,0,0,0.12)', minWidth: 160, mt: 1 } }}
        >
          {activeUser?.status === 'suspended' ? (
            <MenuItem onClick={() => handleAction('activate')} sx={{ gap: 1.5, fontSize: 14, color: '#16A34A', fontWeight: 600 }}>✅ Activate User</MenuItem>
          ) : (
            <MenuItem onClick={() => handleAction('suspend')} sx={{ gap: 1.5, fontSize: 14, color: '#188', fontWeight: 600 }}><PauseIcon/> Suspend User</MenuItem>
          )}
          <MenuItem onClick={() => handleAction('delete')} sx={{ gap: 1.5, fontSize: 14, color: '#DC2626', fontWeight: 600 }}><DeleteIcon/> Delete User</MenuItem>
        </Menu>

        <Snackbar 
          open={snack.open} 
          autoHideDuration={3000} 
          onClose={() => setSnack({ ...snack, open: false })}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <Alert severity={snack.severity} variant="filled" sx={{ borderRadius: 3, fontWeight: 600 }}>{snack.msg}</Alert>
        </Snackbar>
      </Box>
    </AdminLayout>
  );
}