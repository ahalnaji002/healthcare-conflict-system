import React from 'react';
import { Box, Typography, Grid, Card, Chip, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import AdminLayout from './AdminLayout';
import { financialData } from '../../data/adminData';

const transactions = [
  { id: 'TXN-001', patient: 'John Doe', doctor: 'Dr. Sarah Mitchell', amount: 120, date: 'Mar 31, 2026', status: 'completed', type: 'Video Call' },
  { id: 'TXN-002', patient: 'Maria Garcia', doctor: 'Dr. Amira Hassan', amount: 85, date: 'Mar 30, 2026', status: 'completed', type: 'Text Chat' },
  { id: 'TXN-003', patient: 'Ahmed Al-Rashid', doctor: 'Dr. James Cooper', amount: 95, date: 'Mar 30, 2026', status: 'refunded', type: 'Video Call' },
  { id: 'TXN-004', patient: 'Linda Parker', doctor: 'Dr. Michael Torres', amount: 150, date: 'Mar 29, 2026', status: 'completed', type: 'Video Call' },
  { id: 'TXN-005', patient: 'Robert Williams', doctor: 'Dr. Emily Chen', amount: 110, date: 'Mar 29, 2026', status: 'completed', type: 'Video Call' },
  { id: 'TXN-006', patient: 'Sarah Johnson', doctor: 'Dr. Omar Khalil', amount: 130, date: 'Mar 28, 2026', status: 'pending', type: 'Text Chat' },
];

const statusColors = {
  completed: { bg: '#DCFCE7', color: '#15803D' },
  refunded: { bg: '#FEF2F2', color: '#DC2626' },
  pending: { bg: '#FFFBEB', color: '#D97706' },
};

const brandGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';
const brandColor = '#0d9488';

const maxRevenue = Math.max(...financialData.map(d => d.revenue));

export default function FinancialReports() {
  return (
    <AdminLayout>
      <Box sx={{ p: { xs: 2.5, md: 4 } }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4, flexWrap: 'wrap', gap: 2 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 0.5 }}>Financial Reports</Typography>
            <Typography sx={{ color: '#64748B', fontSize: 15 }}>Monitor transactions and platform revenue</Typography>
          </Box>
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            sx={{ 
                borderRadius: 3, 
                fontWeight: 700, 
                borderColor: brandColor, 
                color: brandColor,
                px: 2.5,
                '&:hover': { borderColor: '#0b7a6f', background: 'rgba(13, 148, 136, 0.04)' }
            }}
          >
            Export CSV
          </Button>
        </Box>

        {/* Summary cards */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          {[
            { label: 'Total Revenue', value: '$24,700', sub: 'This month', color: brandColor },
            { label: 'Total Consultations', value: '206', sub: 'This month', color: '#0f172a' },
            { label: 'Avg. Per Session', value: '$119.9', sub: 'This month', color: brandColor },
            { label: 'Refunds Issued', value: '$285', sub: '3 refunds', color: '#EF4444' },
          ].map((s, i) => (
            <Grid item xs={6} md={3} key={i}>
              <Card sx={{ borderRadius: 4, p: 2.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 12px rgba(0,0,0,0.02)' }}>
                <Typography sx={{ fontSize: 24, fontWeight: 800, color: s.color, mb: 0.3 }}>{s.value}</Typography>
                <Typography sx={{ fontSize: 14, fontWeight: 700, color: '#475569' }}>{s.label}</Typography>
                <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>{s.sub}</Typography>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Bar Chart */}
        <Card sx={{ borderRadius: 4, p: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 4px 20px rgba(0,0,0,0.03)', mb: 4 }}>
          <Typography sx={{ fontWeight: 800, fontSize: 16, color: '#0F172A', mb: 0.5 }}>Revenue Over Time</Typography>
          <Typography sx={{ fontSize: 13, color: '#64748B', mb: 4 }}>Monthly revenue for the last 6 months</Typography>
          <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: { xs: 1, md: 3 }, height: 200, px: 2 }}>
            {financialData.map((d, i) => {
              const pct = (d.revenue / maxRevenue) * 100;
              const isLast = i === financialData.length - 1;
              return (
                <Box key={d.month} sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1.5 }}>
                  <Typography sx={{ fontSize: 11, fontWeight: 800, color: isLast ? brandColor : '#94A3B8' }}>
                    ${(d.revenue / 1000).toFixed(1)}k
                  </Typography>
                  <Box sx={{
                    width: '100%', 
                    maxWidth: 40,
                    height: `${pct}%`, 
                    minHeight: 10, 
                    borderRadius: '10px 10px 4px 4px',
                    background: isLast ? brandGradient : '#E2E8F0',
                    boxShadow: isLast ? '0 6px 16px rgba(13,148,136,0.25)' : 'none',
                    transition: 'all 0.3s ease', 
                    '&:hover': { opacity: 0.8, transform: 'scaleX(1.05)' },
                  }} />
                  <Typography sx={{ fontSize: 12, color: isLast ? '#0F172A' : '#94A3B8', fontWeight: isLast ? 800 : 500 }}>{d.month}</Typography>
                </Box>
              );
            })}
          </Box>
        </Card>

        {/* Transactions table */}
        <Card sx={{ borderRadius: 4, border: '1px solid #F1F5F9', boxShadow: '0 4px 20px rgba(0,0,0,0.03)', overflow: 'hidden' }}>
          <Box sx={{ p: 3, borderBottom: '1px solid #F8FAFC', background: '#ffffff' }}>
            <Typography sx={{ fontWeight: 800, fontSize: 16, color: '#0F172A' }}>Recent Transactions</Typography>
          </Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ background: '#F8FAFC' }}>
                  {['Transaction ID', 'Patient', 'Doctor', 'Type', 'Amount', 'Date', 'Status'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 800, fontSize: 12, color: '#64748B', py: 2, borderBottom: '1px solid #F1F5F9' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {transactions.map(tx => (
                  <TableRow key={tx.id} sx={{ '&:hover': { background: '#F0FDF4/30' }, '& td': { borderBottom: '1px solid #F8FAFC' } }}>
                    <TableCell sx={{ fontSize: 13, fontWeight: 700, color: brandColor }}>{tx.id}</TableCell>
                    <TableCell sx={{ fontSize: 13, fontWeight: 600, color: '#0F172A' }}>{tx.patient}</TableCell>
                    <TableCell sx={{ fontSize: 13, color: '#64748B' }}>{tx.doctor}</TableCell>
                    <TableCell>
                        <Chip label={tx.type} size="small" sx={{ background: '#F1F5F9', color: '#475569', fontWeight: 700, fontSize: 10, height: 22 }} />
                    </TableCell>
                    <TableCell sx={{ fontWeight: 800, fontSize: 14, color: '#0F172A' }}>${tx.amount}</TableCell>
                    <TableCell sx={{ fontSize: 13, color: '#64748B' }}>{tx.date}</TableCell>
                    <TableCell>
                      <Chip 
                        label={tx.status} 
                        size="small" 
                        sx={{ 
                            ...statusColors[tx.status], 
                            fontWeight: 800, 
                            fontSize: 10, 
                            height: 22, 
                            borderRadius: 1.5,
                            textTransform: 'uppercase'
                        }} 
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Card>
      </Box>
    </AdminLayout>
  );
}