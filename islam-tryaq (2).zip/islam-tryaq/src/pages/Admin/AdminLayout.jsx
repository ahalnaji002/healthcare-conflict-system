import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Drawer, List, ListItem, ListItemIcon, ListItemText,
  Avatar, Divider, IconButton, useMediaQuery, useTheme, Chip,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import AssignmentIcon from '@mui/icons-material/Assignment';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import ReportProblemIcon from '@mui/icons-material/ReportProblem';
import MenuIcon from '@mui/icons-material/Menu';
import LogoutIcon from '@mui/icons-material/Logout';
import CloseIcon from '@mui/icons-material/Close';
import { useDispatch } from 'react-redux';
import { logout } from '../../store/slices/authSlice';

const SIDEBAR_WIDTH = 256;

const navItems = [
  { path: '/admin', label: 'Dashboard', icon: <DashboardIcon fontSize="small" /> },
  { path: '/admin/doctors', label: 'Doctor Approvals', icon: <LocalHospitalIcon fontSize="small" />, badge: 3 },
  { path: '/admin/users', label: 'User Management', icon: <PeopleIcon fontSize="small" /> },
  { path: '/admin/specialties', label: 'Specialties', icon: <AssignmentIcon fontSize="small" /> },
  { path: '/admin/finance', label: 'Financial Reports', icon: <AttachMoneyIcon fontSize="small" /> },
  { path: '/admin/complaints', label: 'Complaints', icon: <ReportProblemIcon fontSize="small" />, badge: 3 },
];

function SidebarContent({ onClose }) {
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const isActive = (path) => path === '/admin' ? location.pathname === '/admin' : location.pathname.startsWith(path);


  
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)' }}>
      {/* Logo */}
      <Box sx={{ px: 3, py: 3, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>

        <Box sx={{ display: 'flex', alignItems: 'center' }}>

         <Box 
    onClick={() => navigate('/')} // يوجهك لصفحة الهوم
    sx={{ 
      width: 48, 
      height: 48, 
      borderRadius: '12px', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      overflow: 'hidden',
      cursor: 'pointer', // يجعل الماوس يظهر كيد ضاغطة
      transition: 'transform 0.2s',
      '&:hover': { transform: 'scale(1.05)' } // تأثير بسيط عند الهوفر
    }}
  >
    <img 
      src="/logo.png" 
      alt="Home" 
      style={{ 
        width: '100%', 
        height: '100%', 
        objectFit: 'contain' 
      }} 
    />
  </Box>

          <Box>
            <Typography sx={{ color: 'white', fontWeight: 700, fontSize: 17, fontFamily: "'Sora',sans-serif", lineHeight: 1 }}>Teryaq</Typography>
            <Typography sx={{ color: 'rgba(255,255,255,0.6)', fontSize: 10, fontWeight: 600, letterSpacing: 1 }}>ADMIN PANEL</Typography>
          </Box>
        </Box>
        {onClose && <IconButton onClick={onClose} sx={{ color: '#64748B' }}><CloseIcon /></IconButton>}
      </Box>

      <Divider sx={{ borderColor: 'white', mx: 2 }} />

      {/* Nav */}
      <List sx={{ px: 2, pt: 2, flex: 1 }}>
        {navItems.map(item => {
          const active = isActive(item.path);
          return (
            <ListItem
              key={item.path}
              component={Link}
              to={item.path}
              onClick={onClose}
              sx={{
                borderRadius: 2.5, mb: 0.5, py: 1.2,
                background: active ? 'linear-gradient(135deg, rgba(14,165,233,0.2), rgba(20,184,166,0.2))' : 'transparent',
                border: active ? '1px solid rgba(14,165,233,0.2)' : '1px solid transparent',
                '&:hover': { background: 'rgba(255,255,255,0.05)' },
                transition: 'all 0.2s',
                textDecoration: 'none',
              }}
            >
              <ListItemIcon sx={{ minWidth: 36, color: active ? 'white' : '#64748B' }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{ fontSize: 14, fontWeight: active ? 600 : 400, color: active ? 'white' : '#94A3B8' }}
              />
              {item.badge && (
                <Chip label={item.badge} size="small"
                  sx={{ height: 20, fontSize: 11, fontWeight: 700, background: '#EF4444', color: 'white', minWidth: 20 }} />
              )}
            </ListItem>
          );
        })}
      </List>

      {/* Admin user */}
      <Divider sx={{ borderColor: 'white', mx: 2 }} />
      <Box sx={{ p: 2.5, display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Avatar sx={{ width: 38, height: 38, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)', fontSize: 14, fontWeight: 700 }}>AD</Avatar>
        <Box sx={{ flex: 1 }}>
          <Typography sx={{ color: 'white', fontWeight: 600, fontSize: 13 }}>Admin User</Typography>
          <Typography sx={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: 11 }}>admin@teryaq.com</Typography>
        </Box>
        <IconButton size="small" onClick={() => { dispatch(logout()); navigate('/'); }} sx={{ color: 'white', '&:hover': { color: 'white' } }}>
          <LogoutIcon fontSize="small"  />
        </IconButton>
      </Box>
    </Box>
  );
}

export default function AdminLayout({ children }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', background: '#F8FAFC' }}>
      {/* Desktop sidebar */}
      {!isMobile && (
        <Box sx={{ width: SIDEBAR_WIDTH, flexShrink: 0 }}>
          <Box sx={{ position: 'fixed', top: 0, left: 0, bottom: 0, width: SIDEBAR_WIDTH, zIndex: 100 }}>
            <SidebarContent />
          </Box>
        </Box>
      )}

      {/* Mobile drawer */}
      <Drawer
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        PaperProps={{ sx: { width: SIDEBAR_WIDTH, border: 'none' } }}
      >
        <SidebarContent onClose={() => setMobileOpen(false)} />
      </Drawer>

      {/* Main content */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Mobile top bar */}
        {isMobile && (
          <Box sx={{ background: '#0F172A', px: 2, py: 1.5, display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <IconButton onClick={() => setMobileOpen(true)} sx={{ color: 'white' }}><MenuIcon /></IconButton>
            <Typography sx={{ color: 'white', fontWeight: 700, fontFamily: "'Sora',sans-serif" }}>Teryaq Admin</Typography>
          </Box>
        )}
        <Box sx={{ flex: 1, overflow: 'auto' }}>
          {children}
        </Box>
      </Box>
    </Box>
  );
}
