import React, { useState } from 'react';
import { useLocation, useNavigate, Navigate } from 'react-router-dom';
import { 
  Box, Typography, Button, Container, Grid, TextField, 
  CircularProgress, Divider, Stack, Paper, Avatar 
} from '@mui/material';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline'; // أيقونة الفشل
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import Layout from '../../components/layout/Layout';
import { useDispatch, useSelector } from 'react-redux';
import { addAppointment } from '../../store/slices/appointmentsSlice';

export default function Booking() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isAuthenticated } = useSelector(s => s.auth);
  
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('idle'); // 'idle' | 'success' | 'error'
  const [card, setCard] = useState({ name: '', number: '', expiry: '', cvv: '' });

  if (!state?.doctor) return <Navigate to="/doctors" replace />;
  if (!isAuthenticated) return <Navigate to="/login" state={{ from: '/booking', bookingState: state }} replace />;

  const { doctor, date, time, type } = state;

  // ستايل موحد للحقول
  const fieldStyle = {
    '& .MuiOutlinedInput-root': { 
      borderRadius: 3,
      '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
      '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
    },
    '& .MuiInputLabel-root.Mui-focused': { color: '#0d9488' }
  };

  const handlePay = async () => {
    if (!card.name || !card.number || !card.expiry || !card.cvv) return;
    
    setLoading(true);
    try {
      // محاكاة عملية الدفع
      await new Promise((resolve, reject) => {
        setTimeout(() => {
          // هنا يمكنك وضع شرط للفشل، مثلاً لو رقم الكرت "0000" يفشل
          if (card.number === '0000') reject(); 
          else resolve();
        }, 2000);
      });

      dispatch(addAppointment({
        doctorId: doctor.id, doctor: doctor.name, doctorAr: doctor.nameAr,
        specialty: doctor.specialty, specialtyAr: doctor.specialtyAr,
        date, time, type, status: 'confirmed', image: doctor.image,
      }));
      
      setStatus('success');
    } catch (err) {
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  // واجهة النجاح أو الفشل
  if (status === 'success' || status === 'error') {
    const isSuccess = status === 'success';
    return (
      <Layout>
        <Container maxWidth="sm" sx={{ py: 10, textAlign: 'center' }}>
          <Box sx={{ 
            width: 80, height: 80, borderRadius: '50%', 
            background: isSuccess 
              ? 'linear-gradient(135deg, #14B8A6, #0D9488)' 
              : 'linear-gradient(135deg, #EF4444, #B91C1C)', 
            display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 3 
          }}>
            {isSuccess ? <CheckCircleIcon sx={{ color: 'white', fontSize: 40 }} /> : <ErrorOutlineIcon sx={{ color: 'white', fontSize: 40,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', }} />}
          </Box>
          
          <Typography variant="h4" sx={{ fontWeight: 800, mb: 1 ,}}>
            {isSuccess ? 'Booking Confirmed!' : 'Payment Failed'}
          </Typography>
          
          <Typography sx={{  mb: 4,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', }}>
            {isSuccess 
              ? `Your appointment with ${doctor.name} is successfully scheduled.` 
              : 'Something went wrong with your transaction. Please try again.'}
          </Typography>

          <Stack direction="row" spacing={2} justifyContent="center">
            {isSuccess ? (
              <Button 
                variant="contained" 
                onClick={() => navigate('/appointments')} 
                sx={{ borderRadius: 3, px: 4,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',color:"white",
        '&:hover': { } }}
              >
                View My Appointments
              </Button>
            ) : (
              <Button 
                variant="outlined" 
                onClick={() => setStatus('idle')} 
                sx={{ borderRadius: 3, px: 4, color: '#0d9488', borderColor: '#0d9488' }}
              >
                Try Again
              </Button>
            )}
          </Stack>
        </Container>
      </Layout>
    );
  }

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', py: 6 }}>
        <Container maxWidth="lg">
          <Button 
            startIcon={<ArrowBackIcon />} 
            onClick={() => navigate(-1)} 
            sx={{ color: '#0d9488', mb: 3, fontWeight: 600 }}
          >
            Back
          </Button>

          <Typography variant="h4" sx={{ 
            fontWeight: 800, mb: 5, textAlign: 'center',
            background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            Complete Your Booking
          </Typography>

          <Grid container spacing={4} justifyContent="center">
            {/* نموذج الدفع */}
            <Grid item xs={12} md={7}>
              <Paper elevation={0} sx={{ p: 4, borderRadius: 6, border: '1px solid #E2E8F0', background: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <Stack spacing={3} sx={{ width: '100%', maxWidth: '500px' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, justifyContent: 'center', mb: 1 }}>
                    <CreditCardIcon sx={{ color: '#0D9488' }} />
                    <Typography sx={{ fontWeight: 700, fontSize: 18 }}>Payment Details</Typography>
                  </Box>

                  <TextField fullWidth label="Cardholder Name" value={card.name} onChange={e => setCard({ ...card, name: e.target.value })} sx={fieldStyle} />
                  <TextField fullWidth label="Card Number" value={card.number} onChange={e => setCard({ ...card, number: e.target.value })} sx={fieldStyle} />
                  
                  <Box sx={{ display: 'flex', gap: 2 }}>
                    <TextField fullWidth label="Expiry" placeholder="MM/YY" value={card.expiry} onChange={e => setCard({ ...card, expiry: e.target.value })} sx={fieldStyle} />
                    <TextField fullWidth label="CVV" placeholder="123" value={card.cvv} onChange={e => setCard({ ...card, cvv: e.target.value })} sx={fieldStyle} />
                  </Box>

                  <Button 
                    fullWidth variant="contained" size="large"
                    onClick={handlePay}
                    disabled={loading}
                    sx={{ 
                      borderRadius: 3, py: 2, fontWeight: 800,
                      background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                      color: "white !important", mt: 2
                    }}
                  >
                    {loading ? <CircularProgress size={24} color="inherit" /> : `Pay $${doctor.fee}.00 Now`}
                  </Button>
                </Stack>
              </Paper>
            </Grid>

            {/* ملخص الحجز */}
            <Grid item xs={12} md={5}>
              <Paper elevation={0} sx={{ p: 4, borderRadius: 6, border: '1px solid #E2E8F0', background: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
                <Typography sx={{ 
                  fontWeight: 800, mb: 3, fontSize: 18, 
                  background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                }}>
                  Booking Summary
                </Typography>
                
                <Avatar src={doctor.image} sx={{ width: 80, height: 80, borderRadius: 3, mb: 2, boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Typography sx={{ fontWeight: 700, fontSize: 18 }}>{doctor.name}</Typography>
                <Typography sx={{ 
                  background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                  fontWeight: 600, mb: 3 
                }}>
                  {doctor.specialty}
                </Typography>

                <Divider sx={{ width: '100%', mb: 3 }} />

                <Stack spacing={2} sx={{ width: '100%', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <CalendarMonthIcon sx={{ color: '#64748B', fontSize: 20 }} />
                    <Typography sx={{ fontWeight: 500 }}>{date}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <AccessTimeIcon sx={{ color: '#64748B', fontSize: 20 }} />
                    <Typography sx={{ fontWeight: 500 }}>{time}</Typography>
                  </Box>
                </Stack>

                <Box sx={{ mt: 4, p: 2, bgcolor: '#F8FAFC', borderRadius: 4, width: '100%' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography color="textSecondary">Total Amount</Typography>
                    <Typography sx={{ fontWeight: 800, color: '#0D9488' }}>${doctor.fee}.00</Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Layout>
  );
}