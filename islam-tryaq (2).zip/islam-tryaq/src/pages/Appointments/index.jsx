import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, Button, Container, Chip, Avatar, IconButton, Menu, MenuItem, Tabs, Tab, Divider } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import ChatIcon from '@mui/icons-material/Chat';
import AddIcon from '@mui/icons-material/Add';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import Layout from '../../components/layout/Layout';
import { cancelAppointment } from '../../store/slices/appointmentsSlice';

import CalendarTodayIcon from '@mui/icons-material/CalendarToday';

import CloseIcon from '@mui/icons-material/Close';

const statusColors = {
  confirmed: { bg: '#F0FDF4', color: '#15803D', label: 'Confirmed' },
  pending: { bg: '#FFFBEB', color: '#D97706', label: 'Pending' },
  completed: { bg: '#F8FAFC', color: '#64748B', label: 'Completed' },
  cancelled: { bg: '#FEF2F2', color: '#DC2626', label: 'Cancelled' },
};

function AppointmentCard({ appt, onCancel }) {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [anchorEl, setAnchorEl] = useState(null);
  const st = statusColors[appt.status];
  const isUpcoming = appt.status === 'confirmed' || appt.status === 'pending';

  return (
    <Box sx={{
      p: { xs: 2.5, md: 3 }, borderRadius: 3, background: 'white',
      border: '1px solid ##D1FAE5', mb: 2,
      transition: 'all 0.2s', '&:hover': { boxShadow: '0 4px 15px #D1FAE5', borderColor: '#BAE6FD' },
    }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2.5, flexWrap: 'wrap' }}>
        <Avatar src={appt.image} sx={{ width: 56, height: 56, borderRadius: 3 }} />

        <Box sx={{ flex: 1, minWidth: 160 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5, flexWrap: 'wrap' }}>

            <Typography sx={{ fontWeight: 700, fontSize: 15, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', }}>{appt.doctor}</Typography>

            <Chip label={st.label} size="small"
              sx={{ background: st.bg, color: st.color, fontWeight: 600, fontSize: 11, height: 22, borderRadius: 1 }} />
          </Box>
          <Typography sx={{ color: '#188', fontSize: 13, fontWeight: 600, mb: 1 }}>{appt.specialty}</Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: '#64748B', fontSize: 13 }}>
              <CalendarMonthIcon sx={{ fontSize: 14 }} />{appt.date}
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: '#64748B', fontSize: 13 }}>
              <AccessTimeIcon sx={{ fontSize: 14 }} />{appt.time}
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: '#64748B', fontSize: 13 }}>
              {appt.type === 'video' ? <VideoCallIcon sx={{ fontSize: 14 }} /> : <ChatIcon sx={{ fontSize: 14 }} />}
              {appt.type === 'video' ? t('appointments.videoCall') : t('appointments.textChat')}
            </Box>
          </Box>
        </Box>
        {isUpcoming && (
          <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
            <Button variant="contained" size="small"
              onClick={() => navigate(appt.type === 'video' ? `/video/${appt.id}` : `/chat/${appt.id}`)}
              sx={{ borderRadius: 2.5, fontWeight: 700, fontSize: 13, px: 2.5, py: 1 ,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',color:"white",
        }}>
              {appt.type === 'video' ? t('appointments.joinCall') : t('appointments.joinChat')}
            </Button>
            <IconButton size="small" onClick={e => setAnchorEl(e.currentTarget)} sx={{ color: '#94A3B8' }}>
              <MoreVertIcon />
            </IconButton>
            <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}
              PaperProps={{ sx: { borderRadius: 2.5, boxShadow: '0 8px 30px rgba(0,0,0,0.12)', minWidth: 160 } }}>
              <MenuItem onClick={() => { setAnchorEl(null); }} sx={{ gap: 1.5, fontSize: 14 }}>
              <CalendarTodayIcon sx={{color:"#188"}}/> Reschedule</MenuItem>

              <Divider />

              <MenuItem onClick={() => { onCancel(appt.id); setAnchorEl(null); }} sx={{ gap: 1.5, fontSize: 14, color: '#EF4444' }}>

                <CloseIcon/> {t('appointments.cancel')}
              </MenuItem>
            </Menu>
          </Box>
        )}
      </Box>
    </Box>
  );
}

export default function MyAppointments() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { list } = useSelector(s => s.appointments);
  const [tab, setTab] = useState(0);

  const upcoming = list.filter(a => a.status === 'confirmed' || a.status === 'pending');
  const completed = list.filter(a => a.status === 'completed');
  const cancelled = list.filter(a => a.status === 'cancelled');

  const tabs = [
    { label: t('appointments.upcoming'), count: upcoming.length, items: upcoming },
    { label: t('appointments.completed'), count: completed.length, items: completed },
    { label: t('appointments.cancelled'), count: cancelled.length, items: cancelled },
  ];

  return (
    <Layout>

      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', py: { xs: 4, md: 5 } }}>
        <Container maxWidth="md">
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4, flexWrap: 'wrap', gap: 2 }}>
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block', mb: 0.5 }}>
                {t('appointments.title')}
              </Typography>

              <Typography sx={{ color: '#64748B', fontSize: 15 }}>{t('appointments.subtitle')}</Typography>
            </Box>

            <Button variant="contained" endIcon={<AddIcon />} onClick={() => navigate('/doctors')}
              sx={{ borderRadius: 3, fontWeight: 700, px: 2.5 ,background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',color:"white"}}>
              {t('appointments.bookNew')}
            </Button>
            
          </Box>



          <Box sx={{ background: 'white', borderRadius: 4, border: '1px solid #F1F5F9', overflow: 'hidden', mb: 3 }}>
  <Tabs 
    value={tab} 
    onChange={(_, v) => setTab(v)}
    // 1. تغيير لون الخط السفلي (الذي يتحرك تحت التبويبات)
    TabIndicatorProps={{
      style: { background: '#0d9488' }
    }}
    sx={{ 
      px: 2, 
      borderBottom: '1px solid #F1F5F9', 
      '& .MuiTab-root': { 
        fontWeight: 600, 
        textTransform: 'none', 
        fontSize: 14,
        color: '#64748B', // اللون الافتراضي للنص قبل الضغط
        transition: 'color 0.3s',
        // 2. تغيير لون النص عند التحديد (Selected)
        '&.Mui-selected': {
          color: '#0d9488',
        }
      } 
    }}
  >
    {tabs.map((t, i) => (
      <Tab 
        key={i} 
        label={
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {t.label}
            <Chip 
              label={t.count} 
              size="small"
              sx={{ 
                height: 20, 
                fontSize: 11, 
                fontWeight: 700, 
                // تغيير لون الـ Chip الصغير عند اختيار التبويب ليتناسق
                background: tab === i ? '#0d948820' : '#F1F5F9', 
                color: tab === i ? '#0d9488' : '#64748B' 
              }} 
            />
          </Box>
        } 
      />
    ))}
  </Tabs>
</Box>

          <Box>
            {tabs[tab].items.length === 0 ? (
              <Box sx={{ textAlign: 'center', py: 8, background: 'white', borderRadius: 4, border: '1px solid #F1F5F9' }}>
                <Typography sx={{ fontSize: 48, mb: 2 }}>📅</Typography>
                <Typography variant="h6" sx={{ color: '#0F172A', mb: 1 }}>{t('appointments.noAppointments')}</Typography>
                <Button variant="contained" onClick={() => navigate('/doctors')} sx={{ borderRadius: 3, mt: 1 }}>
                  {t('appointments.bookNew')}
                </Button>
              </Box>
            ) : (
              tabs[tab].items.map(appt => (
                <AppointmentCard key={appt.id} appt={appt}
                  onCancel={id => dispatch(cancelAppointment(id))} />
              ))
            )}
          </Box>
        </Container>
      </Box>
    </Layout>
  );
}
