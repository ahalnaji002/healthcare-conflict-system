import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Box, Typography, TextField, Button, Checkbox, FormControlLabel, Divider, CircularProgress, Alert, IconButton, InputAdornment } from '@mui/material';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { login } from '../../store/slices/authSlice';

// Icons
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import GoogleIcon from '@mui/icons-material/Google';
import AppleIcon from '@mui/icons-material/Apple';

const TeryaqLogo = () => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 4 }} component={Link} to="/" style={{ textDecoration: 'none' }}>
    <span style={{ 
      fontFamily: "'Sora',sans-serif", fontWeight: 700, fontSize: 20, 
      background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
      display: 'inline-block', 
    }}>Teryaq</span>
  </Box>
);

export default function Login() {
  const location = useLocation();
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [form, setForm] = useState({ email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (!form.email || !form.password) { setError('Please fill in all fields.'); return; }
    
    setLoading(true);
    setError('');
    
    // محاكاة لعملية تسجيل الدخول
    await new Promise(r => setTimeout(r, 1200));

    // تحديد الدور بناءً على الإيميل (للتجربة)
    let detectedRole = 'patient';
    if (form.email.includes('doctor') || form.email.includes('dr')) detectedRole = 'doctor';
    else if (form.email.includes('ngo') || form.email.includes('org')) detectedRole = 'ngo';
    else if (form.email.includes('admin')) detectedRole = 'admin';
    
    dispatch(login({ 
      firstName: 'John', 
      lastName: 'Doe', 
      email: form.email, 
      role: detectedRole, 
      id: 'TRQ-2024-0847' 
    }));

    // تحديد الوجهة حسب الدور
    const from = location.state?.from;
    const bookingState = location.state?.bookingState;
    if (from && from !== '/') {
      navigate(from, { state: bookingState });
    } else {
      const redirectMap = { patient: '/patient', doctor: '/doctor', ngo: '/ngo', admin: '/admin' };
      navigate(redirectMap[detectedRole] || '/');
    }
  };

  // تنسيق موحد للحقول (نفس ستايل الـ Register)
  const commonTextFieldSx = {
    '& .MuiOutlinedInput-root': {
      borderRadius: 3,
      '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
      '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
    },
    '& .MuiInputLabel-root.Mui-focused': { color: '#0d9488' },
    '& .Mui-focused .MuiInputAdornment-root .MuiSvgIcon-root': { color: '#0d9488' }
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex' }}>
      {/* القسم الأيسر: النموذج */}
      <Box sx={{
        width: { xs: '100%', md: '45%' },
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        px: { xs: 3, md: 6 }, py: 6, background: 'white',
      }}>
        <Box sx={{ maxWidth: 400, mx: 'auto', width: '100%' }}>
          <TeryaqLogo />
          
          <Typography variant="h4" sx={{ 
            fontWeight: 800, mb: 0.5,
            background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'inline-block' 
          }}>
            {t('auth.login.title')}
          </Typography>
          <Typography sx={{ color: '#64748B', fontSize: 15, mb: 4 }}>{t('auth.login.subtitle')}</Typography>

          {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{error}</Alert>}

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <TextField
              fullWidth label={t('auth.login.email')} type="email"
              value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
              placeholder="you@example.com"
              InputProps={{ 
                startAdornment: <InputAdornment position="start"><EmailIcon sx={{ fontSize: 18, color: '#94A3B8' }} /></InputAdornment> 
              }}
              sx={commonTextFieldSx}
            />
            
            <TextField
              fullWidth label={t('auth.login.password')}
              type={showPass ? 'text' : 'password'}
              value={form.password} onChange={e => setForm({ ...form, password: e.target.value })}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              placeholder="Enter your password"
              InputProps={{
                startAdornment: <InputAdornment position="start"><LockIcon sx={{ fontSize: 18, color: '#94A3B8' }} /></InputAdornment>,
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setShowPass(!showPass)}>
                      {showPass ? <VisibilityOffIcon sx={{ fontSize: 18 }} /> : <VisibilityIcon sx={{ fontSize: 18 }} />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              sx={commonTextFieldSx}
            />
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1.5, mb: 3 }}>
            <FormControlLabel
              control={<Checkbox size="small" sx={{ color: '#0d9488', '&.Mui-checked': { color: '#0d9488' } }} />}
              label={<Typography sx={{ fontSize: 13, color: '#64748B' }}>{t('auth.login.remember')}</Typography>}
            />
            <Link to="#" style={{ fontSize: 13, color: '#0d9488', fontWeight: 600, textDecoration: 'none' }}>
              {t('auth.login.forgotPassword')}
            </Link>
          </Box>

          <Button fullWidth variant="contained" size="large" onClick={handleSubmit} disabled={loading}
            sx={{ 
              borderRadius: 3, py: 1.5, fontSize: 15, fontWeight: 700, mb: 3,
              background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
              color: 'white',
              '&:hover': { opacity: 0.9 }
            }}>
            {loading ? <CircularProgress size={22} color="inherit" /> : t('auth.login.signIn')}
          </Button>

          <Divider sx={{ mb: 3 }}>
            <Typography sx={{ fontSize: 13, color: '#94A3B8', px: 1 }}>{t('auth.login.orContinueWith')}</Typography>
          </Divider>

          <Box sx={{ display: 'flex', gap: 2, mb: 4 }}>
            <Button fullWidth variant="outlined" startIcon={<GoogleIcon sx={{ color: '#EA4335' }} />}
              sx={{ borderRadius: 2.5, py: 1.2, borderColor: '#E2E8F0', color: '#0F172A', fontWeight: 600, textTransform: 'none', '&:hover': { borderColor: '#0d9488', color: '#0d9488' } }}>
              Google
            </Button>
            <Button fullWidth variant="outlined" startIcon={<AppleIcon sx={{ color: '#000' }} />}
              sx={{ borderRadius: 2.5, py: 1.2, borderColor: '#E2E8F0', color: '#0F172A', fontWeight: 600, textTransform: 'none', '&:hover': { borderColor: '#0d9488', color: '#0d9488' } }}>
              Apple
            </Button>
          </Box>

          <Typography sx={{ textAlign: 'center', fontSize: 14, color: '#64748B' }}>
            {t('auth.login.noAccount')}{' '}
            <Link to="/register" style={{ color: '#0d9488', fontWeight: 600, textDecoration: 'none' }}>
              {t('auth.login.createOne')}
            </Link>
          </Typography>
        </Box>
      </Box>

      {/* القسم الأيمن: شريط جانبي مع صورة */}
      <Box sx={{
        display: { xs: 'none', md: 'flex' }, flex: 1, position: 'relative', overflow: 'hidden',
        flexDirection: 'column', justifyContent: 'center', px: 6,
      }}>
        <img
          src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=900&h=900&fit=crop"
          alt="Healthcare"
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
        />
        <Box sx={{ position: 'absolute', inset: 0, background: 'linear-gradient(135deg, rgba(15,23,42,0.8) 0%, rgba(13,148,136,0.7) 100%)' }} />
        
<Box sx={{ position: 'relative', color: 'white', maxWidth: 440 }}>
  {/* تغليف حاوية الصورة بالرابط */}
  <Box 
    component={Link} 
    to="/" 
    sx={{ 
      width: 64, // كبرت الحجم قليلاً بناءً على طلبك السابق لتكبير اللوجو
      height: 64, 
      borderRadius: '16px', 
      background: 'rgba(255,255,255,0.2)', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center', 
      mb: 3, 
      backdropFilter: 'blur(8px)',
      cursor: "pointer",
      transition: 'all 0.3s ease',
      textDecoration: 'none', // لضمان عدم وجود خطوط الرابط
      '&:hover': {
        background: 'rgba(255,255,255,0.3)',
        transform: 'scale(1.05)'
      }
    }}
  >
    <img src='/logo.png' style={{ width: '100px', height: 'auto' }} alt="Logo"/>
  </Box>

          
          <Typography variant="h3" sx={{ fontWeight: 800, mb: 2, fontSize: { md: 32, lg: 38 } }}>
            {t('auth.sidebar.loginTitle')}
          </Typography>
          <Typography sx={{ color: 'rgba(255,255,255,0.8)', fontSize: 15, mb: 4 }}>
            {t('auth.sidebar.loginSubtitle')}
          </Typography>
          
          <Box sx={{ display: 'flex', gap: 3 }}>
            {[{ v: '500+', l: 'Doctors' }, { v: '50K+', l: 'Patients' }, { v: '4.9★', l: 'Rating' }].map(s => (
              <Box key={s.l}>
                <Typography sx={{ fontSize: 26, fontWeight: 800 }}>{s.v}</Typography>
                <Typography sx={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{s.l}</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}