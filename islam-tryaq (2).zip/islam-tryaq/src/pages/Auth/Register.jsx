import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Box, Typography, TextField, Button, Checkbox, FormControlLabel, Divider, CircularProgress, Alert, ToggleButton, ToggleButtonGroup, InputAdornment, IconButton } from '@mui/material';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { login } from '../../store/slices/authSlice';

// Icons
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import PhoneIcon from '@mui/icons-material/Phone';
import PersonIcon from '@mui/icons-material/Person';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import CheckIcon from '@mui/icons-material/Check';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import GoogleIcon from '@mui/icons-material/Google';
import AppleIcon from '@mui/icons-material/Apple';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import BusinessIcon from '@mui/icons-material/Business';


const TeryaqLogo = () => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }} component={Link} to="/" style={{ textDecoration: 'none' }}>
    <span style={{ 
      fontFamily: "'Sora',sans-serif", fontWeight: 700, fontSize: 20, 
      background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
      display: 'inline-block', 
    }}>Teryaq</span>
  </Box>
);

export default function Register() {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const [role, setRole] = useState('patient');
  const [form, setForm] = useState({ 
    firstName: '', lastName: '', email: '', phone: '', password: '',
    experience: '', certificates: null 
  });
  
  const [showPass, setShowPass] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleFileChange = (e) => {
    setForm({ ...form, certificates: e.target.files });
  };

  const handleSubmit = async () => {
    if (!form.firstName || !form.lastName || !form.email || !form.password) { 
        setError('Please fill in all required fields.'); return; 
    }
    if (!agreed) { setError('Please agree to Terms of Service.'); return; }
    if (form.password.length < 8) { setError('Password must be at least 8 characters.'); return; }
    
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 1200));
    dispatch(login({ 
        firstName: form.firstName, 
        lastName: form.lastName, 
        email: form.email, 
        role, 
        id: `TRQ-${Date.now()}` 
    }));
    const redirectMap = { patient: '/patient', doctor: '/doctor', ngo: '/ngo', admin: '/admin' };
    navigate(redirectMap[role] || '/');
  };

  // الدالة الموحدة لتنسيق الحقول مع الألوان الجديدة
  const inputField = (key, label, type = 'text', icon, placeholder) => (
    <TextField
      key={key}
      fullWidth 
      label={label} 
      type={key === 'password' && !showPass ? 'password' : type}
      value={form[key]} 
      onChange={e => setForm({ ...form, [key]: e.target.value })}
      placeholder={placeholder}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            {React.cloneElement(icon, { sx: { fontSize: 18, color: '#94A3B8', transition: 'color 0.3s' } })}
          </InputAdornment>
        ),
        ...(key === 'password' ? {
          endAdornment: (
            <InputAdornment position="end">
              <IconButton size="small" onClick={() => setShowPass(!showPass)}>
                {showPass ? <VisibilityOffIcon sx={{ fontSize: 18 }} /> : <VisibilityIcon sx={{ fontSize: 18 }} />}
              </IconButton>
            </InputAdornment>
          )
        } : {}),
      }}
      sx={{
        '& .MuiOutlinedInput-root': {
          borderRadius: 3,
          '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
        },
        '& .MuiInputLabel-root.Mui-focused': { color: '#0d9488' },
        '& .Mui-focused .MuiInputAdornment-root .MuiSvgIcon-root': { color: '#0d9488' }
      }}
    />
  );

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex' }}>
      {/* Sidebar الأيسر */}
      <Box sx={{
        display: { xs: 'none', md: 'flex' }, width: '42%', position: 'relative', overflow: 'hidden',
        flexDirection: 'column', justifyContent: 'center', px: 6,
      }}>
        <img
          src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=900&h=900&fit=crop"
          alt="Healthcare"
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
        />
        <Box sx={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(15,23,42,0.8) 0%, rgba(13,148,136,0.8) 100%)' }} />
        <Box sx={{ position: 'relative', color: 'white', maxWidth: 360 }}>
         <Box 
  component={Link} 
  to="/" 
  sx={{ 
    width: 64, // زيادة الحجم قليلاً ليكون أوضح
    height: 64, 
    borderRadius: '16px', 
    background: 'rgba(255,255,255,0.2)', 
    display: 'flex', 
    alignItems: 'center', 
    justifyContent: 'center', 
    mb: 3,
    cursor: 'pointer',
    textDecoration: 'none',
    transition: 'all 0.3s ease',
    '&:hover': {
      background: 'rgba(255,255,255,0.3)', // تفتيح الخلفية عند تمرير الماوس
      transform: 'scale(1.05)' // تكبير طفيف للتفاعل
    }
  }}
>
  <img 
    src='/logo.png' 
    style={{ width: '100px', height: 'auto' }} // حجم الصورة داخل المربع
    alt="Logo"
  />
</Box>
          <Typography variant="h3" sx={{ fontWeight: 800, mb: 2, fontSize: 32 }}>{t('auth.sidebar.registerTitle')}</Typography>
          <Typography sx={{ color: 'rgba(255,255,255,0.85)', mb: 4 }}>{t('auth.sidebar.registerSubtitle')}</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {t('auth.sidebar.features', { returnObjects: true }).map((f, i) => (
              <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Box sx={{ width: 22, height: 22, borderRadius: '50%', background: 'rgba(255,255,255,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <CheckIcon sx={{ fontSize: 13, color: 'white' }} />
                </Box>
                <Typography sx={{ fontSize: 14 }}>{f}</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>

      {/* Form الأيمن */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', px: { xs: 3, md: 6 }, py: 5, background: 'white', overflowY: 'auto' }}>
        <Box sx={{ maxWidth: 440, mx: 'auto', width: '100%' }}>
          <TeryaqLogo />
          
          <Typography variant="h4" sx={{ 
            fontWeight: 800, mb: 0.5,
            background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'inline-block' 
          }}>
            {t('auth.register.title')}
          </Typography>
          <Typography sx={{ color: '#64748B', mb: 3 }}>{t('auth.register.subtitle')}</Typography>

          {/* Role Selection */}
          <ToggleButtonGroup value={role} exclusive onChange={(_, v) => v && setRole(v)}
            sx={{ mb: 3, width: '100%', '& .MuiToggleButton-root': { flex: 1, borderRadius: '10px !important', fontWeight: 600 } }}>
            <ToggleButton value="patient" sx={{ '&.Mui-selected': { background: '#F0FDF4', color: '#0d9488', borderColor: '#0d9488' } }}>
              <PersonIcon sx={{ mr: 1 }}/> {t('auth.register.asPatient')}
            </ToggleButton>
            <ToggleButton value="doctor" sx={{ ml: '8px !important', '&.Mui-selected': { background: '#F0FDF4', color: '#0d9488', borderColor: '#0d9488' } }}>
              <MedicalServicesIcon sx={{ mr: 1 }}/> {t('auth.register.asDoctor')}
            </ToggleButton>
            <ToggleButton value="ngo" sx={{ ml: '8px !important', '&.Mui-selected': { background: '#F0FDF4', color: '#0d9488', borderColor: '#0d9488' } }}>
              <span style={{ marginRight: 6, fontSize: 16 }}><BusinessIcon sx={{color:"#188"}}/></span> NGO
            </ToggleButton>
          </ToggleButtonGroup>

          {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{error}</Alert>}

          <Box sx={{ display: 'flex', gap: 2, mb: 2.5 }}>
            {inputField('firstName', t('auth.register.firstName'), 'text', <PersonIcon />, 'John')}
            {inputField('lastName', t('auth.register.lastName'), 'text', <PersonIcon />, 'Doe')}
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mb: 2.5 }}>
            {inputField('email', t('auth.register.email'), 'email', <EmailIcon />, 'you@example.com')}
            {inputField('phone', t('auth.register.phone'), 'tel', <PhoneIcon />, '+1 (555) 000-0000')}
            {inputField('password', t('auth.register.password'), 'password', <LockIcon />, t('auth.register.passwordHint'))}
            
            {/* قسم بيانات الطبيب الإضافية */}
            {role === 'doctor' && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mt: 1 }}>
                <Divider><Typography sx={{ fontSize: 12, color: '#94A3B8', fontWeight: 600 }}>Professional Verification</Typography></Divider>
                
                <TextField
                  fullWidth multiline rows={3} label="Experience Summary"
                  placeholder="Describe your medical expertise..."
                  value={form.experience}
                  onChange={e => setForm({ ...form, experience: e.target.value })}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                      '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#0d9488' },
                    },
                    '& .MuiInputLabel-root.Mui-focused': { color: '#0d9488' }
                  }}
                />

                <Button
                  component="label" variant="outlined" startIcon={<CloudUploadIcon />}
                  sx={{
                    borderRadius: 3, py: 1.5, borderStyle: 'dashed', borderColor: '#E2E8F0', color: '#64748B',
                    '&:hover': { borderColor: '#0d9488', color: '#0d9488', background: '#F0FDF4' }
                  }}
                >
                  Upload Certificates / CV
                  <input type="file" hidden multiple onChange={handleFileChange} />
                </Button>

                {form.certificates && (
                  <Typography sx={{ fontSize: 12, color: '#0d9488', fontWeight: 600, mt: -1, px: 1 }}>
                    ✅ {form.certificates.length} file(s) ready for upload
                  </Typography>
                )}
              </Box>
            )}
          </Box>

          <FormControlLabel
            sx={{ mb: 3 }}
            control={<Checkbox size="small" checked={agreed} onChange={e => setAgreed(e.target.checked)} sx={{ color: '#0d9488', '&.Mui-checked': { color: '#0d9488' } }} />}
            label={
              <Typography sx={{ fontSize: 13, color: '#64748B' }}>
                {t('auth.register.agreeTerms')}{' '}
                <Link to="#" style={{ color: '#0d9488', fontWeight: 600, textDecoration: 'none' }}>{t('auth.register.termsOfService')}</Link>
              </Typography>
            }
          />

          <Button startIcon={<PersonAddAlt1Icon />} fullWidth variant="contained" size="large" onClick={handleSubmit} disabled={loading}
            sx={{ 
              borderRadius: 3, py: 1.5, fontWeight: 700, mb: 3,
              background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
              color:"white",
              '&:hover': { opacity: 0.9 }
            }}>
            {loading ? <CircularProgress size={22} color="inherit" /> : t('auth.register.createAccount')} 
          </Button>

          <Divider sx={{ mb: 3 }}>
            <Typography sx={{ fontSize: 13, color: '#94A3B8' }}>{t('auth.register.orSignUpWith')}</Typography>
          </Divider>

          <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
            <Button fullWidth variant="outlined" startIcon={<GoogleIcon sx={{ color: '#EA4335' }} />}
              sx={{ borderRadius: 2.5, py: 1.2, borderColor: '#E2E8F0', color: '#0F172A', fontWeight: 600, textTransform: 'none', '&:hover': { borderColor: '#0d9488', color: '#0d9488' } }}>
              Google
            </Button>
            <Button fullWidth variant="outlined" startIcon={<AppleIcon sx={{ color: '#000' }} />}
              sx={{ borderRadius: 2.5, py: 1.2, borderColor: '#E2E8F0', color: '#0F172A', fontWeight: 600, textTransform: 'none', '&:hover': { borderColor: '#0d9488', color: '#0d9488' } }}>
              Apple
            </Button>
          </Box>

          <Typography sx={{ textAlign: 'center', fontSize: 14, color: '#64748B' }}>
            {t('auth.register.alreadyHaveAccount')}{' '}
            <Link to="/login" style={{ color: '#0d9488', fontWeight: 600, textDecoration: 'none' }}>
              {t('auth.register.signIn')}
            </Link>
          </Typography>
        </Box>
      </Box>
    </Box>
  );
}