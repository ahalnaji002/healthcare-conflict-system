import React, { useState } from 'react';
import {
  Box, Typography, Grid, Card, CardContent, Avatar, Chip, Button,
  TextField, Divider, LinearProgress, Dialog, DialogTitle,
  DialogContent, DialogActions, Tabs, Tab, Badge, Select,
  MenuItem, FormControl, InputLabel, CircularProgress
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Layout from '../../components/layout/Layout';

// Icons
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import SosIcon from '@mui/icons-material/Sos';
import FoodBankIcon from '@mui/icons-material/FoodBank';
import VolunteerActivismIcon from '@mui/icons-material/VolunteerActivism';
import MedicationIcon from '@mui/icons-material/Medication';
import PeopleIcon from '@mui/icons-material/People';
import AssignmentIcon from '@mui/icons-material/Assignment';
import BarChartIcon from '@mui/icons-material/BarChart';
import ReplyIcon from '@mui/icons-material/Reply';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import WarningIcon from '@mui/icons-material/Warning';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import LocationOnIcon from '@mui/icons-material/LocationOn';


import InboxIcon from '@mui/icons-material/Inbox';


const mockRequests = [
  { id: 1, patient: 'Ahmed Al-Hassan', patientAr: 'أحمد الحسن', type: 'medical', typeAr: 'طلب طبي', desc: 'Need urgent insulin supply, running out within 2 days', descAr: 'نقص في الأنسولين، سينتهي خلال يومين', status: 'pending', priority: 'critical', time: '30 min ago', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face', location: 'North Gaza' },
  { id: 2, patient: 'Fatima Nour', patientAr: 'فاطمة نور', type: 'food', typeAr: 'غذاء', desc: 'Family of 5, no food for 3 days, children need nutrition', descAr: 'عائلة من 5 أفراد بلا طعام منذ 3 أيام', status: 'pending', priority: 'critical', time: '1 hour ago', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop&crop=face', location: 'Rafah' },
  { id: 3, patient: 'Omar Khalil', patientAr: 'عمر خليل', type: 'support', typeAr: 'دعم نفسي', desc: 'Lost family members, experiencing severe trauma and grief', descAr: 'فقد أفراداً من عائلته، يعاني من صدمة نفسية شديدة', status: 'in-progress', priority: 'high', time: '3 hours ago', image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop&crop=face', location: 'Khan Younis' },
  { id: 4, patient: 'Layla Mansour', patientAr: 'ليلى منصور', type: 'medical', typeAr: 'طلب طبي', desc: 'Need wound dressings and antiseptics for post-surgery care', descAr: 'تحتاج ضمادات ومعقمات للعناية بما بعد العملية', status: 'pending', priority: 'high', time: '5 hours ago', image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face', location: 'Gaza City' },
  { id: 5, patient: 'Youssef Ibrahim', patientAr: 'يوسف إبراهيم', type: 'food', typeAr: 'غذاء', desc: 'Diabetic patient needs special diet foods and supplements', descAr: 'مريض سكري يحتاج أغذية خاصة ومكملات', status: 'resolved', priority: 'medium', time: '1 day ago', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face', location: 'Deir al-Balah' },
];

const typeConfig = { medical: { icon: <MedicationIcon />, color: '#EF4444', bg: '#FEF2F2', label: 'Medical', labelAr: 'طبي' }, food: { icon: <FoodBankIcon />, color: '#F59E0B', bg: '#FFFBEB', label: 'Food', labelAr: 'غذاء' }, support: { icon: <VolunteerActivismIcon />, color: '#8B5CF6', bg: '#F5F3FF', label: 'Support', labelAr: 'دعم' } };
const priorityConfig = { critical: { color: '#DC2626', bg: '#FEF2F2', label: 'Critical', labelAr: 'حرج' }, high: { color: '#D97706', bg: '#FFFBEB', label: 'High', labelAr: 'عالي' }, medium: { color: '#0EA5E9', bg: '#F0F9FF', label: 'Medium', labelAr: 'متوسط' } };
const statusConfig = { pending: { color: '#D97706', bg: '#FFFBEB', label: 'Pending', labelAr: 'معلق' }, 'in-progress': { color: '#0EA5E9', bg: '#F0F9FF', label: 'In Progress', labelAr: 'جارٍ' }, resolved: { color: '#15803D', bg: '#F0FDF4', label: 'Resolved', labelAr: 'تم' } };

// التنسيق المشترك للـ Input و الـ Select
const inputStyles = {
  '& .MuiOutlinedInput-root': {
    borderRadius: 2.5,
    '& fieldset': { borderColor: '#E2E8F0' },
    '&:hover fieldset': { borderColor: '#188' },
    '&.Mui-focused fieldset': { borderColor: '#188' },
  },
  '& .MuiInputLabel-root.Mui-focused': { color: '#188' }
};

function RespondDialog({ open, onClose, request, lang }) {
  const [response, setResponse] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  if (!request) return null;
  const type = typeConfig[request.type];
  const handleSend = () => {
    setSending(true);
    setTimeout(() => { setSending(false); setDone(true); setTimeout(() => { setDone(false); setResponse(''); onClose(); }, 1500); }, 1200);
  };

  return (
    <Dialog open={open} onClose={onClose} PaperProps={{ sx: { borderRadius: 3.5, minWidth: { xs: '90vw', sm: 480 } } }}>
      <DialogTitle sx={{ fontWeight: 800, fontSize: 18 }}>{lang === 'ar' ? 'الرد على الطلب' : 'Respond to Request'}</DialogTitle>
      <DialogContent>
        {done ? (
          <Box sx={{ textAlign: 'center', py: 4 }}><CheckCircleIcon sx={{ fontSize: 60, color: '#22C55E', mb: 2 }} /><Typography sx={{ fontWeight: 700, fontSize: 18 }}>{lang === 'ar' ? 'تم الرد!' : 'Response Sent!'}</Typography></Box>
        ) : (
          <>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2.5, background: type.bg, mb: 3, mt: 1 }}>
              <Avatar src={request.image} sx={{ width: 46, height: 46, borderRadius: 2 }} />
              <Box><Typography sx={{ fontWeight: 700, fontSize: 14 }}>{lang === 'ar' ? request.patientAr : request.patient}</Typography><Typography sx={{ fontSize: 12, color: '#64748B' }}>{lang === 'ar' ? request.descAr : request.desc}</Typography></Box>
            </Box>
            <TextField 
              fullWidth 
              multiline 
              rows={4} 
              label={lang === 'ar' ? 'ردك على الطلب' : 'Your response'} 
              value={response} 
              onChange={e => setResponse(e.target.value)} 
              sx={{ mb: 2, ...inputStyles }} 
            />
            <FormControl fullWidth size="small" sx={inputStyles}>
              <InputLabel>{lang === 'ar' ? 'تحديث الحالة' : 'Update Status'}</InputLabel>
              <Select label={lang === 'ar' ? 'تحديث الحالة' : 'Update Status'} defaultValue="in-progress">
                <MenuItem value="in-progress">{lang === 'ar' ? 'جارٍ المعالجة' : 'In Progress'}</MenuItem>
                <MenuItem value="resolved">{lang === 'ar' ? 'تم الحل' : 'Resolved'}</MenuItem>
              </Select>
            </FormControl>
          </>
        )}
      </DialogContent>
      {!done && (
        <DialogActions sx={{ p: 2.5 }}>
          <Button onClick={onClose} sx={{ borderRadius: 2.5, color: '#64748B', textTransform: 'none' }}>{lang === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
          <Button variant="contained" onClick={handleSend} disabled={!response || sending}
            sx={{ borderRadius: 2.5, textTransform: 'none', background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)', minWidth: 100,color:"white !important" }}>
            {sending ? <CircularProgress size={18} sx={{ color: 'white' }} /> : (lang === 'ar' ? 'إرسال' : 'Send')}
          </Button>
        </DialogActions>
      )}
    </Dialog>
  );
}

export default function NGODashboard() {
  const { language } = useSelector(s => s.ui);
  const lang = language || 'en';
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);
  const [respondTo, setRespondTo] = useState(null);
  const [filterType, setFilterType] = useState('all');

  const pending = mockRequests.filter(r => r.status === 'pending').length;
  const critical = mockRequests.filter(r => r.priority === 'critical').length;
  const inProgress = mockRequests.filter(r => r.status === 'in-progress').length;
  const resolved = mockRequests.filter(r => r.status === 'resolved').length;

  const filteredReqs = filterType === 'all' ? mockRequests : mockRequests.filter(r => r.type === filterType);

  const reportData = [
    { type: 'medical', count: mockRequests.filter(r => r.type === 'medical').length, color: '#EF4444', label: lang === 'ar' ? 'طبي' : 'Medical' },
    { type: 'food', count: mockRequests.filter(r => r.type === 'food').length, color: '#F59E0B', label: lang === 'ar' ? 'غذاء' : 'Food' },
    { type: 'support', count: mockRequests.filter(r => r.type === 'support').length, color: '#8B5CF6', label: lang === 'ar' ? 'دعم' : 'Support' },
  ];

  const mainGradient = "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)";

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', pt: { xs: 9, md: 10 }, pb: 6 ,display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'}}>
        <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, md: 4 } }}>
          {/* Header */}
          <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 2 }}>
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 800, mb: 0.5 }}>
                <Box component="span" sx={{ background: mainGradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', display: 'inline-block' }}>
                  {lang === 'ar' ? 'لوحة المنظمة' : 'NGO Dashboard'}
                </Box>
              </Typography>
              <Typography sx={{ color: '#64748B', fontSize: 15 }}>
                {lang === 'ar' ? 'إدارة الطلبات وتنظيم المساعدات' : 'Manage aid requests and prioritize assistance'}
              </Typography>
            </Box>
            <Button variant="outlined" startIcon={<BarChartIcon />} onClick={() => navigate('/ngo/reports')}
              sx={{ borderRadius: 2.5, textTransform: 'none', fontWeight: 700, borderColor: '#14B8A6', color: '#14B8A6' }}>
              {lang === 'ar' ? 'التقارير' : 'View Reports'}
            </Button>
          </Box>

          {/* Stats */}
          <Grid container spacing={2} sx={{ mb: 4 }}>
            {[
              { icon: <InboxIcon sx={{color:"#188"}}/>, label: lang === 'ar' ? 'طلبات معلقة' : 'Pending', value: pending, bg: '#FFFBEB', color: '#D97706' },
              { icon: <WarningIcon sx={{color:"#188"}}/>, label: lang === 'ar' ? 'حرجة' : 'Critical', value: critical, bg: '#FEF2F2', color: '#DC2626' },
              { icon: <AutorenewIcon sx={{color:"#188"}}/>, label: lang === 'ar' ? 'جارية' : 'In Progress', value: inProgress, bg: '#F0F9FF', color: '#0EA5E9' },
              { icon: <CheckCircleIcon sx={{color:"#188"}}/>, label: lang === 'ar' ? 'تم حلها' : 'Resolved', value: resolved, bg: '#F0FDF4', color: '#15803D' },
            ].map((s, i) => (
              <Grid item xs={6} sm={3} key={i}>
                <Card sx={{ borderRadius: 3, border: `1px solid ${s.color}25`, boxShadow: 'none', background: s.bg }}>
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography sx={{ fontSize: 22, mb: 0.5 }}>{s.icon}</Typography>
                    <Typography sx={{ fontSize: 28, fontWeight: 800, color: '#0F172A', lineHeight: 1 }}>{s.value}</Typography>
                    <Typography sx={{ fontSize: 11.5, color: '#64748B', mt: 0.5 }}>{s.label}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Tabs */}
          <Box sx={{ borderBottom: '1px solid #F1F5F9', mb: 3 }}>
            <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ 
              '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, fontSize: 14 }, 
              '& .Mui-selected': { color: '#188' }, 
              '& .MuiTabs-indicator': { background: mainGradient } 
            }}>
              <Tab label={<Badge badgeContent={pending} color="warning"><Box sx={{ pr: 1.5 , color:"#188"}}>{lang === 'ar' ? 'الطلبات' : 'Requests'}</Box></Badge>} />
              <Tab sx={{color:"#188"}} label={lang === 'ar' ? 'التقارير' : 'Reports'} />
            </Tabs>
          </Box>

          {/* Requests Tab */}
          {tab === 0 && (
            <>
              <Box sx={{ display: 'flex', gap: 1.5, mb: 3, flexWrap: 'wrap' }}>
                {['all', 'medical', 'food', 'support'].map(f => (
                  <Chip key={f} clickable onClick={() => setFilterType(f)}
                    label={f === 'all' ? (lang === 'ar' ? 'الكل' : 'All') : (lang === 'ar' ? typeConfig[f]?.labelAr : typeConfig[f]?.label)}
                    sx={{ fontWeight: 600, fontSize: 13, borderRadius: 2.5, background: filterType === f ? mainGradient : 'white', color: filterType === f ? 'white' : '#64748B', border: '1px solid #E2E8F0' }} />
                ))}
              </Box>
              <Box>
                {filteredReqs.sort((a, b) => { const order = { critical: 0, high: 1, medium: 2 }; return order[a.priority] - order[b.priority]; }).map(req => {
                  const type = typeConfig[req.type];
                  const pri = priorityConfig[req.priority];
                  const st = statusConfig[req.status];
                  return (
                    <Card key={req.id} sx={{ borderRadius: 3.5, border: `1px solid ${pri.color}25`, mb: 2, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', transition: 'all 0.2s', '&:hover': { boxShadow: '0 6px 20px rgba(0,0,0,0.08)' } }}>
                      <CardContent sx={{ p: 3 }}>
                        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2, flexWrap: 'wrap' }}>
                          <Avatar src={req.image} sx={{ width: 52, height: 52, borderRadius: 2.5, flexShrink: 0 }} />
                          <Box sx={{ flex: 1, minWidth: 200 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5, flexWrap: 'wrap' }}>
                              <Typography sx={{ fontWeight: 700, fontSize: 15 }}>{lang === 'ar' ? req.patientAr : req.patient}</Typography>
                              <Chip label={lang === 'ar' ? pri.labelAr : pri.label} size="small" sx={{ background: pri.bg, color: pri.color, fontWeight: 700, fontSize: 10, height: 20, borderRadius: 1.5 }} />
                              <Chip label={lang === 'ar' ? st.labelAr : st.label} size="small" sx={{ background: st.bg, color: st.color, fontWeight: 700, fontSize: 10, height: 20, borderRadius: 1.5 }} />
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                              <Box sx={{ color: type.color, display: 'flex', alignItems: 'center' }}>{React.cloneElement(type.icon, { sx: { fontSize: 15 } })}</Box>
                              <Typography sx={{ fontSize: 12.5, color: type.color, fontWeight: 600 }}>{lang === 'ar' ? type.labelAr : type.label}</Typography>
                              <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>· {req.location}</Typography>
                            </Box>
                            <Typography sx={{ fontSize: 13.5, color: '#0F172A', mb: 0.5 }}>{lang === 'ar' ? req.descAr : req.desc}</Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><AccessTimeIcon sx={{ fontSize: 12, color: '#94A3B8' }} /><Typography sx={{ fontSize: 11.5, color: '#94A3B8' }}>{req.time}</Typography></Box>
                          </Box>
                          {req.status !== 'resolved' && (
                            <Button variant="contained" startIcon={<ReplyIcon />} onClick={() => setRespondTo(req)}
                              sx={{ borderRadius: 2.5, textTransform: 'none', fontWeight: 700, fontSize: 13, background: mainGradient, flexShrink: 0 , color:"white" }}>
                              {lang === 'ar' ? 'رد' : 'Respond'}
                            </Button>
                          )}
                        </Box>
                      </CardContent>
                    </Card>
                  );
                })}
              </Box>
            </>
          )}

          {/* Reports Tab */}
          {tab === 1 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', p: 3, boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
                  <Typography sx={{ fontWeight: 700, fontSize: 16, mb: 3 }}>
<>
  <BarChartIcon sx={{color:"#188"}} />
  {lang === 'ar' ? ' توزيع الطلبات حسب النوع' : ' Requests by Type'}
</>                  </Typography>
                  {reportData.map(d => (
                    <Box key={d.type} sx={{ mb: 2.5 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                        <Typography sx={{ fontSize: 13.5, fontWeight: 600 }}>{d.label}</Typography>
                        <Typography sx={{ fontSize: 13.5, fontWeight: 700, color: d.color }}>{d.count} {lang === 'ar' ? 'طلب' : 'requests'}</Typography>
                      </Box>
                      <LinearProgress variant="determinate" value={(d.count / mockRequests.length) * 100}
                        sx={{ height: 8, borderRadius: 4, '& .MuiLinearProgress-bar': { background: d.color }, background: `${d.color}20` }} />
                    </Box>
                  ))}
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', p: 3, boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
                  <Typography sx={{ fontWeight: 700, fontSize: 16, mb: 3 }}>
                    <>
  <LocationOnIcon sx={{color:"#188"}} />
  {lang === 'ar' ? ' توزيع حسب المنطقة' : ' By Location'}
</>
                  </Typography>
                  {['North Gaza', 'Gaza City', 'Khan Younis', 'Rafah', 'Deir al-Balah'].map((loc, i) => {
                    const count = mockRequests.filter(r => r.location === loc).length;
                    return (
                      <Box key={loc} sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                        <Typography sx={{ fontSize: 13, color: '#64748B', minWidth: 120 }}>{loc}</Typography>
                        <LinearProgress variant="determinate" value={(count / mockRequests.length) * 100} sx={{ flex: 1, height: 6, borderRadius: 3, '& .MuiLinearProgress-bar': { background: mainGradient } }} />
                        <Typography sx={{ fontSize: 13, fontWeight: 700, color: '#0F172A', minWidth: 24 }}>{count}</Typography>
                      </Box>
                    );
                  })}
                </Card>
              </Grid>
            </Grid>
          )}
        </Box>
      </Box>
      <RespondDialog open={!!respondTo} onClose={() => setRespondTo(null)} request={respondTo} lang={lang} />
    </Layout>
  );
}