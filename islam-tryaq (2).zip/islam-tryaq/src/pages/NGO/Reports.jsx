import React, { useState } from 'react';
import {
  Box, Typography, Grid, Card, CardContent, Chip, Button, Divider,
  LinearProgress, Select, MenuItem, FormControl, InputLabel
} from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import Layout from '../../components/layout/Layout';

import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import BarChartIcon from '@mui/icons-material/BarChart';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import PeopleIcon from '@mui/icons-material/People';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import MedicationIcon from '@mui/icons-material/Medication';
import FoodBankIcon from '@mui/icons-material/FoodBank';
import VolunteerActivismIcon from '@mui/icons-material/VolunteerActivism';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import DownloadIcon from '@mui/icons-material/Download';

const btnGradient = 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)';

const reportData = {
  monthly: {
    totalRequests: 148,
    resolved: 112,
    pending: 24,
    inProgress: 12,
    avgResponseTime: '4.2h',
    criticalHandled: 38,
    byType: { medical: 68, food: 52, support: 28 },
    byLocation: [
      { city: 'Gaza City', cityAr: 'مدينة غزة', count: 44 },
      { city: 'North Gaza', cityAr: 'شمال غزة', count: 32 },
      { city: 'Rafah', cityAr: 'رفح', count: 28 },
      { city: 'Khan Younis', cityAr: 'خان يونس', count: 25 },
      { city: 'Deir al-Balah', cityAr: 'دير البلح', count: 19 },
    ],
    weeklyTrend: [18, 24, 31, 27, 22, 34, 28, 19, 30, 25, 36, 29, 22, 27],
    resolutionRate: 75.7,
  },
  weekly: {
    totalRequests: 36,
    resolved: 26,
    pending: 7,
    inProgress: 3,
    avgResponseTime: '3.8h',
    criticalHandled: 9,
    byType: { medical: 16, food: 13, support: 7 },
    byLocation: [
      { city: 'Gaza City', cityAr: 'مدينة غزة', count: 11 },
      { city: 'North Gaza', cityAr: 'شمال غزة', count: 8 },
      { city: 'Rafah', cityAr: 'رفح', count: 7 },
      { city: 'Khan Younis', cityAr: 'خان يونس', count: 6 },
      { city: 'Deir al-Balah', cityAr: 'دير البلح', count: 4 },
    ],
    weeklyTrend: [5, 6, 4, 7, 6, 4, 4],
    resolutionRate: 72.2,
  },
  quarterly: {
    totalRequests: 412,
    resolved: 318,
    pending: 58,
    inProgress: 36,
    avgResponseTime: '5.1h',
    criticalHandled: 104,
    byType: { medical: 188, food: 142, support: 82 },
    byLocation: [
      { city: 'Gaza City', cityAr: 'مدينة غزة', count: 124 },
      { city: 'North Gaza', cityAr: 'شمال غزة', count: 94 },
      { city: 'Rafah', cityAr: 'رفح', count: 82 },
      { city: 'Khan Younis', cityAr: 'خان يونس', count: 68 },
      { city: 'Deir al-Balah', cityAr: 'دير البلح', count: 44 },
    ],
    weeklyTrend: [28, 32, 40, 38, 44, 48, 42, 50, 46, 52, 48, 44],
    resolutionRate: 77.2,
  },
};

const typeConfig = {
  medical: { icon: <MedicationIcon sx={{ fontSize: 16 }} />, color: '#EF4444', bg: '#FEF2F2', label: 'Medical', labelAr: 'طبي' },
  food: { icon: <FoodBankIcon sx={{ fontSize: 16 }} />, color: '#F59E0B', bg: '#FFFBEB', label: 'Food', labelAr: 'غذاء' },
  support: { icon: <VolunteerActivismIcon sx={{ fontSize: 16 }} />, color: '#8B5CF6', bg: '#F5F3FF', label: 'Support', labelAr: 'دعم' },
};

function StatCard({ icon, label, value, sub, color, bg }) {
  return (
    <Card sx={{ borderRadius: 3, border: `1px solid ${color}25`, background: bg, boxShadow: 'none' }}>
      <CardContent sx={{ p: 2.5, '&:last-child': { pb: 2.5 } }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
          <Box sx={{ width: 40, height: 40, borderRadius: '12px', background: `${color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', color }}>{icon}</Box>
        </Box>
        <Typography sx={{ fontSize: 28, fontWeight: 800, color: '#0F172A', lineHeight: 1 }}>{value}</Typography>
        <Typography sx={{ fontSize: 13, color: '#64748B', mt: 0.5 }}>{label}</Typography>
        {sub && <Typography sx={{ fontSize: 11, color, fontWeight: 600, mt: 0.3 }}>{sub}</Typography>}
      </CardContent>
    </Card>
  );
}

function MiniBarChart({ data, maxVal, color }) {
  const max = maxVal || Math.max(...data);
  return (
    <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: 0.5, height: 60 }}>
      {data.map((v, i) => (
        <Box key={i} sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end' }}>
          <Box sx={{ width: '100%', height: `${(v / max) * 100}%`, minHeight: 3, borderRadius: '2px 2px 0 0', background: color, opacity: i === data.length - 1 ? 1 : 0.45, transition: 'all 0.3s' }} />
        </Box>
      ))}
    </Box>
  );
}

export default function NGOReports() {
  const { language } = useSelector(s => s.ui);
  const navigate = useNavigate();
  const lang = language || 'en';
  const [period, setPeriod] = useState('monthly');
  const d = reportData[period];

  const totalByType = d.byType.medical + d.byType.food + d.byType.support;
  const maxLocation = Math.max(...d.byLocation.map(l => l.count));

  return (
    <Layout>
      <Box sx={{ background: '#F8FAFC', minHeight: '100vh', pt: { xs: 9, md: 10 }, pb: 6 ,display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'}}>
        <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, md: 4 } }}>

          {/* Header */}
          <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
            <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/ngo')}
              sx={{ color: '#64748B', textTransform: 'none', fontWeight: 600, borderRadius: 2.5, border: '1px solid #E2E8F0' }}>
              {lang === 'ar' ? 'رجوع' : 'Back'}
            </Button>
            <Box sx={{ flex: 1 }}>
              <Typography variant="h4" sx={{ fontWeight: 800, background: btnGradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', display: 'inline-block' }}>
                {lang === 'ar' ? 'تقارير المنظمة' : 'NGO Reports'}
              </Typography>
              <Typography sx={{ fontSize: 14, color: '#64748B' }}>
                {lang === 'ar' ? 'تحليل الطلبات والأداء' : 'Request analytics & performance'}
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
              <FormControl size="small" sx={{ minWidth: 130, '& .MuiOutlinedInput-root': { borderRadius: 2.5, '& fieldset': { borderColor: '#E2E8F0' }, '&.Mui-focused fieldset': { borderColor: '#0d9488' } } }}>
                <Select value={period} onChange={e => setPeriod(e.target.value)}>
                  <MenuItem value="weekly">{lang === 'ar' ? 'هذا الأسبوع' : 'This Week'}</MenuItem>
                  <MenuItem value="monthly">{lang === 'ar' ? 'هذا الشهر' : 'This Month'}</MenuItem>
                  <MenuItem value="quarterly">{lang === 'ar' ? 'هذا الربع' : 'This Quarter'}</MenuItem>
                </Select>
              </FormControl>
              <Button variant="outlined" startIcon={<DownloadIcon />}
                sx={{ borderRadius: 2.5, textTransform: 'none', fontWeight: 600, borderColor: '#14B8A6', color: '#14B8A6' }}>
                {lang === 'ar' ? 'تصدير' : 'Export'}
              </Button>
            </Box>
          </Box>

          {/* Stat Cards */}
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={6} sm={3}>
              <StatCard icon={<PeopleIcon />} label={lang === 'ar' ? 'إجمالي الطلبات' : 'Total Requests'}
                value={d.totalRequests} color="#0EA5E9" bg="#F0F9FF" />
            </Grid>
            <Grid item xs={6} sm={3}>
              <StatCard icon={<CheckCircleIcon />} label={lang === 'ar' ? 'تم حلها' : 'Resolved'}
                value={d.resolved} sub={`${d.resolutionRate}%`} color="#22C55E" bg="#F0FDF4" />
            </Grid>
            <Grid item xs={6} sm={3}>
              <StatCard icon={<AccessTimeIcon />} label={lang === 'ar' ? 'متوسط الاستجابة' : 'Avg Response'}
                value={d.avgResponseTime} color="#F59E0B" bg="#FFFBEB" />
            </Grid>
            <Grid item xs={6} sm={3}>
              <StatCard icon={<TrendingUpIcon />} label={lang === 'ar' ? 'حالات حرجة عولجت' : 'Critical Handled'}
                value={d.criticalHandled} color="#EF4444" bg="#FEF2F2" />
            </Grid>
          </Grid>

          <Grid container spacing={3}>
            {/* Trend Chart */}
            <Grid item xs={12} md={8}>
              <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
                <CardContent sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Box>
                      <Typography sx={{ fontWeight: 700, fontSize: 15, color: '#0F172A' }}>
                        {lang === 'ar' ? 'تطور الطلبات' : 'Request Trend'}
                      </Typography>
                      <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>
                        {lang === 'ar' ? 'عدد الطلبات عبر الزمن' : 'Requests over time'}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Chip label={`${d.pending} ${lang === 'ar' ? 'معلق' : 'pending'}`} size="small" sx={{ background: '#FFFBEB', color: '#D97706', fontWeight: 700, fontSize: 11 }} />
                      <Chip label={`${d.inProgress} ${lang === 'ar' ? 'جارٍ' : 'active'}`} size="small" sx={{ background: '#F0F9FF', color: '#0EA5E9', fontWeight: 700, fontSize: 11 }} />
                    </Box>
                  </Box>
                  <MiniBarChart data={d.weeklyTrend} color="#14B8A6" />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Typography sx={{ fontSize: 10, color: '#CBD5E1' }}>{lang === 'ar' ? 'الأقدم' : 'Oldest'}</Typography>
                    <Typography sx={{ fontSize: 10, color: '#CBD5E1' }}>{lang === 'ar' ? 'الأحدث' : 'Latest'}</Typography>
                  </Box>

                  <Divider sx={{ my: 2 }} />

                  {/* Resolution rate */}
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography sx={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>
                      {lang === 'ar' ? 'معدل الحل' : 'Resolution Rate'}
                    </Typography>
                    <Typography sx={{ fontSize: 13, fontWeight: 700, color: '#22C55E' }}>{d.resolutionRate}%</Typography>
                  </Box>
                  <LinearProgress variant="determinate" value={d.resolutionRate}
                    sx={{ height: 8, borderRadius: 4, '& .MuiLinearProgress-bar': { background: btnGradient } }} />
                </CardContent>
              </Card>
            </Grid>

            {/* Request Types */}
            <Grid item xs={12} md={4}>
              <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 10px rgba(0,0,0,0.04)', height: '100%' }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography sx={{ fontWeight: 700, fontSize: 15, mb: 2 }}>
                    {lang === 'ar' ? 'أنواع الطلبات' : 'Request Types'}
                  </Typography>
                  {Object.entries(d.byType).map(([type, count]) => {
                    const cfg = typeConfig[type];
                    const pct = Math.round((count / totalByType) * 100);
                    return (
                      <Box key={type} sx={{ mb: 2 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ color: cfg.color }}>{cfg.icon}</Box>
                            <Typography sx={{ fontSize: 13, fontWeight: 600 }}>
                              {lang === 'ar' ? cfg.labelAr : cfg.label}
                            </Typography>
                          </Box>
                          <Box sx={{ display: 'flex', gap: 0.8, alignItems: 'center' }}>
                            <Typography sx={{ fontSize: 12, fontWeight: 700 }}>{count}</Typography>
                            <Chip label={`${pct}%`} size="small" sx={{ height: 18, fontSize: 10, background: cfg.bg, color: cfg.color, fontWeight: 700 }} />
                          </Box>
                        </Box>
                        <LinearProgress variant="determinate" value={pct}
                          sx={{ height: 5, borderRadius: 3, '& .MuiLinearProgress-bar': { background: cfg.color } }} />
                      </Box>
                    );
                  })}
                </CardContent>
              </Card>
            </Grid>

            {/* Locations */}
            <Grid item xs={12}>
              <Card sx={{ borderRadius: 3.5, border: '1px solid #F1F5F9', boxShadow: '0 2px 10px rgba(0,0,0,0.04)' }}>
                <CardContent sx={{ p: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2.5 }}>
                    <LocationOnIcon sx={{ color: '#0d9488', fontSize: 20 }} />
                    <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
                      {lang === 'ar' ? 'توزيع الطلبات حسب المنطقة' : 'Requests by Location'}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    {d.byLocation.map((loc, i) => {
                      const pct = Math.round((loc.count / maxLocation) * 100);
                      const colors = ['#0EA5E9', '#14B8A6', '#8B5CF6', '#F59E0B', '#EF4444'];
                      return (
                        <Box key={loc.city}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                            <Typography sx={{ fontSize: 13, fontWeight: 600 }}>
                              {i + 1}. {lang === 'ar' ? loc.cityAr : loc.city}
                            </Typography>
                            <Typography sx={{ fontSize: 13, fontWeight: 700, color: colors[i] }}>
                              {loc.count} {lang === 'ar' ? 'طلب' : 'requests'}
                            </Typography>
                          </Box>
                          <LinearProgress variant="determinate" value={pct}
                            sx={{ height: 6, borderRadius: 3, '& .MuiLinearProgress-bar': { background: colors[i] } }} />
                        </Box>
                      );
                    })}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Layout>
  );
}
