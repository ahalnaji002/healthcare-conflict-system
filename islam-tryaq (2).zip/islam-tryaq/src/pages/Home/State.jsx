import React from 'react';
import { Box, Grid, Typography, Container } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';

function StatsSection() {
    
  const stats = [
    { icon: <VerifiedUserIcon />, value: '500+', label: 'Licensed Doctors' },
    { icon: <PeopleIcon />, value: '50,000+', label: 'Happy Patients' },
    { icon: <StarBorderIcon />, value: '4.9/5', label: 'Average Rating' },
    { icon: <AccessTimeIcon />, value: '24/7', label: 'Availability' },
  ];

  return (
    <Container maxWidth="lg" sx={{ mt: 5 }}  style={{marginBottom:"70px"}}>
      <Box
        sx={{
          background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
          borderRadius: '16px',
          padding: { xs: '20px', md: '40px' },
          color: 'white',
        }}
      >
        <Grid container spacing={4} justifyContent="center">
          {stats.map((stat, index) => (
            <Grid item xs={6} md={3} key={index} sx={{ textAlign: 'center' }}>
              <Box sx={{ mb: 1, opacity: 0.8 }}>
                {React.cloneElement(stat.icon, { sx: { fontSize: 30 } })}
              </Box>
              <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 0.5 }}>
                {stat.value}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7, textTransform: 'capitalize' }}>
                {stat.label}
              </Typography>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Container>
  );
};

export default StatsSection;