import React from 'react';
import { Box, Container, Typography, Grid } from '@mui/material';
import { useTranslation } from 'react-i18next';
import SearchIcon from '@mui/icons-material/Search';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';

const HowItWorks = () => {
  const { t, i18n } = useTranslation();
  const isAr = i18n.language === 'ar'; // التأكد إذا كانت اللغة الحالية هي العربية

  // الأيقونات المقابلة لكل خطوة
  const icons = [
    <SearchIcon sx={{ color: 'white' }} />,
    <CalendarMonthIcon sx={{ color: 'white' }} />,
    <VideoCallIcon sx={{ color: 'white' }} />,
    <ReceiptLongIcon sx={{ color: 'white' }} />
  ];

  // جلب البيانات من ملف الترجمة (يجب أن تكون مصفوفة خطوات)
  const steps = t('home.howItWorks.steps', { returnObjects: true }) || [];

  return (
    // الحاوية الرئيسية مع ضبط الاتجاه
    <Box 
      dir={isAr ? 'rtl' : 'ltr'} 
      sx={{ 
        py: { xs: 8, md: 12 }, 
        background: '#F8FAFC', 
        overflow: 'hidden',
      }}

       style={{marginBottom:"70px"}}
    >
      <Container maxWidth="lg">
        {/* قسم العنوان - دائماً في المنتصف */}
        <Box sx={{ textAlign: 'center', mb: { xs: 6, md: 10 } }}>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 13,
              letterSpacing: 2,
              mb: 1,
               textTransform: 'uppercase',
        background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',
            }}
          >
            {isAr ? 'كيف يعمل الموقع' : 'How It Works'}
          </Typography>
          <Typography
            variant="h3"
            sx={{
              fontSize: { xs: 26, md: 36 },
              fontWeight: 800,
              color: '#0F172A',
              mb: 1.5,
            }}
          >
            {t('home.howItWorks.title')}
          </Typography>
        </Box>

        {/* الحاوية النسبية للخط والخطوات */}
        <Box sx={{ position: 'relative' }}>
          
          {/* الخط الواصل - يتأثر بالـ dir تلقائياً */}
          <Box
            sx={{
              position: 'absolute',
              top: 30, // نصف ارتفاع الأيقونة
              // MUI ستقوم بتبديلهم تلقائياً بناءً على dir الصفحة
              left: { md: '0%' }, 
              right: { md: '0%' },
              height: '1px', // خط أنحف ليكون أرقى
              background: 'rgba(13,148,136,0.15)', // لون الخط هادئ
              display: { xs: 'none', md: 'block' },
              zIndex: 0,
            }}
          />

          <Grid 
            container 
            // التعديل الرئيسي: توزيع العناصر بشكل متساوٍ على طول الخط
            // العنصر الأول سيكون على الحافة (يمين في العربي) والأخير على الحافة الأخرى
            sx={{ 
              display: 'flex',
              flexDirection: { xs: 'column', md: isAr ? 'row-reverse' : 'row' },
              justifyContent: { md: 'space-between' }, // هذا السطر هو السر في توزيع المسافات
              alignItems: 'center',
            }}
          >
            {steps.map((step, index) => (
              <Grid 
                item 
                key={index}
                // في الشاشات الكبيرة لا نستخدم xs={} بل نجعل الـ Box الداخلي هو من يحدد العرض
                sx={{ 
                  flex: { md: '1 1 0px' }, // يجعل كل عمود يأخذ نفس المساحة
                  maxWidth: { md: '280px' }, // يمنع تمدد النصوص بشكل قبيح
                  mb: { xs: 4, md: 0 },
                  zIndex: 1,
                  // محاذاة العناصر الداخلية بناءً على اللغة
                  textAlign: isAr ? 'right' : 'left', 
                }}
              >
                <Box
                  sx={{
                    textAlign: 'center', // توسيط المحتوى داخل العمود
                    px: 1,
                  }}
                >
                  {/* الدائرة */}
                  <Box
                    sx={{
                      width: 60,
                      height: 60,
                      borderRadius: '16px',
                      background: 'linear-gradient(135deg, #0d9488 0%, #0f172a 100%)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition:"all 0.4s ease",
                      cursor:"pointer",
                      mx: 'auto', // توسيط الدائرة أفقياً
                      mb: 2.5,
                      boxShadow: '0 8px 24px rgba(13,148,136,0.15)',
                      '&:hover': {
                        transform: 'translateY(-5px) scale(1.05)', // تحريك للأعلى وتكبير بسيط
                        boxShadow: '0 12px 30px rgba(13,148,136,0.25)', // ظل أعمق وأكثر انتشاراً
                      }
                    }}
                  >
                    {icons[index]}
                  </Box>

                  {/* نصوص الخطوة */}
                  <Typography
                    variant="h6"
                    sx={{
                      fontWeight: 700,
                      fontSize: 16, // تصغير بسيط ليناسب التصميم
                      color: '#0F172A',
                      mb: 1,
                      textAlign: 'center', // توسيط العنوان
                    }}
                  >
                    {step.title}
                  </Typography>
                  <Typography
                    sx={{
                      color: '#64748B',
                      fontSize: 13,
                      lineHeight: 1.6,
                      maxWidth: 240,
                      mx: 'auto', // توسيط الوصف
                      textAlign: 'center', // توسيط الوصف
                    }}
                  >
                    {step.desc}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Container>
    </Box>
  );
};

export default HowItWorks;