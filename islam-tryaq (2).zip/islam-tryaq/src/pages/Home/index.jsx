import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, Button, Container, Chip, Avatar, Stack } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import Layout from '../../components/layout/Layout';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import StarIcon from '@mui/icons-material/Star';
import { Grid } from '@mui/material';
import VideoCameraFrontRoundedIcon from '@mui/icons-material/VideoCameraFrontRounded';

import DoctorCard from '../../components/common/DoctorCard';
import { doctors } from '../../data/mockData';

import StatsSection from './State';

import HowItWorks from './HowItWork';

import ArrowBackIcon from '@mui/icons-material/ArrowBack';

import FormatQuoteIcon from '@mui/icons-material/FormatQuote'; // تأكد من استيراد هذه الأيقونة
import TestimonialsSection from './TESTIMONIALS';

export default function Home() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { language } = useSelector(s => s.ui);


  const specialties = [
    { id: 1, key: "dentist", name: "Dentist", color: "#E0F2FE", icon: "🦷" },
    { id: 2, key: "cardiology", name: "Cardiology", color: "#DCFCE7", icon: "❤️" },
    { id: 3, key: "dentist", name: "Dentist", color: "#E0F2FE", icon: "🦷" },
    { id: 4, key: "cardiology", name: "Cardiology", color: "#DCFCE7", icon: "❤️" },
    { id: 5, key: "dentist", name: "Dentist", color: "#E0F2FE", icon: "🦷" },
    { id: 6, key: "cardiology", name: "Cardiology", color: "#DCFCE7", icon: "❤️" },
    { id: 7, key: "cardiology", name: "Cardiology", color: "#DCFCE7", icon: "❤️" },
  ];



  const testimonials = [
    { id: 1, text: "Great service!", name: "Ahmad", role: "Patient", rating: 5 },
    { id: 2, text: "Amazing doctors!", name: "Ali", role: "Patient", rating: 4 },
    { id: 3, text: "Amazing doctors!", name: "Ali", role: "Patient", rating: 4 },
    { id: 4, text: "Amazing doctors!", name: "Ali", role: "Patient", rating: 4 },
    { id: 5, text: "Amazing doctors!", name: "Ali", role: "Patient", rating: 4 },
  ];


  const features = [
  {
    title: "Verified Doctors",
    description: "Every doctor is thoroughly verified before joining."
  },
  {
    title: "Secure & Private",
    description: "Your health data is encrypted end-to-end."
  },
  {
    title: "Instant Prescriptions",
    description: "Digital prescriptions sent to your pharmacy."
  },
  {
    title: "Affordable Care",
    description: "Transparent pricing with no hidden fees."
  }
];

  return (
    <Layout>
      {/* ── HERO ── */}
      <Box sx={{
        background: 'linear-gradient(160deg, #F0F9FF 0%, #F8FAFC 50%, #F0FDF4 100%)',
        pt: { xs: 8, md: 12 }, pb: { xs: 8, md: 10 }, position: 'relative', overflow: 'hidden',
      }}
       style={{marginBottom:"70px"}}
       >
        <Box sx={{ position: 'absolute', top: -60, right: -60, width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle, rgba(14,165,233,0.08) 0%, transparent 70%)', pointerEvents: 'none' }} />
        <Box sx={{ position: 'absolute', bottom: -60, left: -60, width: 300, height: 300, borderRadius: '50%', background: 'radial-gradient(circle, rgba(20,184,166,0.08) 0%, transparent 70%)', pointerEvents: 'none' }} />

        <Container maxWidth="lg">
          <Box sx={{
            display: 'flex',
            flexDirection: { xs: 'column', md: 'row' },
            alignItems: 'center',
            gap: { xs: 6, md: 8 },
            justifyContent: 'space-between',
          }}>

            {/* ── النص ── */}
            <Box sx={{ width: { xs: '100%', md: '50%' } }}>
                
              
              <Chip
                label={` ${t('home.hero.badge')}`}
                sx={{ mb: 3, background: '#F0F9FF', color: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)', background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    backgroundClip: 'text', fontWeight: 600, fontSize: 13, border: '1px solid #188' }}
              />

              <Typography variant="h1" sx={{
                fontSize: { xs: 38, md: 52 }, fontWeight: 800, lineHeight: 1.15, mb: 2, color: '#0F172A',
              }}>
                {/* Healthcare - gradient */}
                <span style={{
                  background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}>
                  {t('home.hero.title1')}
                </span>{' '}

                {t('home.hero.title2')}{' '}

                {/* For Everyone - gradient */}
                <span style={{
                  background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}>
                  {t('home.hero.title3')}
                </span>
              </Typography>

              <Typography sx={{ fontSize: 17, color: '#64748B', lineHeight: 1.7, mb: 4, maxWidth: 480 }}>
                {t('home.hero.subtitle')}
              </Typography>

              <Stack direction="row" spacing={2} sx={{ flexWrap: 'wrap', mb: 3 }}>
                {/* Find a Doctor */}
                <Button variant="contained" size="large" endIcon={<ArrowForwardIcon />}
                  onClick={() => navigate('/doctors')}
                  sx={{
                    borderRadius: '12px', px: 3.5, py: 1.5, fontSize: 15, fontWeight: 700, textTransform: 'none',
                    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                    boxShadow: '0 4px 14px rgba(13,148,136,0.35)',
                    color:"white",
                    transition:"all 0.3s ease",
                    '&:hover': {
                      background: 'linear-gradient(90deg, #1e293b 0%, #0f766e 100%)',
                      transform: 'translateY(-1px)',
                      boxShadow: '0 6px 20px rgba(13,148,136,0.45)',
                      
                    },
                  }}>
                  {t('home.hero.findDoctor')}
                </Button>

                {/* Book Consultation */}
                <Button variant="outlined" size="large"
                  onClick={() => navigate('/register')}
                  sx={{
                    borderRadius: '12px', px: 3.5, py: 1.5, fontSize: 15, fontWeight: 600, textTransform: 'none',
                    borderColor: '#0d9488', color: '#0d9488',
                    '&:hover': { background: '#f0fdf4', borderColor: '#0d9488' },
                  }}>
                  {t('home.hero.bookConsultation')}
                </Button>
              </Stack>

              <Box sx={{ display: 'flex', gap: 1, color: '#64748B', fontSize: 13, alignItems: 'center', flexWrap: 'wrap' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <CheckCircleIcon sx={{ fontSize: 16, color: '#22C55E' }} />
                  <span>HIPAA Compliant</span>
                </Box>
                <Box sx={{ mx: 1, display: { xs: 'none', sm: 'block' } }}>|</Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <CheckCircleIcon sx={{ fontSize: 16, color: '#22C55E' }} />
                  <span>Available 24/7</span>
                </Box>
              </Box>
            </Box>

            {/* ── الصورة ── */}
            <Box sx={{
              width: { xs: '100%', md: '45%' },
              position: 'relative',
              mt: { xs: 4, md: 0 },
            }}>
              <Box sx={{
                borderRadius: 8,
                overflow: 'hidden',
                boxShadow: '0 30px 70px rgba(14,165,233,0.15)',
                border: '4px solid rgba(255,255,255,1)',
                position: 'relative',
                zIndex: 2,
              }}>
                <img
                  src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop"
                  alt="Healthcare"
                  style={{ width: '100%', height: 400, objectFit: 'cover', display: 'block' }}
                />
              </Box>

              {/* كرت Video */}
              <Box sx={{
                position: 'absolute',
                bottom: { xs: -15, md: 30 },
                right: { xs: 0, md: -30 },
                background: 'white', borderRadius: 4, p: 2,
                boxShadow: '0 15px 35px rgba(0,0,0,0.1)',
                display: 'flex', alignItems: 'center', gap: 1.5, minWidth: 200,
                zIndex: 10,
              }}>
                <Box sx={{ width: 42, height: 42, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <VideoCameraFrontRoundedIcon sx={{ color: '#0d9488', fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography sx={{ fontWeight: 800, fontSize: 13, color: '#0F172A' }}>Video Consultation</Typography>
                  <Typography sx={{ fontSize: 11, color: '#22C55E', fontWeight: 600 }}>● Live Now</Typography>
                </Box>
              </Box>

              {/* كرت Doctors */}
              <Box sx={{
                position: 'absolute',
                top: { xs: -15, md: 20 },
                left: { xs: 0, md: -30 },
                background: 'white', borderRadius: 4, p: 1.5,
                boxShadow: '0 15px 35px rgba(0,0,0,0.1)',
                display: 'flex', alignItems: 'center', gap: 1,
                zIndex: 10,
              }}>
                <Box sx={{ display: 'flex' }}>
                  {[
                    'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=64',
                    'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=64',
                    'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=64',
                  ].map((src, i) => (
                    <Avatar key={i} src={src} sx={{ width: 32, height: 32, border: '2px solid white', ml: i > 0 ? -1.5 : 0 }} />
                  ))}
                </Box>
                <Box sx={{ ml: 0.5 }}>
                  <Typography sx={{ fontSize: 11, fontWeight: 800, color: '#0F172A' }}>500+ Doctors</Typography>
                  <Box sx={{ display: 'flex' }}>
                    {[...Array(5)].map((_, i) => <StarIcon key={i} sx={{ fontSize: 12, color: '#F59E0B' }} />)}
                  </Box>
                </Box>
              </Box>
            </Box>

          </Box>
        </Container>
      </Box>



      {/* التقييمات  */}

      <StatsSection />




  {/* ── SPECIALTIES ── */}
<Box sx={{ py: { xs: 6, md: 8 }, background: 'white' }}  style={{marginBottom:"70px"}}>
  <Container maxWidth="lg">

    {/* العنوان */}
    <Box sx={{ textAlign: 'center', mb: 5 }}>
      <Typography sx={{
        fontWeight: 600, fontSize: 13, letterSpacing: 2, mb: 1,
        textTransform: 'uppercase',
        background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        display: 'inline-block',
      }}>
        Specialties
      </Typography>
      <Typography variant="h3" sx={{
        fontSize: { xs: 24, md: 36 }, fontWeight: 700, color: '#0F172A', mb: 1.5,
      }}>
        {t('home.specialties.title')}
      </Typography>
      <Typography sx={{ color: '#64748B', maxWidth: 540, mx: 'auto', fontSize: 15 }}>
        {t('home.specialties.subtitle')}
      </Typography>
    </Box>

    {/* الكروت المعدلة */}
    <Grid container spacing={{ xs: 2, md: 3 }}>
      {[
        { key: 'cardiology',      name: 'Cardiology',       nameAr: 'أمراض القلب',    icon: '❤️',  color: '#fff0f0', border: '#fca5a5' },
        { key: 'neurology',       name: 'Neurology',        nameAr: 'أمراض الأعصاب',  icon: '🧠',  color: '#f5f3ff', border: '#c4b5fd' },
        { key: 'ophthalmology',   name: 'Ophthalmology',    nameAr: 'طب العيون',       icon: '👁️', color: '#eff6ff', border: '#93c5fd' },
        { key: 'generalMedicine', name: 'General Medicine', nameAr: 'الطب العام',      icon: '🩺',  color: '#f0fdf4', border: '#86efac' },
        { key: 'pediatrics',      name: 'Pediatrics',       nameAr: 'طب الأطفال',      icon: '👶',  color: '#fffbeb', border: '#fcd34d' },
        { key: 'orthopedics',     name: 'Orthopedics',      nameAr: 'العظام',          icon: '🦴',  color: '#f0fdf4', border: '#99f6e4' },
        { key: 'dermatology',     name: 'Dermatology',      nameAr: 'الجلدية',         icon: '🌿',  color: '#fdf4ff', border: '#d8b4fe' },
        { key: 'dentist',         name: 'Dentist',          nameAr: 'طب الأسنان',      icon: '🦷',  color: '#f0f9ff', border: '#7dd3fc' },
      ].map((sp, i) => (
        /* التعديل هنا: xs={6} لعنصرين، sm={4} لثلاثة عناصر */
        <Grid item xs={6} sm={4} md={3} key={i}>
          <Box
            onClick={() => navigate(`/doctors?specialty=${sp.key}`)}
            sx={{
              p: { xs: 2, md: 2.5 },
              borderRadius: 3,
              textAlign: 'center',
              cursor: 'pointer',
              border: `1px solid ${sp.border}`,
              background: sp.color,
              transition: 'all 0.25s',
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: `0 10px 28px rgba(13,148,136,0.15)`,
                borderColor: '#0d9488',
              },
            }}
          >
            {/* الأيقونة */}
            <Box sx={{
              width: { xs: 44, md: 52 },
              height: { xs: 44, md: 52 },
              borderRadius: '14px',
              background: 'rgba(255,255,255,0.8)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: { xs: 22, md: 26 },
              mb: 1.5,
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            }}>
              {sp.icon}
            </Box>

            {/* الاسم */}
            <Typography sx={{
              fontWeight: 700,
              fontSize: { xs: 13, md: 15 },
              color: '#0f172a',
              mb: 0.5,
              lineHeight: 1.3,
            }}>
              {language === 'ar' ? sp.nameAr : sp.name}
            </Typography>

            {/* عدد الأطباء */}
            <Typography sx={{
              fontSize: { xs: 11, md: 12 },
              color: '#0d9488',
              fontWeight: 600,
            }}>
              {doctors.filter(d => d.specialtyKey === sp.key).length} {language === 'ar' ? 'طبيب' : 'Doctors'}
            </Typography>
          </Box>
        </Grid>
      ))}
    </Grid>
  </Container>
</Box>



      {/* ── HOW IT WORKS ── */}

      {/* <Box sx={{ py: { xs: 6, md: 8 }, background: '#F8FAFC' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 5 }}>
            <Typography sx={{ background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', fontWeight: 600, fontSize: 13, letterSpacing: 2, mb: 1, textTransform: 'uppercase' }}>
              How It Works
            </Typography>
            <Typography variant="h3" sx={{ fontSize: { xs: 26, md: 36 }, fontWeight: 700, color: '#0F172A', mb: 1.5 }}>
              {t('home.howItWorks.title')}
            </Typography>
            <Typography sx={{ color: '#64748B', fontSize: 15 }}>{t('home.howItWorks.subtitle')}</Typography>
          </Box>
          <Grid container spacing={3}>
            {t('home.howItWorks.steps', { returnObjects: true }).map((step, i) => (
              <Grid item xs={12} sm={6} md={3} key={i}>
                <Box sx={{ textAlign: 'center', p: 3 }}>
                  <Box sx={{
                    width: 60, height: 60, borderRadius: '18px',
                    background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    mx: 'auto', mb: 2, boxShadow: '0 6px 20px rgba(13,148,136,0.3)',
                  }}>
                    <Typography sx={{ color: 'white', fontWeight: 800, fontSize: 20 }}>{i + 1}</Typography>
                  </Box>
                  <Typography sx={{ fontWeight: 700, fontSize: 16, mb: 1, color: '#0F172A' }}>{step.title}</Typography>
                  <Typography sx={{ color: '#64748B', fontSize: 14, lineHeight: 1.6 }}>{step.desc}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box> */}

      <HowItWorks/>



    {/* Our Doctors */}

    {/* <DoctorCard/> */}

{/* Our Doctors Section */}
<Box sx={{ py: { xs: 6, md: 8 }, background: '#F8FAFC' }} style={{ marginBottom: "70px" }}>
  <Container maxWidth="lg">

    {/* Header */}
    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', mb: 5 }}>
      <Box>
        <Typography sx={{
          fontWeight: 700, fontSize: 11, letterSpacing: 2, mb: 1,
          textTransform: 'uppercase',
          background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text', display: 'inline-block',
        }}>
          {language === 'ar' ? 'أطباؤنا' : 'OUR DOCTORS'}
        </Typography>
        <Typography variant="h4" sx={{
          fontSize: { xs: 26, md: 32 }, fontWeight: 900, color: '#0F172A', mb: 0.8
        }}>
          {t('home.topDoctors.title')}
        </Typography>
        <Typography sx={{ color: '#64748B', fontSize: 14 }}>
          {t('home.topDoctors.subtitle')}
        </Typography>
      </Box>

      <Button
        endIcon={language === 'ar' ? <ArrowBackIcon /> : <ArrowForwardIcon />}
        onClick={() => navigate('/doctors')}
        sx={{ color: '#0d9488', fontWeight: 700, fontSize: 13, textTransform: 'none' }}
      >
        {t('home.topDoctors.viewAll')}
      </Button>
    </Box>

    {/* Cards Grid */}
    <Grid container spacing={3}>
      {doctors.slice(0, 4).map(doc => (
        <Grid item xs={12} sm={6} lg={3} key={doc.id} sx={{ display: 'flex' }}>
          <DoctorCard doctor={doc} language={language} navigate={navigate} />
        </Grid>
      ))}
    </Grid>

  </Container>
</Box>





    {/* ── TESTIMONIALS ── */}

    <TestimonialsSection/>



      {/* ── TRUST SECTION ── */}

<Box sx={{ py: { xs: 6, md: 8 }, background: 'white'  }} style={{marginBottom:"70px"}}>
  <Container maxWidth="lg">
    <Grid container spacing={6} alignItems="center">

      {/* الجانب الأيسر - النص */}
      <Grid size={{ xs: 12, md: 6 }}>
        <Typography sx={{
          fontWeight: 700, fontSize: 12,
          letterSpacing: 2, mb: 1.5, textTransform: 'uppercase',
          background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text', display: 'inline-block',
        }}>
          Why Teryaq
        </Typography>

        <Typography variant="h3" sx={{
          fontSize: { xs: 26, md: 36 }, fontWeight: 800,
          color: '#0F172A', lineHeight: 1.2, mb: 2
        }}>
          {t('home.trust.title')}
        </Typography>

        <Typography sx={{
          color: '#64748B', fontSize: 15, mb: 5, lineHeight: 1.8, maxWidth: 420
        }}>
          {t('home.trust.subtitle')}
        </Typography>

        {/* قائمة المميزات */}
        <Stack spacing={3}>
          {t('home.trust.features', { returnObjects: true }).map((f, i) => (
            <Stack key={i} direction="row" spacing={2} alignItems="flex-start">
              <Box sx={{
                width: 32, height: 32,
                borderRadius: '50%',
                background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0, mt: 0.3
              }}>
                <CheckCircleIcon sx={{ fontSize: 18, color: 'white' }} />
              </Box>
              <Box>
                <Typography sx={{ fontWeight: 700, fontSize: 14, color: '#0F172A', mb: 0.3 }}>
                  {f.title}
                </Typography>
                <Typography sx={{ fontSize: 13, color: '#94A3B8', lineHeight: 1.6 }}>
                  {f.desc}
                </Typography>
              </Box>
            </Stack>
          ))}
        </Stack>
      </Grid>

      {/* الجانب الأيمن - الصورة */}
      <Grid size={{ xs: 12, md: 6 }}>
        <Box sx={{ position: 'relative', borderRadius: 5, overflow: 'hidden', boxShadow: '0 20px 50px rgba(0,0,0,0.12)' }}>

          <img
            src="https://images.unsplash.com/photo-1551076805-e1869033e561?w=600&h=420&fit=crop"
            alt="Trust"
            style={{
              width: '100%',
              height: 400,
              objectFit: 'cover',
              display: 'block',
              filter: 'brightness(0.75)'
            }}
          />

          {/* Badge 98% */}
          <Box sx={{
            position: 'absolute',
            bottom: 28,
            left: 28,
            background: 'rgba(255,255,255,0.15)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.25)',
            borderRadius: '50%',
            width: 110,
            height: 110,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            textAlign: 'center',
          }}>
            <Typography sx={{
              fontSize: 32, fontWeight: 900,
              lineHeight: 1, color: 'white',
              fontFamily: "'Sora', sans-serif"
            }}>
              98%
            </Typography>
            <Typography sx={{
              fontSize: 11, color: 'rgba(255,255,255,0.85)',
              mt: 0.5, fontWeight: 500, px: 1
            }}>
              Patient Satisfaction
            </Typography>
          </Box>

        </Box>
      </Grid>

    </Grid>
  </Container>
</Box>

    

      



      {/* ── CTA ── */}
      <Box sx={{
        py: { xs: 7, md: 9 },
        background: 'linear-gradient(135deg, #0F172A 0%, #0d9488 100%)',
        position: 'relative', overflow: 'hidden',
        width:"80%",
        margin:"0 auto",
        borderRadius:"20px",
        marginBottom:"70px"
      }}>
        <Box sx={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(255,255,255,0.05) 0%, transparent 70%)' }} />
        <Container maxWidth="md" sx={{ textAlign: 'center', position: 'relative' }}>
          <Typography variant="h2" sx={{ fontSize: { xs: 28, md: 42 }, fontWeight: 800, color: 'white', mb: 2, lineHeight: 1.2 }}>
            {t('home.cta.title')}
          </Typography>
          <Typography sx={{ color: 'rgba(255,255,255,0.8)', fontSize: 16, mb: 4, maxWidth: 500, mx: 'auto', lineHeight: 1.7 }}>
            {t('home.cta.subtitle')}
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Button variant="contained" size="large" endIcon={<ArrowForwardIcon />}
              onClick={() => navigate('/register')}
              sx={{
                background: 'white', color: '#0d9488', borderRadius: 3, px: 3.5, py: 1.5, fontWeight: 700, fontSize: 15,
                
                boxShadow: '0 4px 20px rgba(0,0,0,0.15)', '&:hover': { background: '#f0fdf4', transform: 'translateY(-2px)' },
              }}>
              {t('home.cta.getStartedFree')}
            </Button>
            <Button variant="outlined" size="large"
              onClick={() => navigate('/register')}
              sx={{
                borderColor: 'rgba(255,255,255,0.5)', color: 'white', borderRadius: 3, px: 3.5, py: 1.5, fontWeight: 600, fontSize: 15,
                '&:hover': { borderColor: 'white', background: 'rgba(255,255,255,0.1)' },
              }}>
              {t('home.cta.createAccount')}
            </Button>
          </Box>
        </Container>
      </Box>
      

    </Layout>
    
  );
}