import React from "react";
import {
  Box,
  Typography,
  Container,
  Grid,
  Card,
  CardContent,
  Avatar,
} from "@mui/material";
import StarIcon from "@mui/icons-material/Star";

const testimonials = [
  {
    name: "Lina Nassar",
    role: "Patient",
    image: "https://i.pravatar.cc/100?img=1",
    text: "Amazing service! The staff is very friendly, and the doctors are incredibly professional. Highly recommended!",
  },
  {
    name: "Mark James",
    role: "Patient",
    image: "https://i.pravatar.cc/100?img=2",
    text: "The best clinic I’ve ever visited. Everything was smooth and the experience was top-notch.",
  },
  {
    name: "Robert Williams",
    role: "Patient",
    image: "https://i.pravatar.cc/100?img=3",
    text: "Excellent care and friendly staff. I felt comfortable throughout the entire consultation.",
  },
];

export default function TestimonialsSection() {
  return (
    <Box sx={{ py: 10, backgroundColor: "#F8FAFC" }} style={{marginBottom:"70px"}}>
      <Container maxWidth="lg">

        {/* Header */}
        <Box textAlign="center" mb={6}>
          <Typography
            sx={{
                background: 'linear-gradient(90deg, #0f172a 0%, #0d9488 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            display: 'inline-block',
              fontWeight: 600,
              letterSpacing: 2,
              fontSize: 14,
              mb: 1,
              textTransform: "uppercase",
            }}
          >
            Testimonials
          </Typography>

          <Typography variant="h4" fontWeight="bold" mb={1}>
            What Our Patients Say
          </Typography>

          <Typography color="text.secondary">
            Real stories from our patients who trust our services
          </Typography>
        </Box>

        {/* Cards */}
        <Grid container spacing={4} justifyContent="center">
          {testimonials.map((item, index) => (
            <Grid
              item
              xs={12}
              md={6}
              lg={6}
              key={index}
              sx={{ display: "flex", justifyContent: "center" }}
            >
              <Card
                sx={{
                  width: "100%",
                  maxWidth: "500px", // 👈 العرض الثابت
                  borderRadius: "20px",
                  boxShadow: "0 10px 30px rgba(0,0,0,0.06)",
                  transition: "0.3s",
                  "&:hover": {
                    transform: "translateY(-6px)",
                    boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
                  },
                }}
              >
                <CardContent sx={{ p: 4 }}>

                  {/* Stars */}
                  <Box sx={{ display: "flex", mb: 2 }}>
                    {[...Array(5)].map((_, i) => (
                      <StarIcon key={i} sx={{ color: "#FFC107", fontSize: 20 }} />
                    ))}
                  </Box>

                  {/* Text */}
                  <Typography
                    sx={{
                      color: "#555",
                      fontSize: 15,
                      lineHeight: 1.8,
                      mb: 4,
                    }}
                  >
                    {item.text}
                  </Typography>

                  {/* User */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                    <Avatar src={item.image} sx={{ width: 45, height: 45 }} />

                    <Box>
                      <Typography fontWeight="bold" fontSize={15}>
                        {item.name}
                      </Typography>
                      <Typography fontSize={13} color="text.secondary">
                        {item.role}
                      </Typography>
                    </Box>
                  </Box>

                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

      </Container>
    </Box>
  );
}