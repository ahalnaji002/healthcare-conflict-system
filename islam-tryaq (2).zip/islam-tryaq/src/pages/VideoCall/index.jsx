import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Box, Typography, IconButton, Avatar, Tooltip } from '@mui/material';
import MicIcon from '@mui/icons-material/Mic';
import MicOffIcon from '@mui/icons-material/MicOff';
import VideocamIcon from '@mui/icons-material/Videocam';
import VideocamOffIcon from '@mui/icons-material/VideocamOff';
import ScreenShareIcon from '@mui/icons-material/ScreenShare';
import ChatIcon from '@mui/icons-material/Chat';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import CallEndIcon from '@mui/icons-material/CallEnd';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import { useSelector } from 'react-redux';

export default function VideoCall() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { list } = useSelector(s => s.appointments);
  const { user } = useSelector(s => s.auth);
  const appt = list.find(a => a.id === Number(id)) || list[0];

  const [mic, setMic] = useState(true);
  const [cam, setCam] = useState(true);
  const [seconds, setSeconds] = useState(754);

  useEffect(() => {
    const timer = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (s) => {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    return `${m}:${sec}`;
  };

  const initials = user ? `${user.firstName?.[0]}${user.lastName?.[0]}` : 'JD';

  return (
    <Box sx={{ height: '100vh', background: '#0F172A', display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
      {/* Top bar */}
      <Box sx={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', px: 3, py: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Avatar src={appt?.image} sx={{ width: 36, height: 36, borderRadius: 1.5 }} />
          <Box>
            <Typography sx={{ color: 'white', fontWeight: 700, fontSize: 14 }}>{appt?.doctor || 'Dr. Sarah Mitchell'}</Typography>
            
            <Typography sx={{ color: '#94A3B8', fontSize: 12 }}>{appt?.specialty || 'Cardiologist'} · In Session</Typography>
          </Box>

        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, background: 'rgba(34,197,94,0.2)', px: 1.5, py: 0.5, borderRadius: 2 }}>

            <Box sx={{ width: 8, height: 8, borderRadius: '50%', background: '#22C55E' }} />
            
            <Typography sx={{ color: '#22C55E', fontSize: 13, fontWeight: 600 }}>{formatTime(seconds)}</Typography>
          </Box>
          <IconButton sx={{ color: '#94A3B8' }}><FullscreenIcon /></IconButton>
        </Box>
      </Box>

      {/* Doctor video (full screen) */}
      <Box sx={{ flex: 1, position: 'relative', background: '#1E293B' }}>
        <img
          src={appt?.image || 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=800&h=600&fit=crop&crop=face'}
          alt="Doctor"
          style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: cam ? 1 : 0.3 }}
        />
        <Box sx={{ position: 'absolute', bottom: 20, left: 20 }}>
          <Box sx={{ background: 'rgba(0,0,0,0.5)', px: 1.5, py: 0.5, borderRadius: 1.5, backdropFilter: 'blur(4px)' }}>
            <Typography sx={{ color: 'white', fontSize: 13, fontWeight: 500 }}>{appt?.doctor || 'Dr. Sarah Mitchell'}</Typography>
          </Box>
        </Box>
      </Box>

      {/* Patient PiP */}
      <Box sx={{
        position: 'absolute', bottom: 90, right: 20,
        width: 140, height: 105, borderRadius: 3, overflow: 'hidden',
        background: "linear-gradient(90deg, #0f172a 0%, #0d9488 100%)",
        boxShadow: '0 8px 24px rgba(0,0,0,0.4)', border: '2px solid rgba(255,255,255,0.2)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {cam ? (
          <Typography sx={{ color: 'white', fontWeight: 800, fontSize: 24 }}>{initials}</Typography>
        ) : (
          <Box sx={{ textAlign: 'center' }}>
            <VideocamOffIcon sx={{ color: 'rgba(255,255,255,0.6)', fontSize: 28 }} />
          </Box>
        )}
        <Box sx={{ position: 'absolute', bottom: 6, left: 8 }}>
          <Typography sx={{ color: 'rgba(255,255,255,0.8)', fontSize: 11 }}>You</Typography>
        </Box>
      </Box>

      {/* Controls */}
      <Box sx={{ position: 'absolute', bottom: 0, left: 0, right: 0, py: 3, display: 'flex', justifyContent: 'center', gap: 2, background: 'linear-gradient(to top, rgba(15,23,42,0.9), transparent)' }}>
        {[
          { icon: mic ? <MicIcon /> : <MicOffIcon />, action: () => setMic(!mic), active: mic, label: mic ? 'Mute' : 'Unmute' },
          { icon: cam ? <VideocamIcon /> : <VideocamOffIcon />, action: () => setCam(!cam), active: cam, label: cam ? 'Stop Video' : 'Start Video' },
          { icon: <ScreenShareIcon />, action: () => {}, active: true, label: 'Share Screen' },
          { icon: <ChatIcon />, action: () => navigate(`/chat/${id}`), active: true, label: 'Chat' },
          { icon: <MoreHorizIcon />, action: () => {}, active: true, label: 'More' },
        ].map((btn, i) => (
          <Tooltip key={i} title={btn.label} placement="top">
            <IconButton onClick={btn.action}
              sx={{
                width: 52, height: 52, borderRadius: '50%',
                background: btn.active ? 'rgba(255,255,255,0.15)' : 'rgba(239,68,68,0.3)',
                color: 'white', backdropFilter: 'blur(8px)',
                transition: 'all 0.2s',
                '&:hover': { background: btn.active ? 'rgba(255,255,255,0.25)' : 'rgba(239,68,68,0.5)', transform: 'scale(1.05)' },
              }}>
              {btn.icon}
            </IconButton>
          </Tooltip>
        ))}
        <Tooltip title="End Call" placement="top">
          <IconButton onClick={() => navigate('/appointments')}
            sx={{
              width: 52, height: 52, borderRadius: '50%',
              background: '#EF4444', color: 'white',
              '&:hover': { background: '#DC2626', transform: 'scale(1.05)' },
              transition: 'all 0.2s',
            }}>
            <CallEndIcon />
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  );
}
